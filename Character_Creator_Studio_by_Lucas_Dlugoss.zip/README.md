# Lucas Character — v27

A local app for creating 3D characters and objects with PBR textures, reference approval, and optional automatic rigging.

## Installation

1. Close ComfyUI.
2. Extract the entire ZIP into a folder.
3. Run `INSTALL.cmd`. Keep the window open until setup finishes.
4. Open ComfyUI, refresh the interface with Ctrl+F5, and import `Qwen_Character_Approval_3Views_Offline.json` into a new tab.

The installer uses your existing ComfyUI Desktop installation on Windows. It prepares Git, Blender, and the UniRig environment when needed. Downloads require internet access and free disk space. The Qwen/Hunyuan generation models and their nodes must be available. PBR painting requires its native extensions; compiling them may require Visual Studio C++ Build Tools and the CUDA Toolkit. Installation errors are recorded in `lucas_install_logs`. Do not enable rigging until its installation is complete.

## Using the app

Choose your interface language, then enter a description and select an anatomy preset, or upload reference images. Image generation produces front, left, and back views. Upload mode accepts additional references; top and bottom views are used for painting. Approve the views, choose a performance profile, and run generation. UniRig is optional.

Automatic and Quality adjust parameters according to detected memory. Check the effective settings shown in the interface. Manual uses the performance node's `manual_*` parameters. No profile guarantees compatibility with every GPU.

Click **Open editor** to see the ComfyUI nodes and load another workflow. Save any changes to your current workflow first.

## Blender files and materials

After generation finishes, use the editable Blender file download button. The `.blend` includes packed images and a material connected to the Principled BSDF:

- Base Color: an sRGB image connected to Base Color.
- Metallic: a Non-Color image connected to Metallic.
- Roughness: a Non-Color image connected to Roughness.
- If only the combined map is available, its green channel provides Roughness and its blue channel provides Metallic.

The individual maps and the combined map represent the same data; they are not added together. The current painting pipeline does not generate normal, displacement, or ambient occlusion maps. The material does not invent this information. The mesh retains its original UVs and uses an Alpha value of 1.

The GLB includes PBR materials and can be imported through File > Import > glTF 2.0. To inspect the explicit shader node connections, open the `.blend` and select the object in the Shading workspace. Use Material Preview or Rendered shading.

The `.blend` is created with or without a rig and requires Blender 4.2 or later. When rigging is enabled, it also includes the skeleton and skin weights. Check deformations before animating. Blender export failures preserve the original GLB and create a `.log` file alongside it.

Files are saved in ComfyUI's output directory, normally under `Lucas_Character/3D`. Outputs include a GLB, PNG maps, reports, and a `.blend`. The `.blend` contains its images and can be moved on its own.

## Resuming stages

- `Lucas_Retomar_PBR.json`: repaints from a saved checkpoint without rebuilding the geometry.
- `Lucas_Retomar_Rig.json`: accepts the relative path of a GLB inside the output directory. UniRig adds a rig; None prepares a `.blend` without a rig.

Older GLBs without associated PNG files retain their embedded materials. Keep each model's PNG files alongside its GLB to reconstruct the explicit material connections. Do not rename only part of the file set.

## Requirements and limitations

Windows x64, an NVIDIA/CUDA GPU, ComfyUI Desktop, and Blender 4.2 or later. Automatic profiles require approximately 16 GB of VRAM and 32 GB of RAM. Models and generation may require more memory. The app does not guarantee animation-ready retopology or remove artifacts already present in the mesh or textures. Connecting materials does not increase image resolution.

## Support development

Enjoyed bringing your idea to life? If this app helped you, you can buy me a coffee and help me keep building free AI tools. Your support means a lot!

[Support Lucas on Ko-fi](https://ko-fi.com/lucasdlugoss)

Contributions are completely optional and do not unlock or restrict any app features or downloads.

## Licenses and credits

Qwen, Hunyuan3D, UniRig, ComfyUI, and Blender retain their own licenses. See `THIRD_PARTY_NOTICES.txt` and the licenses of the installed components. Model weights and binaries are downloaded from their distributors and are not included in this package.

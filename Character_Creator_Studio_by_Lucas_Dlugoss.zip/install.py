"""Updater for Lucas/ComfyUI Windows installation with automatic requirements and PBR setup."""
import argparse
import ast
from datetime import datetime
import importlib
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import uuid

PACKAGE = Path(__file__).resolve().parent
WORKFLOW = 'Qwen_Character_Approval_3Views_Offline.json'
NODEPACK = 'ComfyUI-Lucas-Character-Approval'


def patch_pipeline(text):
    old = '        posterior = self.vae.encode(images.to(dtype)).latent_dist'
    new = """        images = images.to(
            device=self._execution_device,
            dtype=dtype,
        )
        posterior = self.vae.encode(images).latent_dist"""
    if new in text:
        return text
    if text.count(old) != 1:
        raise RuntimeError('Unrecognized pipeline.py version. No files were changed. Share the file to adapt the patch.')
    return text.replace(old, new)


def patch_multiview(text):
    for operation in ('slicing', 'tiling'):
        old = f'        self.pipeline.enable_vae_{operation}()'
        if old in text:
            new = (f'        if callable(getattr(self.pipeline.vae, "enable_{operation}", None)):\n'
                   f'            self.pipeline.vae.enable_{operation}()\n'
                   f'        else:\n'
                   f'            print("[Hunyuan PBR] VAE {operation} unavailable.")')
            text = text.replace(old, new)
        elif f'"enable_{operation}"' not in text and f"'enable_{operation}'" not in text:
            raise RuntimeError(f'multiview_utils.py: VAE {operation} not recognized; no files changed.')
    text = text.replace('        self.pipeline = pipeline.to(self.device)', '        self.pipeline = pipeline')
    return text


def ensure_node_requirements():
    """Install lightweight Python requirements for ComfyUI-Lucas-Character-Approval preserving Torch/numpy."""
    req_file = PACKAGE / NODEPACK / 'requirements.txt'
    if not req_file.is_file():
        return
    missing = []
    for mod_name in ('trimesh', 'fast_simplification', 'xatlas', 'psutil'):
        try:
            importlib.import_module(mod_name)
        except Exception:
            missing.append(mod_name)
    if not missing:
        return
    print('Installing Lucas node pack Python dependencies:', ', '.join(missing), flush=True)
    protected = {}
    for name in ('torch', 'torchvision', 'torchaudio', 'numpy'):
        try:
            protected[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            pass
    with tempfile.TemporaryDirectory(prefix='lucas_node_constraints_') as directory:
        constraints = Path(directory) / 'constraints.txt'
        constraints.write_text(''.join(f'{name}=={version}\n' for name, version in protected.items()), encoding='utf-8')
        subprocess.run([sys.executable, '-m', 'pip', 'install', '-r', str(req_file), '-c', str(constraints)], check=True)


def install(root, check_dependencies=True):
    root = Path(root).resolve()
    if not (root / 'main.py').is_file() and not (root / 'custom_nodes').is_dir():
        raise RuntimeError('Invalid ComfyUI folder: ' + str(root))
    for path in (PACKAGE / NODEPACK).rglob('*.py'):
        ast.parse(path.read_text(encoding='utf-8'), filename=str(path))
    json.loads((PACKAGE / WORKFLOW).read_text(encoding='utf-8'))

    if check_dependencies:
        ensure_node_requirements()

    dest = root / 'custom_nodes' / NODEPACK
    workflow_dest = root / 'user/default/workflows' / WORKFLOW
    backup = root / 'lucas_backups' / (datetime.now().strftime('%Y%m%d_%H%M%S') + '_' + uuid.uuid4().hex[:8])
    backup.mkdir(parents=True, exist_ok=True)

    # First copy ComfyUI-Lucas-Character-Approval so tools/install_pbr.py is inside custom_nodes if needed
    changes = {
        dest / p.relative_to(PACKAGE / NODEPACK): p.read_bytes()
        for p in (PACKAGE / NODEPACK).rglob('*')
        if p.is_file() and '__pycache__' not in p.parts
    }
    changes[workflow_dest] = (PACKAGE / WORKFLOW).read_bytes()
    changes[workflow_dest.parent / 'Lucas_Retomar_PBR.json'] = (PACKAGE / 'Lucas_Retomar_PBR.json').read_bytes()
    changes[workflow_dest.parent / 'Lucas_Retomar_Rig.json'] = (PACKAGE / 'Lucas_Retomar_Rig.json').read_bytes()

    prior = {}
    for path in list(changes):
        prior[path] = path.read_bytes() if path.exists() else None
        if prior[path] is not None:
            saved = backup / path.relative_to(root)
            saved.parent.mkdir(parents=True, exist_ok=True)
            saved.write_bytes(prior[path])

    try:
        for path, content in changes.items():
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
    except Exception:
        for path, content in prior.items():
            if content is None:
                path.unlink(missing_ok=True)
            else:
                path.write_bytes(content)
        raise

    if check_dependencies:
        code = (
            'import torch; import xatlas; import trimesh; import fast_simplification; import psutil; '
            'print("Core mesh dependencies: OK | CUDA available:", torch.cuda.is_available())'
        )
        subprocess.run([sys.executable, '-c', code], check=True)
        pbr_code = 'import custom_rasterizer; import custom_rasterizer_kernel; import mesh_inpaint_processor; print("PBR native extensions: OK")'
        pbr_res = subprocess.run([sys.executable, '-c', pbr_code], capture_output=True, text=True)
        if pbr_res.returncode != 0:
            print('Attempting automatic setup of Hunyuan PBR extensions (tools/install_pbr.py)...', flush=True)
            pbr_script = dest / 'tools/install_pbr.py'
            if pbr_script.is_file():
                attempt = subprocess.run([sys.executable, str(pbr_script)])
                if attempt.returncode != 0:
                    print('[Note] Optional Hunyuan PBR C++/CUDA rasterizer build skipped (requires VS 2022 C++ Build Tools + CUDA Toolkit). '
                          'UniRig rigging (Lucas_Retomar_Rig.json) will work normally.', flush=True)

    wrapper = root / 'custom_nodes/ComfyUI-Hunyuan3d-2-1/hy3dpaint'
    pipeline = wrapper / 'hunyuanpaintpbr/pipeline.py'
    multiview = wrapper / 'utils/multiview_utils.py'
    if pipeline.is_file() and multiview.is_file():
        try:
            patches = {
                pipeline: patch_pipeline(pipeline.read_text(encoding='utf-8')),
                multiview: patch_multiview(multiview.read_text(encoding='utf-8')),
            }
            for path, text in patches.items():
                ast.parse(text, filename=str(path))
            for path, text in patches.items():
                if path.exists():
                    saved = backup / path.relative_to(root)
                    saved.parent.mkdir(parents=True, exist_ok=True)
                    saved.write_bytes(path.read_bytes())
                path.write_text(text, encoding='utf-8')
                changes[path] = text.encode('utf-8')
        except Exception as exc:
            print(f'[Warning] Hunyuan 2.1 patch skipped ({exc}). Continuing with Lucas node pack and UniRig setup.', flush=True)

    (backup / 'manifest.json').write_text(
        json.dumps(
            {
                'root': str(root),
                'files': [str(p.relative_to(root)) for p in changes],
                'created': [str(p.relative_to(root)) for p, data in prior.items() if data is None],
            },
            indent=2,
        ),
        encoding='utf-8',
    )
    print('\nWORKFLOW v26 UPDATED. Automatic bootstrap will continue with UniRig dependencies and models.')
    print('Backup:', backup)
    print('Workflow:', workflow_dest)
    return backup


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--comfy-root', type=Path, required=True)
    args = parser.parse_args()
    install(args.comfy_root)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('\nINSTALLATION STOPPED:', exc, file=sys.stderr)
        sys.exit(1)

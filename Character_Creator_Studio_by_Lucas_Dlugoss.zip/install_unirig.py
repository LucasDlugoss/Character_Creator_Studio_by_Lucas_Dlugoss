"""Install the pinned ComfyUI-UniRig backend, heal comfy-env-root.toml, guard bpy teardown on Windows, and verify node registration."""
import argparse
from datetime import datetime
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile

REPO = 'https://github.com/PozzettiAndrea/ComfyUI-UniRig.git'
REVISION = '69ee59dc459d2da7cb0291930c1f944886c31d7c'
ARCHIVE_URL = f'https://github.com/PozzettiAndrea/ComfyUI-UniRig/archive/{REVISION}.zip'
REQUIRED_NODES = ('UniRigLoadModel', 'UniRigExtractSkeletonNew', 'UniRigApplySkinningMLNew')

BPY_TEARDOWN_GUARD = """# --- LUCAS_BPY_TEARDOWN_GUARD ---
import atexit as _lucas_atexit, os as _lucas_os, sys as _lucas_sys
_lucas_had_exc = False
_lucas_orig_hook = _lucas_sys.excepthook
def _lucas_excepthook(t, v, tb):
    global _lucas_had_exc
    _lucas_had_exc = True
    _lucas_orig_hook(t, v, tb)
_lucas_sys.excepthook = _lucas_excepthook
def _lucas_clean_exit():
    if not _lucas_had_exc and ' WORKER' not in ' '.join(_lucas_sys.argv).upper():
        try:
            _lucas_sys.stdout.flush()
            _lucas_sys.stderr.flush()
        except Exception:
            pass
        _lucas_os._exit(0)
_lucas_atexit.register(_lucas_clean_exit)
# --- END LUCAS_BPY_TEARDOWN_GUARD ---
"""


def run(command, **kwargs):
    print('Running:', ' '.join(map(str, command)), flush=True)
    subprocess.run(list(map(str, command)), check=True, **kwargs)


def run_streaming(command, cwd=None, env=None):
    """Run a command streaming stdout/stderr live while capturing output for error inspection."""
    print('Running:', ' '.join(map(str, command)), flush=True)
    captured = []
    with subprocess.Popen(
        list(map(str, command)),
        cwd=str(cwd) if cwd else None,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding='utf-8',
        errors='replace',
    ) as proc:
        try:
            for line in proc.stdout:
                print(line, end='', flush=True)
                captured.append(line)
            code = proc.wait()
        except BaseException:
            proc.terminate()
            proc.wait()
            raise
    return code, ''.join(captured)


def clear_stale_metadata_caches(target, comfy_env_root=None):
    """Remove stale .metadata_cache.pkl files before scanning so ComfyUI-UniRig builds a fresh cache."""
    roots = [Path(target)]
    if comfy_env_root and Path(comfy_env_root).is_dir():
        roots.append(Path(comfy_env_root))
    localappdata = os.environ.get('LOCALAPPDATA')
    if localappdata:
        ce = Path(localappdata) / 'Programs' / 'comfy-env'
        if ce.is_dir():
            roots.append(ce)
    for base in roots:
        for cache_file in base.rglob('.metadata_cache.pkl'):
            try:
                cache_file.unlink()
                print('Cleared stale metadata cache:', cache_file, flush=True)
            except OSError:
                pass


def restore_or_heal_root_toml(target, mode='modern'):
    """Ensure comfy-env-root.toml matches the active comfy-env schema."""
    root_toml = Path(target) / 'comfy-env-root.toml'
    backup_toml = Path(target) / 'comfy-env-root.toml.lucas-orig'
    if not root_toml.is_file():
        return
    if not backup_toml.is_file():
        backup_toml.write_bytes(root_toml.read_bytes())
    orig_text = backup_toml.read_text(encoding='utf-8')
    if mode == '0.4.1':
        root_toml.write_text(orig_text, encoding='utf-8')
    elif mode == 'minimal':
        # Keep only [types] if [node_packs] causes external clone issues
        lines = orig_text.splitlines(keepends=True)
        out = []
        keep_section = False
        for line in lines:
            stripped = line.strip()
            if stripped.startswith('[') and stripped.endswith(']'):
                sec = stripped[1:-1].strip()
                keep_section = (sec == 'types' or sec.startswith('types.'))
            if keep_section:
                out.append(line)
        root_toml.write_text(''.join(out), encoding='utf-8')
    else:
        # Strip [dependencies] / [settings] sections and rename [node_reqs] -> [node_packs] for comfy-env >= 0.4.25
        lines = orig_text.splitlines(keepends=True)
        out = []
        skip_section = False
        for line in lines:
            stripped = line.strip()
            if stripped.startswith('[') and stripped.endswith(']'):
                sec = stripped[1:-1].strip()
                if sec in ('dependencies', 'settings') or sec.startswith('dependencies.') or sec.startswith('settings.'):
                    skip_section = True
                    continue
                skip_section = False
                if sec == 'node_reqs':
                    line = line.replace('[node_reqs]', '[node_packs]')
            if not skip_section:
                out.append(line)
        root_toml.write_text(''.join(out), encoding='utf-8')


def inject_bpy_teardown_guard(target, comfy_env_root=None):
    """Prevent Windows 0xC0000005 Access Violation on bpy exit during comfy-env metadata scan (Issues #74 & #75)."""
    target = Path(target)
    nodes_init = target / 'nodes' / '__init__.py'
    if nodes_init.is_file():
        backup_init = target / 'nodes' / '__init__.py.lucas-orig'
        if not backup_init.is_file():
            backup_init.write_bytes(nodes_init.read_bytes())
        text = backup_init.read_text(encoding='utf-8')
        if 'LUCAS_BPY_TEARDOWN_GUARD' not in text:
            nodes_init.write_text(BPY_TEARDOWN_GUARD + '\n' + text, encoding='utf-8')


def patch_installed_comfy_env():
    """Patch comfy_env metadata scanner in site-packages so a teardown fault after writing output never discards metadata."""
    try:
        import comfy_env
        ce_root = Path(comfy_env.__file__).resolve().parent
        for py_file in ce_root.rglob('*.py'):
            text = py_file.read_text(encoding='utf-8', errors='ignore')
            # Look for subprocess metadata scan where returncode != 0 discards stdout containing marker
            if 'returncode' in text and ('METADATA' in text or 'scan' in py_file.name or 'metadata' in py_file.name):
                # Inject os._exit(0) into inline scan child script if it prints json/pickle payload
                if 'sys.stdout.flush()' in text and 'os._exit(0)' not in text:
                    patched = text.replace('sys.stdout.flush()', 'sys.stdout.flush(); import os as _os; _os._exit(0)')
                    try:
                        compile(patched, str(py_file), 'exec')
                        py_file.write_text(patched, encoding='utf-8')
                        print('Patched comfy_env scanner child exit in:', py_file.name, flush=True)
                    except Exception:
                        pass
    except Exception as exc:
        print('[Note] comfy_env scanner inspection note:', exc, flush=True)


def verify_and_cache_unirig_nodes(root, target, env):
    """Run prestartup_script.py + __init__.py in a subprocess to populate .metadata_cache.pkl and confirm all UniRig nodes load."""
    check_code = (
        "import sys, json, importlib.util, pathlib\n"
        f"root = pathlib.Path({repr(str(root))})\n"
        f"target = pathlib.Path({repr(str(target))})\n"
        "sys.path.insert(0, str(root))\n"
        "sys.path.insert(0, str(target))\n"
        "pre = target / 'prestartup_script.py'\n"
        "if pre.is_file():\n"
        "    ps = importlib.util.spec_from_file_location('unirig_prestartup', str(pre))\n"
        "    pm = importlib.util.module_from_spec(ps); ps.loader.exec_module(pm)\n"
        "spec = importlib.util.spec_from_file_location('ComfyUI_UniRig', str(target / '__init__.py'))\n"
        "mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)\n"
        "keys = list((getattr(mod, 'NODE_CLASS_MAPPINGS', None) or {}).keys())\n"
        "print('LUCAS_REGISTERED_UNIRIG_NODES:' + json.dumps(keys))\n"
    )
    code, out = run_streaming([sys.executable, '-c', check_code], cwd=target, env=env)
    registered = []
    for line in out.splitlines():
        if 'LUCAS_REGISTERED_UNIRIG_NODES:' in line:
            try:
                registered = json.loads(line.split('LUCAS_REGISTERED_UNIRIG_NODES:', 1)[1].strip())
            except Exception:
                pass
    missing = [n for n in REQUIRED_NODES if n not in registered]
    return len(missing) == 0, registered, missing


def fetch_unirig_checkout(root, target):
    """Ensure custom_nodes/ComfyUI-UniRig is at REVISION, backing up any dirty/conflicting folder outside custom_nodes."""
    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        for rel in ('comfy-env-root.toml', 'nodes/__init__.py'):
            bak = target / (rel + '.lucas-orig')
            if bak.is_file():
                (target / rel).write_bytes(bak.read_bytes())
                bak.unlink(missing_ok=True)
        needs_replace = False
        try:
            revision = subprocess.check_output(['git', '-C', str(target), 'rev-parse', 'HEAD'], text=True, stderr=subprocess.DEVNULL).strip()
            dirty = subprocess.check_output(
                ['git', '-C', str(target), 'status', '--porcelain', '--untracked-files=no'],
                text=True,
                stderr=subprocess.DEVNULL,
            ).strip()
            if revision != REVISION or dirty:
                needs_replace = True
        except Exception:
            needs_replace = True
        if needs_replace:
            backup_dir = root / 'lucas_backups' / ('ComfyUI-UniRig_backup_' + datetime.now().strftime('%Y%m%d_%H%M%S'))
            backup_dir.parent.mkdir(parents=True, exist_ok=True)
            print(f'Backing up existing ComfyUI-UniRig to {backup_dir} (outside custom_nodes)...', flush=True)
            shutil.move(str(target), str(backup_dir))

    if not target.exists():
        staging = Path(tempfile.mkdtemp(prefix='lucas_unirig_', dir=root))
        try:
            try:
                run(['git', 'clone', '--no-checkout', REPO, staging / 'repo'])
                run(['git', '-C', staging / 'repo', 'checkout', '--detach', REVISION])
                shutil.move(str(staging / 'repo'), str(target))
            except Exception as git_exc:
                print(f'Git clone failed ({git_exc}); falling back to direct GitHub ZIP download...', flush=True)
                zip_path = staging / 'unirig.zip'
                req = urllib.request.Request(ARCHIVE_URL, headers={'User-Agent': 'Lucas-Character-Installer/25'})
                with urllib.request.urlopen(req, timeout=60) as resp, zip_path.open('wb') as out:
                    shutil.copyfileobj(resp, out)
                extract_dir = staging / 'extracted'
                with zipfile.ZipFile(zip_path) as zf:
                    zf.extractall(extract_dir)
                subdirs = [d for d in extract_dir.iterdir() if d.is_dir()]
                if not subdirs:
                    raise RuntimeError('Downloaded ComfyUI-UniRig archive was empty.')
                shutil.move(str(subdirs[0]), str(target))
        finally:
            shutil.rmtree(staging, ignore_errors=True)


def install(root):
    root = Path(root).resolve()
    if not (root / 'main.py').is_file() and not (root / 'custom_nodes').is_dir():
        raise RuntimeError('Invalid ComfyUI root: ' + str(root))

    managed_git = root / 'lucas_tools/mingit/cmd/git.exe'
    if not shutil.which('git') and managed_git.is_file():
        os.environ['PATH'] = str(managed_git.parent) + os.pathsep + os.environ.get('PATH', '')
    if not shutil.which('git'):
        from bootstrap import ensure_git
        tools = root / 'lucas_tools'
        tools.mkdir(exist_ok=True)
        ensure_git(root, tools / 'downloads')

    try:
        importlib.metadata.version('pip')
    except importlib.metadata.PackageNotFoundError:
        run([sys.executable, '-m', 'ensurepip', '--upgrade'])

    target = root / 'custom_nodes' / 'ComfyUI-UniRig'
    fetch_unirig_checkout(root, target)

    protected = {}
    for name in ('torch', 'torchvision', 'torchaudio', 'numpy'):
        try:
            protected[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            pass

    comfy_env_root = os.environ.get('COMFY_ENV_ROOT') or str(
        Path(os.environ.get('LOCALAPPDATA', str(root / 'lucas_tools'))) / 'Programs' / 'comfy-env'
    )
    os.environ['COMFY_ENV_ROOT'] = comfy_env_root

    with tempfile.TemporaryDirectory(prefix='lucas_constraints_') as directory:
        constraints = Path(directory) / 'constraints.txt'
        constraints.write_text(''.join(f'{name}=={version}\n' for name, version in protected.items()), encoding='utf-8')
        run([sys.executable, '-m', 'pip', 'install', '-r', target / 'requirements.txt', '-c', constraints])
        # Upgrade to latest comfy-env>=0.4.46 (which fixes Windows isolation & metadata caching)
        # AND pre-heal comfy-env-root.toml BEFORE calling target/install.py!
        try:
            run([sys.executable, '-m', 'pip', 'install', '--upgrade', 'comfy-env>=0.4.46', '-c', constraints])
            restore_or_heal_root_toml(target, mode='modern')
        except Exception:
            restore_or_heal_root_toml(target, mode='0.4.1')

        inject_bpy_teardown_guard(target, comfy_env_root)
        patch_installed_comfy_env()
        clear_stale_metadata_caches(target, comfy_env_root)

        env = os.environ.copy()
        env['PYTHONUNBUFFERED'] = '1'
        env['PYTHONIOENCODING'] = 'utf-8'
        env['COMFY_ENV_ROOT'] = comfy_env_root

        last_err = None
        for attempt in range(1, 4):
            try:
                print(f'Running ComfyUI-UniRig isolated environment installer (attempt {attempt}/3)...', flush=True)
                code, output = run_streaming([sys.executable, target / 'install.py'], cwd=target, env=env)
                if code != 0:
                    if 'unsupported section(s)' in output and 'comfy-env-root.toml' in output:
                        print('Adapting comfy-env-root.toml for comfy-env schema and retrying...', flush=True)
                        restore_or_heal_root_toml(target, mode='minimal')
                    elif attempt == 2:
                        print('Trying minimal comfy-env-root.toml for attempt 3...', flush=True)
                        restore_or_heal_root_toml(target, mode='minimal')
                    raise RuntimeError(f'ComfyUI-UniRig install.py exited with code {code}')
                last_err = None
                break
            except Exception as exc:
                last_err = exc
                print(f'UniRig environment setup attempt {attempt} failed: {exc}', flush=True)
                if attempt < 3:
                    clear_stale_metadata_caches(target, comfy_env_root)
                    time.sleep(2)
        if last_err is not None:
            raise last_err

        # Now verify node registration and warm up .metadata_cache.pkl (do NOT delete the cache after warming it!)
        print('Verifying UniRig node registration and warming metadata cache...', flush=True)
        ok, registered, missing = verify_and_cache_unirig_nodes(root, target, env)
        if not ok:
            print(f'First metadata scan missed nodes {missing}; clearing cache and retrying with minimal root config...', flush=True)
            clear_stale_metadata_caches(target, comfy_env_root)
            restore_or_heal_root_toml(target, mode='minimal')
            inject_bpy_teardown_guard(target, comfy_env_root)
            ok, registered, missing = verify_and_cache_unirig_nodes(root, target, env)
        if not ok:
            print(f'Retrying with pinned comfy-env==0.4.1 + bpy teardown guard (missing: {missing})...', flush=True)
            clear_stale_metadata_caches(target, comfy_env_root)
            restore_or_heal_root_toml(target, mode='0.4.1')
            inject_bpy_teardown_guard(target, comfy_env_root)
            run([sys.executable, '-m', 'pip', 'install', 'comfy-env==0.4.1', '-c', constraints])
            patch_installed_comfy_env()
            run_streaming([sys.executable, target / 'install.py'], cwd=target, env=env)
            ok, registered, missing = verify_and_cache_unirig_nodes(root, target, env)
        if not ok:
            raise RuntimeError(
                f'ComfyUI-UniRig environment installed, but required nodes did not register: {missing} '
                f'(registered: {registered}). Check log above for comfy-env worker/scanner errors.'
            )
        print(f'Verified {len(registered)} UniRig nodes registered: {", ".join(REQUIRED_NODES)} OK!', flush=True)

    for name, version in protected.items():
        if importlib.metadata.version(name) != version:
            raise RuntimeError(f'{name} unexpectedly changed; inspect installer log before proceeding.')

    (root / 'lucas_unirig_install.json').write_text(
        json.dumps(
            {
                'repository': REPO,
                'revision': REVISION,
                'comfy_env_root': comfy_env_root,
                'registered_nodes': registered,
                'protected_main_packages': protected,
            },
            indent=2,
        ),
        encoding='utf-8',
    )
    print('UniRig backend setup and node registration verified! Restart ComfyUI and press Ctrl+F5.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--comfy-root', required=True)
    try:
        install(parser.parse_args().comfy_root)
    except Exception as exc:
        print('UNIRIG INSTALLATION STOPPED:', exc, file=sys.stderr)
        sys.exit(1)

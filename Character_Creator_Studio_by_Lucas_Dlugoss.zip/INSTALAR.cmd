@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul
title Lucas Character v26 - Auto Installer (Git + Blender 4.5 LTS + UniRig + PBR)

set "comfyRoot="
if not "%~1"=="" set "comfyRoot=%~1"

if defined comfyRoot (
    set "comfyRoot=!comfyRoot:"=!"
    if "!comfyRoot:~-1!"=="\" set "comfyRoot=!comfyRoot:~0,-1!"
    if exist "!comfyRoot!\ComfyUI\main.py" set "comfyRoot=!comfyRoot!\ComfyUI"
)

:: 1. Check ComfyUI Desktop config.json basePath first if comfyRoot not provided
if not defined comfyRoot (
    if exist "%APPDATA%\ComfyUI\config.json" (
        for /f "usebackq delims=" %%P in (`powershell -NoProfile -Command "try { $c = Get-Content -Raw '$env:APPDATA\ComfyUI\config.json' | ConvertFrom-Json; if ($c.basePath) { Write-Output $c.basePath } } catch {}"`) do (
            if exist "%%~fP\ComfyUI\main.py" (
                set "comfyRoot=%%~fP\ComfyUI"
            ) else if exist "%%~fP\.venv\Scripts\python.exe" (
                set "comfyRoot=%%~fP"
            ) else if exist "%%~fP\custom_nodes" (
                set "comfyRoot=%%~fP"
            )
            set "comfyBase=%%~fP"
        )
    )
)

:: 2. Try automatic detection across standard Desktop and Portable locations
if not defined comfyRoot (
    for %%C in (
        "%~dp0"
        "%~dp0.."
        "%~dp0..\.."
        "%LOCALAPPDATA%\Comfy-Desktop\ComfyUI-Installs\ComfyUI\ComfyUI"
        "%LOCALAPPDATA%\Comfy-Desktop\ComfyUI-Installs\ComfyUI"
        "%USERPROFILE%\Documents\ComfyUI"
        "C:\ComfyUI_windows_portable\ComfyUI"
        "D:\ComfyUI_windows_portable\ComfyUI"
        "C:\ComfyUI"
        "D:\ComfyUI"
    ) do (
        if not defined comfyRoot (
            if exist "%%~fC\main.py" set "comfyRoot=%%~fC"
            if not defined comfyRoot if exist "%%~fC\ComfyUI\main.py" set "comfyRoot=%%~fC\ComfyUI"
            if not defined comfyRoot if exist "%%~fC\.venv\Scripts\python.exe" if exist "%%~fC\custom_nodes" set "comfyRoot=%%~fC"
        )
    )
)

:: 3. Prompt user if still not found
if not exist "!comfyRoot!\main.py" (
    if not exist "!comfyRoot!\custom_nodes" (
        echo ============================================================================
        echo  Nao foi possivel detectar automaticamente a pasta do ComfyUI.
        echo  Cole abaixo o caminho da sua pasta ComfyUI ^(com ou sem aspas^):
        echo ============================================================================
        set /p "comfyRoot=Caminho (Path): "
        set "comfyRoot=!comfyRoot:"=!"
        if "!comfyRoot:~-1!"=="\" set "comfyRoot=!comfyRoot:~0,-1!"
        if exist "!comfyRoot!\ComfyUI\main.py" set "comfyRoot=!comfyRoot!\ComfyUI"
    )
)

:: 4. Locate the Python executable (.venv, parent .venv, python_embeded, or ComfyUI Desktop basePath)
set "comfyPython="
for %%P in (
    "!comfyRoot!\.venv\Scripts\python.exe"
    "!comfyRoot!\..\.venv\Scripts\python.exe"
    "!comfyRoot!\..\python_embeded\python.exe"
    "!comfyRoot!\python_embeded\python.exe"
    "!comfyBase!\.venv\Scripts\python.exe"
    "%USERPROFILE%\Documents\ComfyUI\.venv\Scripts\python.exe"
    "%LOCALAPPDATA%\Comfy-Desktop\ComfyUI-Installs\ComfyUI\.venv\Scripts\python.exe"
    "%LOCALAPPDATA%\Comfy-Desktop\ComfyUI-Installs\ComfyUI\ComfyUI\.venv\Scripts\python.exe"
) do (
    if not defined comfyPython (
        if exist "%%~fP" set "comfyPython=%%~fP"
    )
)

if not defined comfyPython (
    echo [ERRO] Python do ComfyUI ^(.venv ou python_embeded^) nao encontrado em:
    echo        "!comfyRoot!"
    echo Verifique a pasta selecionada e tente novamente.
    pause
    exit /b 1
)

echo ============================================================================
echo  LUCAS CHARACTER v26 - INSTALADOR AUTOMATICO (GIT + BLENDER 4.5 + UNIRIG)
echo  Pasta ComfyUI : "!comfyRoot!"
echo  Python ComfyUI: "!comfyPython!"
echo ============================================================================
echo  - Feche o ComfyUI antes de continuar.
echo  - O instalador vai configurar automaticamente Git, Blender 4.5.15 LTS,
echo    ComfyUI-UniRig ^(comfy-env 0.4.1 + Pixi^) e pesos do UniRig ^(2,9 GB^).
echo ============================================================================
if "%LUCAS_NONINTERACTIVE%"=="" pause

"!comfyPython!" -u "%~dp0bootstrap.py" --comfy-root "!comfyRoot!"
set "installResult=%ERRORLEVEL%"
if not "%installResult%"=="0" (
    echo.
    echo [FALHA] A instalacao encontrou um erro ^(codigo %installResult%^).
    echo Consulte o arquivo de log indicado acima na pasta lucas_install_logs.
) else (
    echo.
    echo [SUCESSO] Tudo instalado e verificado automaticamente!
)
if "%LUCAS_NONINTERACTIVE%"=="" pause
exit /b %installResult%

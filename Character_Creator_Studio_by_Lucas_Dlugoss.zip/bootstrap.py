"""Windows automatic bootstrap for Lucas/ComfyUI, portable Git, portable Blender 4.5 LTS, and UniRig backend."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile

PACKAGE = Path(__file__).resolve().parent
GIT_URL = 'https://github.com/git-for-windows/git/releases/download/v2.56.0.windows.4/MinGit-2.56.0.4-64-bit.zip'
GIT_SHA = 'e3bf78351fe777fba47ddee5950082f8a98bb0f02604fdc7ba3ee2cb68ffa877'
BLENDER_URL = 'https://download.blender.org/release/Blender4.5/blender-4.5.15-windows-x64.zip'
BLENDER_SHA = '52dd02fd74877fa08e74b67d7854cf32568a232c02aaa19b6844c91285574f8d'


def checksum(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1025 * 1025), b''):
            digest.update(block)
    return digest.hexdigest()


def fetch_json(url):
    request = urllib.request.Request(url, headers={'User-Agent': 'Lucas-Character-Installer/25'})
    with urllib.request.urlopen(request, timeout=60) as response:
        return json.load(response)


def download(url, path, sha, size=None):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not re.fullmatch('[0-9a-f]{64}', sha):
        raise ValueError('Missing trusted SHA256 for ' + path.name)
    if path.is_file():
        print('Checking existing file:', path.name, flush=True)
    if path.is_file() and (size is None or path.stat().st_size == size) and checksum(path) == sha:
        print('Already verified:', path.name, flush=True)
        return path
    part = path.with_name(path.name + '.part')
    for attempt in range(3):
        try:
            offset = part.stat().st_size if part.exists() else 0
            if offset and size is not None and offset >= size:
                if offset == size and checksum(part) == sha:
                    os.replace(part, path)
                    return path
                part.unlink()
                offset = 0
            headers = {'User-Agent': 'Lucas-Character-Installer/25'}
            if offset:
                headers['Range'] = f'bytes={offset}-'
            request = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(request, timeout=60) as response:
                resumed = response.status == 206
                if resumed and not response.headers.get('Content-Range', '').startswith(f'bytes {offset}-'):
                    raise RuntimeError('Invalid server resume offset.')
                if not resumed:
                    offset = 0
                total = size or offset + int(response.headers.get('Content-Length', '0'))
                done = offset
                last = 0.0
                with part.open('ab' if resumed else 'wb') as output:
                    while True:
                        block = response.read(1025 * 1025)
                        if not block:
                            break
                        output.write(block)
                        done += len(block)
                        if time.monotonic() - last > 5:
                            print(f'Downloading {path.name}: {done / 1048576:.0f} / {total / 1048576:.0f} MB', flush=True)
                            last = time.monotonic()
            print('Verifying SHA256:', path.name, flush=True)
            if (size is not None and part.stat().st_size != size) or checksum(part) != sha:
                part.unlink(missing_ok=True)
                raise RuntimeError('Download integrity check failed: ' + path.name)
            os.replace(part, path)
            return path
        except Exception:
            if attempt == 2:
                raise
            print('Download interrupted; retrying with resume where supported.', flush=True)
    raise RuntimeError('Download failed.')


def unpack(archive, destination):
    destination = Path(destination).resolve()
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as source:
        for item in source.infolist():
            target = (destination / item.filename.replace('\\', '/')).resolve()
            if not target.is_relative_to(destination):
                raise ValueError('Unsafe archive path.')
            if (item.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError('Archive symlinks not allowed.')
        source.extractall(destination)


def program_version(executable, pattern, minimum=None, maximum=None):
    try:
        result = subprocess.run([str(executable), '--version'], capture_output=True, text=True, timeout=20, check=True)
        output = (result.stdout or '') + '\n' + (result.stderr or '')
        match = re.search(pattern, output)
        if not match:
            return False
        ver = tuple(map(int, match.groups()))
        if minimum is not None and ver < minimum:
            return False
        if maximum is not None and ver > maximum:
            return False
        return True
    except (OSError, subprocess.SubprocessError):
        return False


def user_path_add(directory):
    """Make portable tools available to later Desktop launches, without admin rights."""
    if os.name != 'nt':
        return
    try:
        import winreg
        value = str(directory)
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, 'Environment') as key:
            try:
                old, kind = winreg.QueryValueEx(key, 'Path')
            except FileNotFoundError:
                old, kind = '', winreg.REG_EXPAND_SZ
            entries = [item for item in old.split(';') if item]
            if os.path.normcase(value.rstrip('\\/')) not in [os.path.normcase(item.rstrip('\\/')) for item in entries]:
                winreg.SetValueEx(key, 'Path', 0, kind, ';'.join(entries + [value]))
    except Exception:
        pass
    try:
        import ctypes
        result = ctypes.c_size_t()
        notify = ctypes.windll.user32.SendMessageTimeoutW
        notify.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_uint, ctypes.c_uint, ctypes.POINTER(ctypes.c_size_t)]
        notify.restype = ctypes.c_void_p
        name = ctypes.c_wchar_p('Environment')
        notify(0xffff, 0x1a, 0, ctypes.cast(name, ctypes.c_void_p), 2, 5000, ctypes.byref(result))
    except Exception:
        pass


def ensure_vc_runtime(cache):
    """Official Microsoft runtime, invoked only if a portable executable cannot start."""
    exe = cache / 'vc_redist.x64.exe'
    print('Preparing Microsoft Visual C++ runtime. Windows may request administrator approval.', flush=True)
    request = urllib.request.Request('https://aka.ms/vc14/vc_redist.x64.exe', headers={'User-Agent': 'Lucas-Character-Installer/25'})
    with urllib.request.urlopen(request, timeout=60) as response, exe.open('wb') as stream:
        shutil.copyfileobj(response, stream)
    env = {**os.environ, 'LUCAS_VC_REDIST': str(exe)}
    signature = "$s=Get-AuthenticodeSignature -LiteralPath $env:LUCAS_VC_REDIST; if ($s.Status -ne 'Valid' -or $s.SignerCertificate.Subject -notmatch 'O=Microsoft Corporation') { exit 1 }"
    subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', signature], env=env, check=True)
    launch = "$ErrorActionPreference='Stop'; $p=Start-Process -FilePath $env:LUCAS_VC_REDIST -ArgumentList '/install','/passive','/norestart' -Verb RunAs -Wait -PassThru; exit $p.ExitCode"
    result = subprocess.run(['powershell.exe', '-NoProfile', '-Command', launch], env=env)
    if result.returncode == 3010:
        raise RuntimeError('Microsoft runtime installed; Windows requires a restart. Restart Windows and run this installer again.')
    if result.returncode not in (0, 1638):
        raise RuntimeError('Microsoft runtime installation did not complete; code ' + str(result.returncode))


def ensure_git(root, cache):
    managed = root / 'lucas_tools' / 'mingit' / 'cmd' / 'git.exe'
    candidates = [shutil.which('git'), managed]
    for prefix in [os.environ.get('ProgramFiles'), os.environ.get('ProgramFiles(x86)'), os.environ.get('LOCALAPPDATA')]:
        if prefix:
            candidates.extend([Path(prefix) / 'Git/cmd/git.exe', Path(prefix) / 'Programs/Git/cmd/git.exe'])
    git = next((Path(p) for p in candidates if p and program_version(p, r'git version')), None)
    if git is None:
        archive = download(GIT_URL, cache / 'mingit.zip', GIT_SHA)
        (root / 'lucas_tools').mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='git_', dir=root / 'lucas_tools') as temp:
            unpack(archive, temp)
            source = Path(temp)
            if not program_version(source / 'cmd/git.exe', r'git version'):
                ensure_vc_runtime(cache)
                if not program_version(source / 'cmd/git.exe', r'git version'):
                    raise RuntimeError('Downloaded Git did not start even after runtime setup.')
            if managed.parent.parent.exists():
                backup = managed.parent.parent.with_name('mingit_backup_' + str(time.time_ns()))
                shutil.move(managed.parent.parent, backup)
            shutil.move(str(source), managed.parent.parent)
        git = managed
    os.environ['PATH'] = str(git.parent) + os.pathsep + os.environ.get('PATH', '')
    user_path_add(git.parent)
    print('Git ready:', git, flush=True)
    return git


def ensure_blender(root, cache):
    """Ensure a compatible Blender 4.2-4.5 LTS is ready; if only Blender 5.x or none is present, install portable Blender 4.5.15 LTS."""
    candidates = [os.environ.get('LUCAS_BLENDER')]
    candidates.extend(sorted((root / 'lucas_tools' / 'blender').glob('blender-*/blender.exe'), reverse=True))
    candidates.append(shutil.which('blender'))
    for prefix in [os.environ.get('ProgramFiles'), os.environ.get('LOCALAPPDATA')]:
        if prefix:
            candidates.extend(sorted(Path(prefix).glob('Blender Foundation/Blender 4.*/blender.exe'), reverse=True))
    blender = next((Path(p) for p in candidates if p and program_version(p, r'Blender (\d+)\.(\d+)', (4, 2), (4, 99))), None)
    if blender is None:
        print('Downloading portable Blender 4.5.15 LTS for ComfyUI-Lucas...', flush=True)
        archive = download(BLENDER_URL, cache / 'blender-4.5.15.zip', BLENDER_SHA)
        dest = root / 'lucas_tools' / 'blender'
        dest.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='blender_', dir=root / 'lucas_tools') as temp:
            unpack(archive, temp)
            extracted = list(Path(temp).glob('blender-*/blender.exe'))
            folder = extracted[0].parent if extracted else Path(temp) / 'blender-4.5.15-windows-x64'
            if not program_version(folder / 'blender.exe', r'Blender (\d+)\.(\d+)', (4, 2)):
                ensure_vc_runtime(cache)
                if not program_version(folder / 'blender.exe', r'Blender (\d+)\.(\d+)', (4, 2)):
                    raise RuntimeError('Downloaded Blender did not start even after runtime setup.')
            final = dest / folder.name
            if final.exists():
                shutil.move(final, final.with_name(final.name + '_backup_' + str(time.time_ns())))
            shutil.move(folder, final)
            blender = final / 'blender.exe'
    os.environ['LUCAS_BLENDER'] = str(blender)
    os.environ['PATH'] = str(blender.parent) + os.pathsep + os.environ.get('PATH', '')
    user_path_add(blender.parent)
    print('Blender ready:', blender, flush=True)
    return blender


def resolve_comfy_python(root):
    """Locate the Python executable for Desktop (.venv), split Desktop, or Portable (python_embeded)."""
    root = Path(root).resolve()
    candidates = [
        root / '.venv/Scripts/python.exe',
        root.parent / '.venv/Scripts/python.exe',
        root.parent / 'python_embeded/python.exe',
        root / 'python_embeded/python.exe',
        root / '.venv/bin/python',
        root.parent / '.venv/bin/python',
    ]
    appdata = os.environ.get('APPDATA')
    if appdata:
        cfg = Path(appdata) / 'ComfyUI/config.json'
        if cfg.is_file():
            try:
                base = Path(json.loads(cfg.read_text(encoding='utf-8')).get('basePath', ''))
                if base.is_dir():
                    candidates.append(base / '.venv/Scripts/python.exe')
            except Exception:
                pass
    for cand in candidates:
        if cand.is_file():
            return cand
    if Path(sys.executable).is_file():
        return Path(sys.executable)
    raise RuntimeError('ComfyUI Python executable (.venv or python_embeded) not found for: ' + str(root))


def run(command, log, check=True):
    print('Running:', ' '.join(map(str, command)), flush=True)
    with subprocess.Popen(
        list(map(str, command)),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding='utf-8',
        errors='replace',
        env={**os.environ, 'PYTHONUNBUFFERED': '1', 'PYTHONIOENCODING': 'utf-8'},
    ) as process:
        try:
            for line in process.stdout:
                print(line, end='', flush=True)
                log.write(line)
                log.flush()
            code = process.wait()
            if code and check:
                raise RuntimeError(f'Command failed with exit code {code}: {command[0]} (see installation log)')
            return code
        except BaseException:
            process.terminate()
            process.wait()
            raise


def download_models(root):
    repo = 'apozz/UniRig-safetensors'
    revision = 'd0ba4ef9784eee71dd88b47d207f0c2c8f9dd623'
    directory = root / 'models' / 'unirig'
    result = {}
    weights = {
        'skeleton.safetensors': ('013bc852dec0ab9d5a89ce4be68d0993046f4a61f90ab1e94bdd944cb3ed6003', 1440598432),
        'skin.safetensors': ('e1fafb94b26acb0b6e096e165c650448ea1cd4b04d2e1f23e05611e3998060c9', 1458123556),
    }
    for name, (sha, size) in weights.items():
        download('https://huggingface.co/' + repo + '/resolve/' + revision + '/' + name, directory / name, sha, size)
        result[name] = {'sha256': sha, 'size': size}
    return {'repository': repo, 'revision': revision, 'files': result, 'directory': str(directory)}


def install(root, backend_only=False):
    root = Path(root).resolve()
    if os.name != 'nt' or platform.machine().lower() not in ('amd64', 'x86_64'):
        raise RuntimeError('This automatic bootstrap targets Windows x64.')
    if not (root / 'main.py').is_file() and not (root / 'custom_nodes').is_dir():
        raise RuntimeError('An existing ComfyUI installation is required. Select its ComfyUI folder.')
    python = resolve_comfy_python(root)
    (root / 'lucas_tools').mkdir(parents=True, exist_ok=True)
    cache = root / 'lucas_tools/downloads'
    cache.mkdir(parents=True, exist_ok=True)
    logs = root / 'lucas_install_logs'
    logs.mkdir(parents=True, exist_ok=True)
    logpath = logs / ('install_v26_' + time.strftime('%Y%m%d_%H%M%S') + '.log')
    with logpath.open('w', encoding='utf-8') as log:
        print('Installation log:', logpath, flush=True)
        try:
            run([python, '-m', 'ensurepip', '--upgrade'], log, check=False)
            git = ensure_git(root, cache)
            blender = ensure_blender(root, cache)
            comfy_env_root = os.environ.get('COMFY_ENV_ROOT') or str(
                Path(os.environ.get('LOCALAPPDATA', str(root / 'lucas_tools'))) / 'Programs' / 'comfy-env'
            )
            os.environ['COMFY_ENV_ROOT'] = comfy_env_root
            config = {'git': str(git), 'blender': str(blender), 'python': str(python), 'comfy_env_root': comfy_env_root}
            configpath = root / 'lucas_tools/tools.json'
            tmp = configpath.with_suffix('.tmp')
            tmp.write_text(json.dumps(config, indent=2), encoding='utf-8')
            os.replace(tmp, configpath)
            if not backend_only:
                run([python, PACKAGE / 'install.py', '--comfy-root', root], log)
            run([python, PACKAGE / 'install_unirig.py', '--comfy-root', root], log)
            config['models'] = download_models(root)
            tmp.write_text(json.dumps(config, indent=2), encoding='utf-8')
            os.replace(tmp, configpath)
            pip_code = run([python, '-m', 'pip', 'check'], log, check=False)
            if pip_code:
                print('Note: pip check reported third-party package warnings (logged for reference; installation succeeded).', flush=True)
            print('SETUP COMPLETE. Fully exit and reopen ComfyUI. Reload the browser (Ctrl+F5) and import the JSON workflow.', flush=True)
            print('Git, Blender 4.5.15 LTS, UniRig backend, and model weights verified. Run Lucas_Retomar_Rig.json to test GPU inference.', flush=True)
            log.write('SETUP COMPLETE. All tools and model weights verified.\n')
        except BaseException as exc:
            log.write('\nINSTALLATION FAILED: ' + str(exc) + '\n')
            log.flush()
            print('INSTALLATION STOPPED:', exc, '\nKeep this log:', logpath, flush=True)
            raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--comfy-root', required=True)
    parser.add_argument('--backend-only', action='store_true')
    args = parser.parse_args()
    try:
        install(args.comfy_root, args.backend_only)
    except Exception:
        sys.exit(1)

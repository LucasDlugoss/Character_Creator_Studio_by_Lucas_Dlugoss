"""UniRig graph integration. Never substitutes template bones or distance weights."""
import json
import functools
import re
import os
from pathlib import Path
import shutil
import subprocess
import time
import uuid

REQUIRED_NODES = ('UniRigLoadModel', 'UniRigExtractSkeletonNew', 'UniRigApplySkinningMLNew')
UNIRIG_REVISION = '69ee59dc459d2da7cb0291930c1f944886c31d7c'


def find_blender():
    root_dir = Path(__file__).resolve().parents[2]
    managed = root_dir / 'lucas_tools' / 'tools.json'
    if managed.is_file():
        try:
            selected = Path(json.loads(managed.read_text(encoding='utf-8'))['blender'])
            if selected.is_file(): return str(selected)
        except (ValueError,KeyError,OSError): pass
    portable = sorted((root_dir / 'lucas_tools' / 'blender').glob('blender-*/blender.exe'), reverse=True)
    if portable and portable[0].is_file():
        return str(portable[0])
    explicit = os.environ.get('LUCAS_BLENDER', '')
    if explicit and Path(explicit).is_file(): return explicit
    found = shutil.which('blender')
    if found: return found
    paths = []
    for base in [os.environ.get('ProgramFiles', 'C:/Program Files'), os.environ.get('LOCALAPPDATA', '')]:
        if base: paths.extend(Path(base).glob('Blender Foundation/Blender */blender.exe'))
    if paths: return str(sorted(paths, key=lambda p: p.stat().st_mtime, reverse=True)[0])
    raise RuntimeError('Install Blender 4.2+ or set LUCAS_BLENDER. Disable rig to continue without it.')


@functools.lru_cache(maxsize=4)
def check_blender_version(executable, modified):
    result=subprocess.run([executable,'--version'],capture_output=True,text=True,timeout=15,check=True)
    match=re.search(r'Blender (\d+)\.(\d+)',result.stdout)
    if not match or tuple(map(int,match.groups()))<(4,2):
        raise RuntimeError('Blender 4.2 or newer is required.')


def _try_register_unirig_dynamically(nodes_module):
    unirig_dir = Path(__file__).resolve().parents[1] / 'ComfyUI-UniRig'
    if not unirig_dir.is_dir():
        return
    try:
        import importlib.util
        init_py = unirig_dir / '__init__.py'
        if init_py.is_file():
            spec = importlib.util.spec_from_file_location('comfyui_unirig_dynamic', init_py)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            mappings = getattr(mod, 'NODE_CLASS_MAPPINGS', None) or {}
            names = getattr(mod, 'NODE_DISPLAY_NAME_MAPPINGS', None) or {}
            if mappings:
                nodes_module.NODE_CLASS_MAPPINGS.update(mappings)
                nodes_module.NODE_DISPLAY_NAME_MAPPINGS.update(names)
    except Exception as exc:
        print('[Lucas UniRig dynamic load warning]', exc, flush=True)


def check_unirig():
    import nodes
    missing = [name for name in REQUIRED_NODES if name not in nodes.NODE_CLASS_MAPPINGS]
    if missing:
        _try_register_unirig_dynamically(nodes)
        missing = [name for name in REQUIRED_NODES if name not in nodes.NODE_CLASS_MAPPINGS]
    if missing:
        raise RuntimeError('UniRig nodes unavailable: '+', '.join(missing)+'. Run INSTALAR.cmd, restart ComfyUI, and inspect the startup log.')
    executable=find_blender()
    check_blender_version(executable, Path(executable).stat().st_mtime_ns)


def output_path(value, suffix=None):
    import folder_paths
    root = Path(folder_paths.get_output_directory()).resolve()
    path = (root / value).resolve()
    if not path.is_relative_to(root) or (suffix and path.suffix.lower() != suffix):
        raise ValueError('Rig files must remain inside the ComfyUI output folder.')
    return root, path


def export_blender_materials(glb_path):
    import comfy.model_management as mm
    _, source = output_path(glb_path, '.glb')
    if not source.is_file(): raise FileNotFoundError(source)
    # Unique working file prevents a failed export from replacing an earlier result.
    target = source.with_suffix('.blend')
    temp = target.with_name(target.stem + '_' + uuid.uuid4().hex[:8] + '.blend')
    log = source.with_suffix('.materials.log')
    script = Path(__file__).parent / 'tools' / 'blender_materials.py'
    command = [find_blender(), '--background', '--factory-startup', '--python-exit-code', '1',
               '--python', str(script), '--', str(source), str(temp)]
    with log.open('w', encoding='utf-8') as stream:
        proc = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT)
        started = time.monotonic()
        try:
            while proc.poll() is None:
                mm.throw_exception_if_processing_interrupted()
                if time.monotonic() - started > 600: raise RuntimeError('Blender material export timed out.')
                time.sleep(.2)
        except BaseException:
            proc.terminate()
            try: proc.wait(timeout=10)
            except subprocess.TimeoutExpired: proc.kill(); proc.wait()
            raise
    if proc.returncode or not temp.is_file():
        raise RuntimeError(f'Blender material export failed; GLB preserved. Log: {log}')
    temp.replace(target)
    report = temp.with_suffix('.materials.json')
    if report.is_file(): report.replace(source.with_suffix('.materials.json'))


class LucasAutomaticRig:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required': {'glb_path': ('STRING', {'forceInput': True}),
                             'rig_preset': (['None', 'UniRig'], {'default': 'None'}),
                             'seed': ('INT', {'default': 42, 'min': 0, 'max': 4294967295, 'control_after_generate': False})}}
    RETURN_TYPES = ('STRING',)
    RETURN_NAMES = ('glb_path',)
    FUNCTION = 'run'
    CATEGORY = 'Lucas/Character'
    OUTPUT_NODE = True
    @classmethod
    def VALIDATE_INPUTS(cls, rig_preset):
        if rig_preset != 'None':
            try: check_unirig()
            except Exception as exc: return str(exc)
        return True
    def run(self, glb_path, rig_preset='None', seed=42):
        if rig_preset == 'None':
            export_blender_materials(glb_path)
            return {'ui': {'lucas_result': [glb_path], 'lucas_blend': [glb_path[:-4]+'.blend']}, 'result': (glb_path,)}
        if rig_preset != 'UniRig': raise ValueError('Import the v21 JSON. Legacy template rig is disabled.')
        check_unirig()
        from comfy_execution.graph_utils import GraphBuilder
        root, source = output_path(glb_path, '.glb')
        if not source.is_file(): raise FileNotFoundError(source)
        job = uuid.uuid4().hex[:12]
        g = GraphBuilder()
        mesh = g.node('LucasUniRigMesh', glb_path=glb_path)
        model = g.node('UniRigLoadModel', precision='auto', attn_backend='sdpa')
        split = g.node('LucasUniRigModels', model=model.out(0))
        skeleton = g.node('UniRigExtractSkeletonNew', trimesh=mesh.out(0), skeleton_model=split.out(0),
                          seed=int(seed), skeleton_template='articulationxl', target_face_count=50000, debug=False)
        checked = g.node('LucasUniRigValidateSkeleton', normalized_mesh=skeleton.out(0), skeleton=skeleton.out(1),
                         source_path=glb_path, job=job, seed=int(seed))
        skin = g.node('UniRigApplySkinningMLNew', normalized_mesh=checked.out(0), skeleton=checked.out(1),
                      skinning_model=split.out(1), fbx_name='lucas_unirig_'+job,
                      voxel_grid_size=196, num_samples=32768, vertex_samples=8192, voxel_mask_power=0.5, debug=False)
        final = g.node('LucasUniRigFinalize', source_path=glb_path, fbx_path=skin.out(0), metadata_path=checked.out(2))
        return {'ui': {'lucas_result': [glb_path]}, 'result': (final.out(0),), 'expand': g.finalize()}


class LucasUniRigMesh:
    @classmethod
    def INPUT_TYPES(cls): return {'required': {'glb_path': ('STRING',)}}
    RETURN_TYPES = ('TRIMESH',)
    FUNCTION = 'load'
    CATEGORY = 'Lucas/Character/Internal'
    def load(self, glb_path):
        import trimesh
        import comfy.model_management as mm
        _, path = output_path(glb_path, '.glb')
        mm.unload_all_models(); mm.soft_empty_cache()
        mesh = trimesh.load(str(path), force='mesh', process=False)
        if len(mesh.vertices) < 4 or len(mesh.faces) < 4: raise ValueError('Empty or invalid rig input.')
        # Only the inference copy may be decimated by UniRig. Finalization uses the original GLB.
        return (mesh,)


class LucasUniRigModels:
    @classmethod
    def INPUT_TYPES(cls): return {'required': {'model': ('UNIRIG_MODEL',)}}
    RETURN_TYPES = ('UNIRIG_SKELETON_MODEL', 'UNIRIG_SKINNING_MODEL')
    FUNCTION = 'split'
    CATEGORY = 'Lucas/Character/Internal'
    def split(self, model):
        outputs=[]
        for name in ('skeleton_model','skinning_model'):
            config=dict(model[name])
            if not config.get('checkpoint_path') or not Path(config['checkpoint_path']).is_file():
                raise RuntimeError('UniRig checkpoint unavailable: '+name+'. Check the model download log.')
            config.update(dtype=model.get('dtype', 'bf16'), attn_backend='sdpa')
            outputs.append(config)
        return tuple(outputs)


def validate_skeleton(skeleton):
    import numpy as np
    joints=np.asarray(skeleton['joints'], dtype=float)
    tails=np.asarray(skeleton['tails'], dtype=float)
    names=list(skeleton['names']); parents=list(skeleton['parents'])
    if not 2 <= len(names) <= 512 or len(set(names)) != len(names): raise ValueError('Invalid or duplicate predicted bones.')
    if joints.shape != (len(names),3) or tails.shape != joints.shape or len(parents)!=len(names):
        raise ValueError('Inconsistent predicted skeleton dimensions.')
    if not np.isfinite(joints).all() or not np.isfinite(tails).all(): raise ValueError('Non-finite predicted joints.')
    parents=[-1 if p is None else int(p) for p in parents]
    for i in range(len(names)):
        seen=set(); cursor=i
        while cursor!=-1:
            if cursor<0 or cursor>=len(names) or cursor in seen: raise ValueError('Invalid bone hierarchy or cycle.')
            seen.add(cursor);cursor=parents[cursor]
    center=np.asarray(skeleton['mesh_center'],dtype=float);scale=float(skeleton['mesh_scale'])
    if center.shape!=(3,) or not np.isfinite(center).all() or not 0 < scale < 1e10: raise ValueError('Invalid mesh normalization.')
    return {'center':center.tolist(),'scale':scale,'bones':len(names),'names':names,
            'joints':joints.tolist(),'tails':tails.tolist(),'parents':parents}


class LucasUniRigValidateSkeleton:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{'normalized_mesh':('TRIMESH',),'skeleton':('SKELETON',),
                            'source_path':('STRING',),'job':('STRING',),'seed':('INT',)}}
    RETURN_TYPES=('TRIMESH','SKELETON','STRING')
    FUNCTION='validate'
    CATEGORY='Lucas/Character/Internal'
    def validate(self, normalized_mesh, skeleton, source_path, job, seed):
        metadata=validate_skeleton(skeleton)
        root, source=output_path(source_path,'.glb')
        metadata.update(source=source_path, seed=int(seed), method='UniRig skeleton and ML skinning',
                        wrapper_revision=UNIRIG_REVISION, template='articulationxl')
        path=source.with_name(source.stem+'_'+job+'_unirig.json')
        path.write_text(json.dumps(metadata,indent=2),encoding='utf-8')
        return normalized_mesh, skeleton, path.relative_to(root).as_posix()


class LucasUniRigFinalize:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required': {k:('STRING',) for k in ('source_path','fbx_path','metadata_path')}}
    RETURN_TYPES=('STRING',)
    FUNCTION='finalize'
    CATEGORY='Lucas/Character/Internal'
    OUTPUT_NODE=True
    def finalize(self, source_path, fbx_path, metadata_path):
        import comfy.model_management as mm
        root,source=output_path(source_path,'.glb');_,fbx=output_path(fbx_path,'.fbx');_,meta=output_path(metadata_path,'.json')
        for path in (source,fbx,meta):
            if not path.is_file(): raise FileNotFoundError(path)
        # Unique names keep earlier successful rigs intact, including cached download paths.
        target=source.with_name(source.stem+'_'+uuid.uuid4().hex[:8]+'_rigged.glb')
        script=Path(__file__).parent/'tools'/'blender_unirig_finish.py'
        log=target.with_suffix('.log')
        command=[find_blender(),'--background','--factory-startup','--python-exit-code','1','--python',str(script),'--',str(source),str(fbx),str(meta),str(target)]
        with log.open('w',encoding='utf-8') as stream:
            proc=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT)
            started=time.monotonic()
            try:
                while proc.poll() is None:
                    mm.throw_exception_if_processing_interrupted()
                    if time.monotonic()-started>1800: raise RuntimeError('UniRig export exceeded 30 minutes.')
                    time.sleep(.2)
            except BaseException:
                proc.terminate()
                try: proc.wait(timeout=10)
                except subprocess.TimeoutExpired: proc.kill();proc.wait()
                raise
        if proc.returncode or not target.is_file() or not target.with_suffix('.rig.json').is_file():
            raise RuntimeError(f'UniRig export failed. Original GLB is preserved: {source_path}. Log: {log}')
        relative=target.relative_to(root).as_posix()
        return {'ui':{'lucas_result':[relative], 'lucas_blend':[relative[:-4]+'.blend']},'result':(relative,)}


class LucasRigExistingGLB:
    @classmethod
    def INPUT_TYPES(cls): return {'required':{'glb_path':('STRING',{'default':'Lucas_Character/3D/character_PBR_00001_.glb'})}}
    RETURN_TYPES=('STRING',)
    FUNCTION='load'
    CATEGORY='Lucas/Character'
    def load(self,glb_path):
        _,path=output_path(glb_path,'.glb')
        if not path.is_file(): raise FileNotFoundError(path)
        return (glb_path,)


NODE_CLASS_MAPPINGS={cls.__name__:cls for cls in (LucasAutomaticRig,LucasUniRigMesh,LucasUniRigModels,LucasUniRigValidateSkeleton,LucasUniRigFinalize,LucasRigExistingGLB)}
NODE_DISPLAY_NAME_MAPPINGS={name:'Lucas | '+name.removeprefix('Lucas') for name in NODE_CLASS_MAPPINGS}
NODE_DISPLAY_NAME_MAPPINGS['LucasAutomaticRig']='Lucas | UniRig automatic rig'

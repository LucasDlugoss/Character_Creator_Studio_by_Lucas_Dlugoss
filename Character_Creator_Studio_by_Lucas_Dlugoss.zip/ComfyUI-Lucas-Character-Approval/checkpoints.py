"""PBR recovery without repeating image approval or geometry sampling."""
import json
from pathlib import Path
import tempfile


def save_checkpoint(mesh, refs, mesh_report='', high_detail_path='', performance_config=''):
    import folder_paths
    import numpy as np
    from PIL import Image
    root = Path(folder_paths.get_output_directory()).resolve()
    parent = root / 'Lucas_Character/checkpoints';parent.mkdir(parents=True, exist_ok=True)
    target = Path(tempfile.mkdtemp(prefix='pbr_', dir=parent))
    mesh.export(str(target / 'mesh.ply'))
    names = []
    for name in ('front', 'left', 'back', 'right', 'top', 'bottom'):
        if name not in refs: continue
        value = refs[name]
        if value.ndim != 4 or value.shape[0] != 1: raise ValueError('Each reference must be one BHWC image.')
        pixels = (value[0,...,:3].detach().cpu().numpy().clip(0,1)*255).round().astype(np.uint8)
        Image.fromarray(pixels).save(target / (name + '.png'));names.append(name)
    if not names: raise ValueError('No approved views to save.')
    # Manifest last: incomplete checkpoints cannot be resumed.
    data = {'format': 'lucas_pbr_v1', 'views': names, 'mesh_report': mesh_report,
            'high_detail_path': high_detail_path, 'performance_config': performance_config}
    (target / 'checkpoint.json').write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    relative = (target / 'checkpoint.json').relative_to(root).as_posix()
    print('[Lucas PBR checkpoint] ' + relative, flush=True)
    return relative


class LucasLoadPBRCheckpoint:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required': {'checkpoint': ('STRING', {'default': 'Lucas_Character/checkpoints/pbr_.../checkpoint.json'})}}
    RETURN_TYPES = ('TRIMESH','LUCAS_APPROVED_VIEWS','STRING','STRING')
    RETURN_NAMES = ('mesh','approved_views','mesh_report','high_detail_path')
    FUNCTION = 'load'
    CATEGORY = 'Lucas/Character'
    def load(self, checkpoint):
        import folder_paths
        import numpy as np
        import torch
        import trimesh
        from PIL import Image
        root = Path(folder_paths.get_output_directory()).resolve()
        path = (root / checkpoint).resolve()
        if not path.is_relative_to(root): raise ValueError('Choose a checkpoint inside ComfyUI output.')
        data = json.loads(path.read_text(encoding='utf-8'))
        if data.get('format') != 'lucas_pbr_v1': raise ValueError('Invalid checkpoint format.')
        names = data.get('views', [])
        if not names or any(n not in ('front','left','back','right','top','bottom') for n in names): raise ValueError('Invalid views.')
        refs = {}
        for name in names:
            with Image.open(path.parent / (name + '.png')) as img:
                refs[name] = torch.from_numpy(np.array(img.convert('RGB'),copy=True)).float().unsqueeze(0)/255.0
        mesh = trimesh.load(path.parent / 'mesh.ply', force='mesh', process=False)
        if not len(mesh.faces): raise ValueError('Empty checkpoint mesh.')
        return mesh, {'images':refs}, data.get('mesh_report',''), data.get('high_detail_path','')


NODE_CLASS_MAPPINGS = {'LucasLoadPBRCheckpoint': LucasLoadPBRCheckpoint}
NODE_DISPLAY_NAME_MAPPINGS = {'LucasLoadPBRCheckpoint': 'Lucas | Resume PBR texture only'}

"""Expose managed portable Git, portable Blender, and COMFY_ENV_ROOT for tools launched by ComfyUI."""
import json
import os
from pathlib import Path

_root = Path(__file__).resolve().parents[2]
_git = _root / 'lucas_tools/mingit/cmd'
if (_git / 'git.exe').is_file():
    os.environ['PATH'] = str(_git) + os.pathsep + os.environ.get('PATH', '')

_tools_json = _root / 'lucas_tools/tools.json'
if _tools_json.is_file():
    try:
        _cfg = json.loads(_tools_json.read_text(encoding='utf-8'))
        _blender = _cfg.get('blender')
        if _blender and Path(_blender).is_file():
            os.environ['LUCAS_BLENDER'] = str(_blender)
            os.environ['PATH'] = str(Path(_blender).parent) + os.pathsep + os.environ.get('PATH', '')
        _ce = _cfg.get('comfy_env_root')
        if _ce:
            os.environ.setdefault('COMFY_ENV_ROOT', str(_ce))
    except Exception:
        pass

"""Quality stages. Heavy third-party packages are imported only at execution."""
import gc
import importlib
import json
from pathlib import Path

VIEW_ORDER = ('front', 'left', 'back', 'right', 'top', 'bottom')


def camera_owners(approved, swap_sides=False):
    """Six upstream cameras: front, left, back, right, top, bottom.

    Missing references fall back to an approved image, never to a rejected view.
    """
    if not approved or any(k not in VIEW_ORDER for k in approved):
        raise ValueError('At least one valid approved reference is required.')
    fallback = next(k for k in VIEW_ORDER if k in approved)
    sides = ['right', 'left'] if swap_sides else ['left', 'right']
    desired = ['front', sides[0], 'back', sides[1],
               'top' if 'top' in approved else 'front',
               'bottom' if 'bottom' in approved else 'back']
    return [x if x in approved else fallback for x in desired]


def pbr_images(albedo, mr):
    """Hunyuan stores M in R and R in G. glTF stores roughness G, metallic B."""
    import numpy as np
    from PIL import Image
    a = albedo.detach().cpu().numpy() if hasattr(albedo, 'detach') else np.asarray(albedo)
    m = mr.detach().cpu().numpy() if hasattr(mr, 'detach') else np.asarray(mr)
    if a.dtype != np.uint8:
        a = (np.clip(a, 0, 1) * 255).round().astype(np.uint8)
    if m.dtype != np.uint8:
        m = (np.clip(m, 0, 1) * 255).round().astype(np.uint8)
    packed = np.full_like(m[..., :3], 255)
    packed[..., 1] = m[..., 1]
    packed[..., 2] = m[..., 0]
    return Image.fromarray(a[..., :3]), Image.fromarray(packed), Image.fromarray(m[..., 0]), Image.fromarray(m[..., 1])


def clean_mesh(mesh, target_faces):
    """Conservative cleanup. Do not weld nearby fingers or delete accessories."""
    import numpy as np
    import trimesh
    high = mesh.copy()
    if len(high.faces) == 0:
        raise ValueError('Generated mesh is empty; regenerate geometry.')
    if not np.isfinite(high.vertices).all():
        raise ValueError('Mesh contains non-finite vertices; regenerate geometry.')
    high.update_faces(high.nondegenerate_faces())
    high.update_faces(high.unique_faces())
    high.remove_unreferenced_vertices()
    # Exact duplicated positions only; no distance-based welding or voxel remesh.
    trimesh.repair.fix_normals(high, multibody=True)
    low = high.copy()
    protected_components = 0
    if target_faces > 0 and len(high.faces) > target_faces:
        # Budget each disconnected component independently. A global decimator
        # can erase small accessories even when the total triangle budget is met.
        parts = high.split(only_watertight=False)
        ratio = target_faces / len(high.faces)
        reduced = []
        for part in parts:
            count = len(part.faces)
            goal = min(count, max(64, round(count * ratio)))
            if goal == count:
                protected_components += 1
                reduced.append(part)
                continue
            try:
                candidate = part.simplify_quadric_decimation(face_count=goal, aggression=3)
            except ImportError as exc:
                raise RuntimeError('Install fast-simplification in the ComfyUI Python environment.') from exc
            candidate.update_faces(candidate.nondegenerate_faces())
            candidate.remove_unreferenced_vertices()
            if not len(candidate.faces) or (part.is_watertight and not candidate.is_watertight):
                candidate = part.copy()
                protected_components += 1
            reduced.append(candidate)
        low = trimesh.util.concatenate(reduced)
        trimesh.repair.fix_normals(low, multibody=True)
    def stats(m):
        edges = np.bincount(m.edges_unique_inverse)
        return dict(vertices=len(m.vertices), triangles=len(m.faces),
                    watertight=bool(m.is_watertight), winding_consistent=bool(m.is_winding_consistent),
                    boundary_edges=int((edges == 1).sum()), nonmanifold_edges=int((edges > 2).sum()))
    return high, low, {'high': stats(high), 'working': stats(low),
                       'requested_target_faces': int(target_faces), 'protected_components': protected_components,
                       'note': 'Decimation targets are approximate; component protection may exceed the requested budget. Simplification is not animation retopology; inspect fingers and joints.'}


def unwrap_quality(mesh, texture_size):
    """One xatlas atlas with pixel-aware padding; preserve normals across UV seams."""
    import numpy as np
    import trimesh
    import xatlas
    vertices = np.asarray(mesh.vertices, dtype=np.float32)
    faces = np.asarray(mesh.faces, dtype=np.uint32)
    normals = np.asarray(mesh.vertex_normals, dtype=np.float32)
    atlas = xatlas.Atlas()
    atlas.add_mesh(vertices, faces, normals=normals)
    options = xatlas.PackOptions()
    options.resolution = int(texture_size)
    options.padding = max(4, int(texture_size) // 256)
    options.bilinear = True
    options.bruteForce = False
    atlas.generate(pack_options=options)
    if atlas.atlas_count != 1:
        raise RuntimeError('UV unwrap produced multiple atlases; one atlas is required for PBR.')
    mapping, indices, uv = atlas[0]
    if not np.isfinite(uv).all() or uv.min() < 0 or uv.max() > 1:
        raise RuntimeError('Invalid UV coordinates from xatlas.')
    # xatlas's actual dimensions can differ from the requested resolution.
    # Scale normalized coordinates into a square atlas without stretching charts.
    width, height = int(atlas.width), int(atlas.height)
    extent = max(width, height)
    uv = uv.copy()
    uv *= np.array([width / extent, height / extent])
    uv += (1 - np.array([width / extent, height / extent])) / 2
    wrapped = trimesh.Trimesh(vertices=vertices[mapping], faces=indices,
        vertex_normals=normals[mapping], process=False)
    wrapped.visual = trimesh.visual.TextureVisuals(uv=uv)
    tri = uv[np.asarray(indices)]
    u, v = tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0]
    area = np.abs(u[:, 0] * v[:, 1] - u[:, 1] * v[:, 0]) * .5
    report = {'method': 'xatlas', 'atlas_count': int(atlas.atlas_count),
        'chart_count': int(atlas.chart_count), 'packing_width': width, 'packing_height': height,
        'texture_size': int(texture_size), 'padding_requested_px': options.padding,
        'padding_at_output_px': float(options.padding * texture_size / extent),
        'uv_area_fraction': float(area.sum()), 'degenerate_uv_triangles': int((area < 1e-14).sum()),
        'note': 'Area is not an overlap test. Automatic charts are not hand-authored seams.'}
    print('[Lucas UV QA]', json.dumps(report))
    return wrapped, report


ANATOMY_MODES = ('Natural anatomy', 'Humanoid T-pose', 'Quadruped animal', 'Reptile quadruped', 'Bipedal reptile', 'Bird spread wings', 'Aquatic creature', 'Tentacled creature', 'Arthropod', 'Serpentine creature')
FRAMING_RULES = (
    "Single subject, full body, front view, plain white background, even neutral light. "
    "Preserve the requested identity, species, colors, materials and artistic style. "
    "Keep the entire body and extremities in frame with clear margins."
)
BODY_RULES = {
    'Natural anatomy': (
        "Use the subject's natural species-specific body plan and a neutral resting stance. "
        "Preserve its anatomical limb count and proportions. Adapt clothing and accessories "
        "to the existing body structure. Styling and clothing do not change the species' anatomy."
    ),
    'Quadruped animal': (
        "A fully quadrupedal animal with exactly four anatomical legs: two forelegs and two hind legs. "
        "All four legs support the body on the ground in a natural standing stance. "
        "The chest, shoulders, neck and torso follow the animal's natural skeletal proportions. "
        "Preserve species-specific paws or hooves at the ends of all four legs. "
        "Any costume is tailored as an animal coat, blanket, cape or harness fitted along "
        "the animal's torso. Clothing openings align only with the four existing legs. "
        "Accessories attach to that animal garment. Keep the same quadrupedal body plan regardless of clothing or art style."
    ),
    'Humanoid T-pose': (
        "A human or explicitly anthropomorphic biped with two arms and two legs. "
        "Neutral T-pose: the existing arms extend sideways at shoulder height. "
        "Use relaxed hands or the user's requested hand posture. Preserve the requested species features."
    ),
}
# Rig-reference poses preserve species topology; they do not build a rig.
BODY_RULES['Natural anatomy'] += (
    " Use a centered neutral reference pose with natural symmetry where applicable. "
    "Keep existing appendages visibly separated where anatomy permits; preserve actual limb count."
)
BODY_RULES['Humanoid T-pose'] += (
    " Keep the spine and pelvis neutral, head level, legs straight without locking joints, "
    "feet parallel and hip-width apart. Keep wrists neutral and clothing clear of joint gaps. "
    "Do not force finger spread or palm direction."
)
BODY_RULES['Quadruped animal'] += (
    " Neutral reference stance: level spine, balanced weight, legs spaced slightly apart "
    "with visible gaps in the corresponding camera views. Keep the tail extended away "
    "from the legs without curling around the body. Keep neck and head in a neutral species-appropriate position."
)
BODY_RULES.update({
    'Reptile quadruped': (
        "A naturally four-legged reptile with exactly four anatomical legs. Neutral symmetrical resting stance, "
        "body aligned straight along its length, legs spread slightly outward following the species' "
        "normal joint articulation. Preserve the species-specific belly height; all four feet rest on the ground. "
        "Tail extended rearward along the body axis, clear of the legs and not coiled. Head aligned with the spine, "
        "jaw gently closed. Preserve natural claws and digits. Clothing, if requested, fits this reptilian body."
    ),
    'Bipedal reptile': (
        "A naturally bipedal reptile or dinosaur, not a person in a costume. Two hind legs support the body "
        "in a balanced neutral stance with feet apart. Preserve the species' native torso inclination. "
        "Exactly two species-proportioned forelimbs, held slightly clear of the chest in a relaxed anatomical pose. "
        "Do not lengthen short forelimbs. Tail extended rearward and clear of the legs as a natural counterbalance. "
        "Head and neck neutral; preserve reptilian feet, claws and native digit count."
    ),
    'Bird spread wings': (
        "A bird with exactly two anatomical wings and two legs. Symmetrical neutral spread-wing reference pose: "
        "both wings extended laterally in a comfortable natural spread, with wing joints following avian anatomy. "
        "Both feet planted slightly apart; head and beak aligned forward. Tail feathers extended rearward, "
        "clear of the legs. Preserve the feather structure and wing proportions of the requested bird. "
        "The two wings are the forelimbs. Keep wing roots and leg joints readable. Clothing fits the avian body."
    ),
    'Aquatic creature': (
        "An aquatic animal in a neutral suspended reference pose, with its natural body axis straight and level. "
        "Preserve the species' actual fins, flippers and tail configuration. Existing fins or flippers are "
        "extended gently away from the body with readable attachment points. Tail centered, relaxed and "
        "uncurled; preserve its native orientation. Keep the entire body visible against the white background."
    ),
    'Tentacled creature': (
        "A tentacled creature in a neutral open reference pose. Preserve exactly the appendage count "
        "and arrangement of the requested species or explicitly described creature. Gently fan the existing "
        "tentacles or arms outward around the body with clear spaces between them, relaxed curves and "
        "readable attachment points. Avoid tight coils, knots and crossed appendages. Keep tips separated "
        "from the body and neighboring appendages. Preserve the species' natural body structure."
    ),
    'Arthropod': (
        "An arthropod with the correct number of legs, antennae and other appendages for the requested "
        "species. Neutral bilateral reference stance with the body centered and aligned, legs spread "
        "laterally along their natural joint angles, feet resting on the ground. Keep adjacent legs "
        "separated and joints readable. Existing antennae and mouthparts are held clear of the body. "
        "Preserve the species-specific segment arrangement and any naturally present wings."
    ),
    'Serpentine creature': (
        "A naturally limbless serpentine creature. Neutral elongated reference pose: body gently extended "
        "along its longitudinal axis with only a shallow natural curve, head aligned with the neck, "
        "tail extended clear of the body. Keep the entire body visible, avoiding coils, knots, overlapping "
        "loops or a raised striking pose. Preserve the requested species' scales and body proportions."
    ),
})
PRESET_NEGATIVES = {
    'Reptile quadruped': 'human arms, human hands, humanoid torso, extra legs, bipedal stance, coiled tail',
    'Bipedal reptile': 'human hands, human torso, extra limbs, elongated forelimbs, T-pose, crossed limbs, coiled tail',
    'Bird spread wings': 'human arms, human hands, additional arms, four wings, extra legs, folded wings, crossed wings',
    'Aquatic creature': 'human arms, human hands, human legs, humanoid torso, extra fins, coiled body, curled tail',
    'Tentacled creature': 'human torso, human hands, extra appendages, fused tentacles, knotted tentacles, tightly coiled tentacles',
    'Arthropod': 'human arms, human hands, humanoid torso, fused legs, crossed legs, extra legs, missing legs',
    'Serpentine creature': 'arms, hands, legs, feet, humanoid torso, coiled body, knots, overlapping loops, striking pose',
}
BASE_NEGATIVE = 'extra limbs, duplicated anatomy, malformed body, cropped subject, multiple subjects, text overlay, watermark'
QUADRUPED_NEGATIVE = (
    'human arms, human hands, human fingers, additional arms, six limbs, six legs, '
    'centaur, humanoid torso, anthropomorphic body, bipedal stance, upright human posture, '
    'T-pose, outstretched arms, horizontal sleeves, human shoulders'
)


def compose_character_prompt(user_prompt, anatomy_mode='Natural anatomy'):
    if not isinstance(user_prompt, str) or not user_prompt.strip():
        raise ValueError('Empty character description; generation stopped.')
    if anatomy_mode not in ANATOMY_MODES:
        raise ValueError('Invalid anatomy mode. Reimport the current workflow.')
    return f"{user_prompt.strip()}\n\n{BODY_RULES[anatomy_mode]}\n{FRAMING_RULES}"


def compose_negative_prompts(anatomy_mode):
    if anatomy_mode not in ANATOMY_MODES: raise ValueError('Invalid anatomy mode.')
    negative = BASE_NEGATIVE
    if anatomy_mode == 'Quadruped animal': negative += ', ' + QUADRUPED_NEGATIVE
    elif anatomy_mode in PRESET_NEGATIVES: negative += ', ' + PRESET_NEGATIVES[anatomy_mode]
    views = negative + ', changed species, changed body plan, changed pose, changed costume, inconsistent proportions, shadows, gradient background, collage'
    return negative, views


def check_pbr_dependencies():
    """Import-only checks: no weights loaded and no automatic downloads."""
    import nodes
    errors = []
    for name in ('fast_simplification', 'trimesh', 'xatlas',
                 'custom_rasterizer', 'custom_rasterizer_kernel', 'mesh_inpaint_processor'):
        try:
            importlib.import_module(name)
        except Exception as exc:
            errors.append(f'{name}: {type(exc).__name__}: {exc}')
    upstream = nodes.NODE_CLASS_MAPPINGS.get('Hy3D21CameraConfig')
    if upstream is None:
        errors.append('ComfyUI-Hunyuan3d-2-1 (visualbruno) is not loaded. The older Hunyuan3DWrapper is a different package.')
    else:
        try:
            module = importlib.import_module(upstream.__module__)
            for name in ('Hunyuan3DPaintConfig', 'Hunyuan3DPaintPipeline', 'mesh_uv_wrap'):
                value = getattr(module, name)
                # Resolve upstream lazy imports without constructing a pipeline.
                resolver = getattr(value, '_get', None)
                if resolver is not None:
                    resolver()
        except Exception as exc:
            errors.append(f'PBR pipeline imports: {type(exc).__name__}: {exc}')
    if errors:
        return ('Lucas preflight stopped BEFORE image sampling. Run tools/install_pbr.py '
                'with the ComfyUI Python, then restart.\n' + '\n'.join(errors))
    return True


class LucasBuildCharacterPrompt:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required': {'user_prompt': ('STRING', {'forceInput': True})}, 'optional': {'performance_config': ('STRING', {'forceInput': True}), 'anatomy_mode': ('STRING', {'forceInput': True})}}
    RETURN_TYPES = ('STRING', 'STRING', 'STRING')
    RETURN_NAMES = ('exact_positive_prompt', 'concept_negative', 'view_negative')
    FUNCTION = 'build'
    CATEGORY = 'Lucas/Character'

    def build(self, user_prompt, performance_config="", anatomy_mode="Natural anatomy"):
        status = check_pbr_dependencies()
        if status is not True:
            raise RuntimeError(status)
        final = compose_character_prompt(user_prompt, anatomy_mode)
        negative, view_negative = compose_negative_prompts(anatomy_mode)
        print('[Lucas | exact concept positive prompt]\n' + final)
        return {'ui': {'text': ['ANATOMY: ' + anatomy_mode + '\n\nPOSITIVE:\n' + final + '\n\nNEGATIVE:\n' + negative]}, 'result': (final, negative, view_negative)}


class LucasPackApprovedViews:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required': {}, 'optional': {k: ('IMAGE',) for k in VIEW_ORDER}}
    RETURN_TYPES = ('LUCAS_APPROVED_VIEWS',)
    FUNCTION = 'pack'
    CATEGORY = 'Lucas/Character'
    def pack(self, **images):
        if not images:
            raise ValueError('No approved images.')
        return ({'images': images},)


class LucasMeshQuality:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required': {'mesh': ('TRIMESH',), 'target_faces': ('INT', {'default': 0, 'min': 0, 'max': 2000000, 'tooltip': '0 uses the performance profile budget; explicit values override it.'})},
                'optional': {'performance_config': ('STRING', {'forceInput': True})}}
    RETURN_TYPES = ('TRIMESH', 'TRIMESH', 'STRING')
    RETURN_NAMES = ('high_detail', 'working_mesh', 'mesh_report')
    FUNCTION = 'process'
    CATEGORY = 'Lucas/Character'
    def process(self, mesh, target_faces, performance_config=''):
        if target_faces == 0:
            profile = json.loads(performance_config) if performance_config else {}
            target_faces = int(profile.get('settings', {}).get('mesh_target_faces', 300000))
        high, low, report = clean_mesh(mesh, target_faces)
        report['warnings'] = []
        if report['working']['nonmanifold_edges']:
            report['warnings'].append('Non-manifold edges remain; inspect or regenerate geometry before rigging. UV processing does not repair topology.')
        if report['working']['boundary_edges']:
            report['warnings'].append('Open boundaries remain; check whether these are intentional.')
        print('[Lucas mesh QA]', json.dumps(report))
        return high, low, json.dumps(report, indent=2)


class LucasPBRPaint21:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required': {
            'mesh': ('TRIMESH',), 'approved_views': ('LUCAS_APPROVED_VIEWS',),
            'view_size': ([512, 768, 1024], {'default': 768}),
            'texture_size': ([2048, 4096], {'default': 4096}),
            'steps': ('INT', {'default': 30, 'min': 1, 'max': 100}),
            'guidance_scale': ('FLOAT', {'default': 3.0, 'min': 1.0, 'max': 10.0}),
            'seed': ('INT', {'default': 42, 'min': 0, 'max': 0xffffffffffffffff, 'control_after_generate': False}),
            'use_all_approved': ('BOOLEAN', {'default': True}),
            'swap_side_references': ('BOOLEAN', {'default': False}),
            'filename_prefix': ('STRING', {'default': 'Lucas_Character/3D/character_PBR'}),
        }, 'optional': {'mesh_report': ('STRING', {'forceInput': True}), 'high_detail_path': ('STRING', {'forceInput': True}), 'performance_config': ('STRING', {'forceInput': True})}}
    @classmethod
    def VALIDATE_INPUTS(cls, steps):
        # A real literal input makes ComfyUI invoke this during queue validation.
        return check_pbr_dependencies()

    RETURN_TYPES = ('TRIMESH', 'STRING', 'IMAGE', 'IMAGE', 'IMAGE', 'IMAGE')
    RETURN_NAMES = ('textured_mesh', 'glb_path', 'base_color', 'metallic_roughness', 'metallic', 'roughness')
    FUNCTION = 'paint'
    CATEGORY = 'Lucas/Character'
    OUTPUT_NODE = True

    def paint(self, mesh, approved_views, view_size, texture_size, steps, guidance_scale,
              seed, use_all_approved, swap_side_references, filename_prefix, mesh_report='', high_detail_path='', performance_config=''):
        import numpy as np
        import torch
        import trimesh
        from PIL import Image
        import folder_paths
        import nodes
        import comfy.model_management as mm
        from .checkpoints import save_checkpoint
        profile = json.loads(performance_config) if performance_config else None
        if profile:
            settings = profile['settings']
            view_size, texture_size, steps = settings['pbr_view_size'], settings['texture_size'], settings['pbr_steps']
        checkpoint = save_checkpoint(mesh, approved_views.get('images', {}), mesh_report, high_detail_path, performance_config)
        upstream = nodes.NODE_CLASS_MAPPINGS.get('Hy3D21CameraConfig')
        if upstream is None:
            raise RuntimeError('Install visualbruno/ComfyUI-Hunyuan3d-2-1 and its rasterizer dependencies, then restart ComfyUI.')
        module = importlib.import_module(upstream.__module__)
        refs = approved_views.get('images', {})
        owners = camera_owners(refs, swap_side_references)
        if not use_all_approved:
            owners = [next(k for k in VIEW_ORDER if k in refs)] * 6
        # Release managed Qwen/Hunyuan shape models before the separate Diffusers pipeline.
        mm.unload_all_models()
        mm.soft_empty_cache()
        device = mm.get_torch_device()
        free, total = torch.cuda.mem_get_info(device)
        print(f'[Lucas PBR] Free VRAM after unload: {free / 1024**3:.1f} GiB; views={view_size}, atlas={texture_size}, steps={steps}')
        if free < 2 * 1024**3:
            raise RuntimeError('Less than 2 GiB free VRAM before PBR. Close other applications and resume texture with: ' + checkpoint)
        azims, elevs = [0, 90, 180, 270, 0, 180], [0, 0, 0, 0, 90, -90]
        weights = [1.0, 0.6, 0.9, 0.6, 0.15, 0.15]
        conf = module.Hunyuan3DPaintConfig(int(view_size), azims, elevs, weights, 1.2, int(texture_size))
        pipe = None
        try:
            from comfy.utils import ProgressBar
            progress = ProgressBar(len(set(owners)) + 2)
            uv_mesh, uv_report = unwrap_quality(mesh, int(texture_size))
            pipe = module.Hunyuan3DPaintPipeline(conf)
            albedos, materials = [None] * 6, [None] * 6
            for label in dict.fromkeys(owners):
                mm.throw_exception_if_processing_interrupted()
                image = refs[label]
                if image.ndim != 4 or image.shape[0] != 1:
                    raise ValueError('Each approved view must contain one BHWC image.')
                pil = Image.fromarray((image[0, ..., :3].detach().cpu().numpy().clip(0, 1) * 255).round().astype(np.uint8))
                # Each pass produces geometry-aligned views, conditioned on ONE approved
                # appearance. Keep the cameras associated with that actual reference.
                # Passing a list to upstream would silently use only its first image.
                print(f'[Lucas PBR] Reference {label}; cameras {[i for i, x in enumerate(owners) if x == label]}')
                a, mr, normals, positions = pipe(mesh=uv_mesh.copy(), image_path=pil,
                    num_steps=steps, guidance_scale=guidance_scale, unwrap=False, seed=int(seed) % (2**32))
                if len(a) != 6 or len(mr) != 6:
                    raise RuntimeError('Unexpected Hunyuan Paint 2.1 camera count; check upstream compatibility.')
                for i, owner in enumerate(owners):
                    if owner == label:
                        albedos[i], materials[i] = a[i], mr[i]
                del a, mr, normals, positions
                progress.update(1)
            mm.throw_exception_if_processing_interrupted()
            # Diffusion weights are no longer needed while baking the 4K atlas.
            pipe.model = None
            gc.collect()
            mm.soft_empty_cache()
            texture, mask, mr, mr_mask = pipe.bake_from_multiview(albedos, materials, elevs, azims, weights)
            texture, mr = pipe.inpaint(texture, mask, mr, mr_mask, False, 'NS')
            progress.update(1)
            base, packed, metal, rough = pbr_images(texture, mr)
            material = trimesh.visual.material.PBRMaterial(baseColorTexture=base,
                metallicRoughnessTexture=packed, metallicFactor=1.0, roughnessFactor=1.0,
                baseColorFactor=[255, 255, 255, 255], doubleSided=True)
            uv_mesh.visual = trimesh.visual.TextureVisuals(uv=uv_mesh.visual.uv, material=material)
            directory, stem, counter, subfolder, _ = folder_paths.get_save_image_path(filename_prefix, folder_paths.get_output_directory())
            out = Path(directory)
            out.mkdir(parents=True, exist_ok=True)
            # SaveImage counters do not necessarily discover standalone GLBs.
            while any(out.glob(f'{stem}_{counter:05}_*')):
                counter += 1
            basename = f'{stem}_{counter:05}_'
            path = out / (basename + '.glb')
            uv_mesh.export(str(path), include_normals=True)
            images = [base, packed, metal, rough]
            for name, img in zip(('base_color', 'metallic_roughness', 'metallic', 'roughness'), images):
                img.save(out / (basename + '_' + name + '.png'))
            report = {'view_size': int(view_size), 'atlas_size': int(texture_size), 'camera_references': owners,
                'uv': uv_report, 'export_vertex_normals': True,
                'checkpoint': checkpoint, 'performance_profile': profile, 'high_detail_path': high_detail_path, 'approved_references': list(refs),
                'geometry_supported_views': ['front', 'left', 'back', 'right'],
                'pbr_only_views': [v for v in ('top', 'bottom') if v in refs], 'paint_passes': len(set(owners)),
                'mesh': json.loads(mesh_report) if mesh_report else None,
                'limits': 'No automatic pose certification or animation topology. Multi-reference painting is inferred, not exact projection. Check seams and side orientation.'}
            (out / (basename + '_report.json')).write_text(json.dumps(report, indent=2), encoding='utf-8')
            tensors = tuple(torch.from_numpy(np.asarray(img.convert('RGB')).copy()).float().unsqueeze(0) / 255.0 for img in images)
            relative = (Path(subfolder) / path.name).as_posix()
            progress.update(1)
            return {'ui': {'lucas_result': [relative]}, 'result': (uv_mesh, relative, *tensors)}
        except torch.cuda.OutOfMemoryError as exc:
            raise RuntimeError('GPU memory exhausted. Open Lucas_Retomar_PBR.json, select Speed and paste this checkpoint: ' + checkpoint) from exc
        finally:
            if pipe is not None:
                pipe.clean_memory()
            gc.collect()
            mm.soft_empty_cache()


NODE_CLASS_MAPPINGS = {c.__name__: c for c in (LucasBuildCharacterPrompt, LucasPackApprovedViews, LucasMeshQuality, LucasPBRPaint21)}
NODE_DISPLAY_NAME_MAPPINGS = {k: k.replace('Lucas', 'Lucas | ', 1) for k in NODE_CLASS_MAPPINGS}

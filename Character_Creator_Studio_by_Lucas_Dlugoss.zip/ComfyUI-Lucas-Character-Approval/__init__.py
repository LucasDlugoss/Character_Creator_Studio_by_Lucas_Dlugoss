"""Local human approval gate for a two-stage ComfyUI character workflow."""
import threading
import uuid
from aiohttp import web
from server import PromptServer
from nodes import PreviewImage
import comfy.model_management as model_management

_PENDING = {}
_LOCK = threading.Lock()

@PromptServer.instance.routes.post('/lucas_character_approval/decide')
async def decide(request):
    data = await request.json()
    if data.get('action') not in ('approve', 'reject', 'cancel'):
        return web.json_response({'error': 'Invalid action'}, status=400)
    with _LOCK:
        item = _PENDING.get(data.get('token'))
        if item is None or item['action'] is not None:
            return web.json_response({'error': 'This review is no longer pending'}, status=409)
        item['action'] = data['action']
        item['event'].set()
    return web.json_response({'ok': True})

@PromptServer.instance.routes.get('/lucas_character_approval/pending')
async def pending(request):
    node_id = request.query.get('node_id')
    with _LOCK:
        reviews = [v['payload'] for v in _PENDING.values()
                   if v['action'] is None and v['payload']['node_id'] == node_id]
    return web.json_response({'reviews': reviews})

class LucasCharacterApproval:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required': {'images': ('IMAGE',),
                             'front_sampler_id': ('INT', {'default': 16, 'min': 1})},
                'hidden': {'unique_id': 'UNIQUE_ID', 'prompt': 'PROMPT',
                           'extra_pnginfo': 'EXTRA_PNGINFO'}}
    RETURN_TYPES = ('IMAGE',)
    RETURN_NAMES = ('approved_image',)
    FUNCTION = 'review'
    CATEGORY = 'Lucas/Character'
    OUTPUT_NODE = True
    @classmethod
    def IS_CHANGED(cls, **kwargs):
        return float('nan')

    def review(self, images, front_sampler_id=16, unique_id=None,
               prompt=None, extra_pnginfo=None):
        preview = PreviewImage().save_images(images, filename_prefix='LucasCharacterReview',
                                            prompt=prompt, extra_pnginfo=extra_pnginfo)
        token = uuid.uuid4().hex
        payload = {'token': token, 'node_id': str(unique_id),
                   'images': preview['ui']['images'], 'front_sampler_id': front_sampler_id}
        item = {'event': threading.Event(), 'action': None, 'payload': payload}
        with _LOCK:
            _PENDING[token] = item
        client_id = getattr(PromptServer.instance, 'client_id', None)
        try:
            PromptServer.instance.send_sync('lucas-character-review', payload, client_id)
            while not item['event'].wait(0.2):
                model_management.throw_exception_if_processing_interrupted()
            model_management.throw_exception_if_processing_interrupted()
            if item['action'] != 'approve':
                raise model_management.InterruptProcessingException()
            return {'ui': preview['ui'], 'result': (images,)}
        finally:
            with _LOCK:
                _PENDING.pop(token, None)
            PromptServer.instance.send_sync('lucas-character-review-closed', {'token': token}, client_id)

from .quality import ANATOMY_MODES

class LucasCharacterPrompt:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required': {'description': ('STRING', {'default': '', 'multiline': True}), 'anatomy_mode': (list(ANATOMY_MODES), {'default': 'Natural anatomy'})}}
    RETURN_TYPES = ('STRING', 'STRING')
    RETURN_NAMES = ('user_prompt', 'anatomy_mode')
    FUNCTION = 'get_prompt'
    CATEGORY = 'Lucas/Character'

    def get_prompt(self, description, anatomy_mode='Natural anatomy'):
        if not isinstance(description, str) or not description.strip():
            raise ValueError('Character description is empty. Update the Lucas node pack, reload the browser, and submit the prompt dialog again.')
        if anatomy_mode not in ANATOMY_MODES:
            raise ValueError('Invalid anatomy mode.')
        return (description.strip(), anatomy_mode)

NODE_CLASS_MAPPINGS = {'LucasCharacterApproval': LucasCharacterApproval, 'LucasCharacterPrompt': LucasCharacterPrompt}
NODE_DISPLAY_NAME_MAPPINGS = {'LucasCharacterApproval': 'Lucas | Concept approval', 'LucasCharacterPrompt': 'Lucas | Character prompt dialog'}
WEB_DIRECTORY = './web'
_VIEW_PENDING = {}
_VIEW_ORDER = ('front', 'left', 'back')

@PromptServer.instance.routes.post('/lucas_character_views/decide')
async def decide_view(request):
    data = await request.json()
    action = data.get('action')
    if action not in (*_VIEW_ORDER, 'retry', 'skip', 'finish', 'cancel'):
        return web.json_response({'error': 'Invalid action'}, status=400)
    with _LOCK:
        item = _VIEW_PENDING.get(data.get('token'))
        if item is None or item['action'] is not None:
            return web.json_response({'error': 'This review is no longer pending'}, status=409)
        if action in _VIEW_ORDER and action not in item['payload']['remaining']:
            return web.json_response({'error': 'This view is already approved'}, status=409)
        if action == 'finish' and not item['payload']['approved']:
            return web.json_response({'error': 'Approve at least one view before generating 3D.'}, status=400)
        if action == 'skip' and not item['payload']['approved'] and len(item['payload']['pending']) <= 1:
            return web.json_response({'error': 'Approve at least one view. Generate again or stop execution.'}, status=400)
        item['action'] = action
        item['event'].set()
    return web.json_response({'ok': True})

@PromptServer.instance.routes.get('/lucas_character_views/pending')
async def pending_view(request):
    node_id = request.query.get('node_id')
    with _LOCK:
        reviews = [v['payload'] for v in _VIEW_PENDING.values()
                   if v['action'] is None and v['payload']['node_id'] == node_id]
    return web.json_response({'reviews': reviews})

class LucasReviewThreeViews:
    @classmethod
    def INPUT_TYPES(cls):
        import comfy.samplers
        return {'required': {
            'model': ('MODEL',), 'vae': ('VAE',),
            'positive_front': ('CONDITIONING',),
            'positive_back': ('CONDITIONING',), 'positive_left': ('CONDITIONING',),
            'negative': ('CONDITIONING',), 'latent_image': ('LATENT',),
            'seed': ('INT', {'default': 123456, 'min': 0, 'max': 0xffffffffffffffff, 'control_after_generate': True}),
            'steps': ('INT', {'default': 40, 'min': 1, 'max': 10000}),
            'cfg': ('FLOAT', {'default': 4.0, 'min': 0.0, 'max': 100.0}),
            'sampler_name': (comfy.samplers.KSampler.SAMPLERS,),
            'scheduler': (comfy.samplers.KSampler.SCHEDULERS,),
            'denoise': ('FLOAT', {'default': 1.0, 'min': 0.0, 'max': 1.0}),
        }, 'optional': {'approved_front': ('IMAGE',)}, 'hidden': {'unique_id': 'UNIQUE_ID', 'prompt': 'PROMPT', 'extra_pnginfo': 'EXTRA_PNGINFO'}}
    RETURN_TYPES = ('LUCAS_APPROVED_VIEWS',)
    RETURN_NAMES = ('approved_views',)
    FUNCTION = 'generate_review'
    CATEGORY = 'Lucas/Character'
    @classmethod
    def IS_CHANGED(cls, **kwargs):
        return float('nan')

    def generate_review(self, model, vae, positive_front, positive_back,
                        positive_left, negative, latent_image, seed, steps, cfg,
                        sampler_name, scheduler, denoise=1.0, unique_id=None,
                        prompt=None, extra_pnginfo=None, approved_front=None):
        from nodes import common_ksampler, VAEDecode
        accepted = {'front': approved_front} if approved_front is not None else {}
        skipped = set()
        conditionings = {'front': positive_front, 'left': positive_left, 'back': positive_back}
        attempt = 0
        client_id = getattr(PromptServer.instance, 'client_id', None)
        while len(accepted) < len(_VIEW_ORDER):
            model_management.throw_exception_if_processing_interrupted()
            remaining = [v for v in _VIEW_ORDER if v not in accepted]
            pending_angles = [v for v in remaining if v not in skipped]
            if not pending_angles:
                break
            requested = pending_angles[0]
            actual_seed = (int(seed) + attempt) % (1 << 64)
            attempt += 1
            samples = common_ksampler(model, actual_seed, steps, cfg, sampler_name, scheduler,
                                      conditionings[requested], negative, latent_image, denoise=denoise)[0]
            # Use the native decoder: Qwen's VAE can return a 5D image tensor.
            # VAEDecode folds the batch/frame axes into ComfyUI's 4D IMAGE layout.
            images = VAEDecode().decode(vae, samples)[0]
            # No samplers, latent histories or rejected image tensors are retained.
            del samples
            preview = PreviewImage().save_images(images, filename_prefix='LucasViewReview',
                                                prompt=prompt, extra_pnginfo=extra_pnginfo)
            token = uuid.uuid4().hex
            payload = {'token': token, 'node_id': str(unique_id), 'images': preview['ui']['images'],
                       'remaining': remaining, 'approved': list(accepted), 'requested': requested,
                       'pending': pending_angles, 'skipped': [v for v in _VIEW_ORDER if v in skipped],
                       'seed': str(actual_seed), 'attempt': attempt}
            item = {'event': threading.Event(), 'action': None, 'payload': payload}
            with _LOCK:
                _VIEW_PENDING[token] = item
            try:
                PromptServer.instance.send_sync('lucas-view-review', payload, client_id)
                while not item['event'].wait(0.2):
                    model_management.throw_exception_if_processing_interrupted()
                model_management.throw_exception_if_processing_interrupted()
                action = item['action']
                if action == 'cancel':
                    raise model_management.InterruptProcessingException()
                if action == 'retry':
                    continue
                if action == 'finish':
                    if not accepted:
                        raise ValueError('Approve at least one view before generating 3D.')
                    break
                if action == 'skip':
                    skipped.add(requested)
                    continue
                # Endpoint checks uniqueness; check again before assigning a tensor.
                if action not in remaining:
                    raise ValueError('Invalid or duplicate approved view')
                accepted[action] = images
                skipped.discard(action)
            finally:
                with _LOCK:
                    _VIEW_PENDING.pop(token, None)
                PromptServer.instance.send_sync('lucas-view-review-closed', {'token': token}, client_id)
        if not accepted:
            raise ValueError('Approve at least one view before generating 3D.')
        return ({'images': accepted, 'skipped': [v for v in _VIEW_ORDER if v not in accepted]},)

NODE_CLASS_MAPPINGS['LucasReviewThreeViews'] = LucasReviewThreeViews
NODE_DISPLAY_NAME_MAPPINGS['LucasReviewThreeViews'] = 'Lucas | Review, skip or generate 3D'


class LucasApprovedViews3D:
    """Expand only approved angles into native foreground, save and encode nodes."""
    @classmethod
    def INPUT_TYPES(cls):
        return {'required': {'approved_views': ('LUCAS_APPROVED_VIEWS',),
                             'clip_vision': ('CLIP_VISION',)}}
    RETURN_TYPES = ('CONDITIONING', 'CONDITIONING', 'IMAGE', 'LUCAS_APPROVED_VIEWS')
    RETURN_NAMES = ('positive', 'negative', 'texture_reference', 'clean_approved_views')
    FUNCTION = 'prepare'
    CATEGORY = 'Lucas/Character'
    OUTPUT_NODE = True

    def prepare(self, approved_views, clip_vision):
        from comfy_execution.graph_utils import GraphBuilder
        from .sources import ANGLES, SHAPE_ANGLES
        images = approved_views.get('images', {})
        if not images or any(name not in ANGLES for name in images):
            raise ValueError('At least one valid approved view is required.')
        if not any(name in images for name in SHAPE_ANGLES):
            raise ValueError('At least one front, left, back or right reference is required for geometry.')
        graph = GraphBuilder()
        encoded = {}
        foreground = {}
        for name in ANGLES:
            if name not in images:
                continue
            clean = graph.node('easy imageRemBg', images=images[name],
                               rem_mode='RMBG-1.4', image_output='Hide',
                               save_prefix='Lucas_Character/views/' + name,
                               torchscript_jit=False, add_background='white',
                               refine_foreground=False)
            foreground[name] = clean.out(0)
            graph.node('SaveImage', images=clean.out(0),
                       filename_prefix='Lucas_Character/views/' + name)
            if name in SHAPE_ANGLES:
                encoded[name] = graph.node('CLIPVisionEncode', clip_vision=clip_vision,
                                           image=clean.out(0), crop='none').out(0)
        conditioning = graph.node('Hunyuan3Dv2ConditioningMultiView', **encoded)
        reference_name = next(name for name in SHAPE_ANGLES if name in images)
        packed = graph.node('LucasPackApprovedViews', **foreground)
        return {'result': (conditioning.out(0), conditioning.out(1), foreground[reference_name], packed.out(0)),
                'expand': graph.finalize()}

NODE_CLASS_MAPPINGS['LucasApprovedViews3D'] = LucasApprovedViews3D
NODE_DISPLAY_NAME_MAPPINGS['LucasApprovedViews3D'] = 'Lucas | Approved views to 3D inputs'

from .quality import NODE_CLASS_MAPPINGS as QUALITY_NODES, NODE_DISPLAY_NAME_MAPPINGS as QUALITY_NAMES
NODE_CLASS_MAPPINGS.update(QUALITY_NODES)
NODE_DISPLAY_NAME_MAPPINGS.update(QUALITY_NAMES)

from .performance import NODE_CLASS_MAPPINGS as PERF_NODES, NODE_DISPLAY_NAME_MAPPINGS as PERF_NAMES
from .checkpoints import NODE_CLASS_MAPPINGS as CHECK_NODES, NODE_DISPLAY_NAME_MAPPINGS as CHECK_NAMES
NODE_CLASS_MAPPINGS.update(PERF_NODES)
NODE_DISPLAY_NAME_MAPPINGS.update(PERF_NAMES)
NODE_CLASS_MAPPINGS.update(CHECK_NODES)
NODE_DISPLAY_NAME_MAPPINGS.update(CHECK_NAMES)

@PromptServer.instance.routes.post('/lucas_character/performance')
async def preview_performance(request):
    from .performance import hardware, select_profile
    try:
        data = await request.json()
        config = select_profile(data.get('mode', 'Automatic'), hardware(), data.get('manual', {}))
        return web.json_response(config)
    except Exception as exc:
        return web.json_response({'error': str(exc)}, status=400)

from .sources import route_sources, NODE_CLASS_MAPPINGS as SOURCE_NODES, NODE_DISPLAY_NAME_MAPPINGS as SOURCE_NAMES
NODE_CLASS_MAPPINGS.update(SOURCE_NODES)
NODE_DISPLAY_NAME_MAPPINGS.update(SOURCE_NAMES)
PromptServer.instance.add_on_prompt_handler(route_sources)


@PromptServer.instance.routes.get('/lucas_character/download')
async def download_character(request):
    from pathlib import Path
    import folder_paths
    root = Path(folder_paths.get_output_directory()).resolve()
    target = (root / request.query.get('path', '')).resolve()
    if not target.is_relative_to(root) or target.suffix.lower() not in ('.glb', '.blend') or not target.is_file():
        raise web.HTTPNotFound()
    return web.FileResponse(target, headers={'Content-Disposition': 'attachment; filename="character' + target.suffix.lower() + '"'})

from .rig import NODE_CLASS_MAPPINGS as RIG_NODES, NODE_DISPLAY_NAME_MAPPINGS as RIG_NAMES
NODE_CLASS_MAPPINGS.update(RIG_NODES)
NODE_DISPLAY_NAME_MAPPINGS.update(RIG_NAMES)

@PromptServer.instance.routes.get('/lucas_character/rig_status')
async def rig_status(request):
    from .rig import check_unirig
    try:
        check_unirig()
        return web.json_response({'available': True})
    except Exception as exc:
        return web.json_response({'available': False, 'reason': str(exc)})

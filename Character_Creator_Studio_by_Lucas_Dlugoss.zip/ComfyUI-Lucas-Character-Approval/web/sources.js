import { rigPanel } from './rig.js';
import { app } from '../../scripts/app.js';
import { api } from '../../scripts/api.js';
import { t, languageButton } from './i18n.js';
import { performancePanel } from './performance.js';

export function requestViewSource(node) {
    const widget = name => node.widgets?.find(w => w.name === name);
    let mode = widget('source')?.value || 'Generate';
    const files = Object.fromEntries(['front','left','back','right','top','bottom'].map(a => [a,widget(a)?.value || '']));
    return new Promise(resolve => {
        const overlay=document.createElement('div');
        Object.assign(overlay.style,{position:'fixed',inset:'0',zIndex:'100010',background:'rgba(0,0,0,.85)',display:'flex',alignItems:'center',justifyContent:'center'});
        const panel=document.createElement('div');
        Object.assign(panel.style,{background:'#20242b',color:'white',padding:'24px',borderRadius:'12px',width:'850px',maxWidth:'92vw',maxHeight:'92vh',overflow:'auto',fontFamily:'sans-serif'});
        const title=document.createElement('h2'),help=document.createElement('p'),choices=document.createElement('div');
        const generate=document.createElement('button'),upload=document.createElement('button');
        choices.append(generate,upload);
        const uploadPanel=document.createElement('div'),hint=document.createElement('p'),cards=document.createElement('div');
        Object.assign(cards.style,{display:'flex',gap:'12px',flexWrap:'wrap'});
        const status=document.createElement('p');status.style.color='#ffdb87';
        let busy=false,errorKey='';
        const entries=[];
        const hardware=performancePanel();
        const rig=rigPanel();
        const next=document.createElement('button'),cancel=document.createElement('button');
        function finish(value){overlay.remove();resolve(value);}
        function render(){
            title.textContent=t('sourceTitle');help.textContent=t('sourceHelp');
            generate.textContent=t('sourceGenerate');upload.textContent=t('sourceUpload');
            generate.style.background=mode==='Generate'?'#287447':'#555';
            upload.style.background=mode==='Upload'?'#287447':'#555';
            uploadPanel.hidden=mode!=='Upload';hint.textContent=t('uploadHint');
            next.textContent=mode==='Upload'?t('uploadStart'):t('sourceNext');cancel.textContent=t('cancel');
            next.disabled=busy;cancel.disabled=busy;generate.disabled=busy;upload.disabled=busy;
            status.textContent=busy?t('uploadBusy'):errorKey?t(errorKey):'';
            hardware?.refreshLanguage();rig?.refreshLanguage();
            for(const e of entries){
                e.title.textContent=t(e.angle)+' — '+t(['top','bottom'].includes(e.angle)?'pbrOnly':'shapeAndPbr');e.pick.textContent=t('uploadChoose');e.remove.textContent=t('uploadRemove');
                e.name.textContent=files[e.angle]||t('uploadEmpty');
                e.pick.disabled=busy;e.remove.disabled=busy||!files[e.angle];
                e.image.hidden=!files[e.angle];
                if(files[e.angle]){
                    const path=files[e.angle],slash=path.lastIndexOf('/');
                    e.image.src=api.apiURL('/view?'+new URLSearchParams({filename:path.slice(slash+1),subfolder:slash<0?'':path.slice(0,slash),type:'input'}));
                }
            }
        }
        for(const angle of ['front','left','back','right','top','bottom']){
            const card=document.createElement('div');Object.assign(card.style,{flex:'1',minWidth:'180px',padding:'10px',border:'1px solid #555',borderRadius:'8px'});
            const title=document.createElement('h3'),image=document.createElement('img'),name=document.createElement('p');
            Object.assign(image.style,{maxWidth:'100%',height:'150px',objectFit:'contain'});name.style.overflowWrap='anywhere';
            const input=document.createElement('input');input.type='file';input.accept='image/png,image/jpeg,image/webp';input.hidden=true;
            const pick=document.createElement('button'),remove=document.createElement('button');
            pick.onclick=()=>input.click();
            remove.onclick=()=>{files[angle]='';errorKey='';render();};
            input.onchange=async()=>{
                const file=input.files?.[0];if(!file)return;
                busy=true;errorKey='';render();
                try{
                    const form=new FormData();form.append('image',file);form.append('type','input');form.append('subfolder','Lucas_Character/uploads');form.append('overwrite','false');
                    const response=await api.fetchApi('/upload/image',{method:'POST',body:form});
                    if(!response.ok)throw new Error('Upload HTTP '+response.status);
                    const data=await response.json();if(!data.name||data.type!=='input')throw new Error('Invalid upload response');
                    files[angle]=data.subfolder?data.subfolder+'/'+data.name:data.name;
                }catch(e){console.error('[Lucas upload]',e);errorKey='uploadFailed';}
                finally{busy=false;input.value='';render();}
            };
            card.append(title,image,name,input,pick,remove);cards.append(card);entries.push({angle,title,image,name,pick,remove});
        }
        generate.onclick=()=>{mode='Generate';errorKey='';render();};
        upload.onclick=()=>{mode='Upload';errorKey='';render();};
        next.onclick=()=>{
            if(busy)return;
            if(mode==='Upload'&&!['front','left','back','right'].some(a=>files[a])){errorKey='uploadRequired';render();return;}
            widget('source').value=mode;
            for(const angle of ['front','left','back','right','top','bottom'])widget(angle).value=files[angle];
            app.graph.setDirtyCanvas(true,true);finish(mode);
        };
        cancel.onclick=()=>{if(!busy)finish(null);};
        uploadPanel.append(hint,cards);
        panel.append(languageButton(render),title,help,choices,uploadPanel);
        if(hardware)panel.append(hardware);if(rig)panel.append(rig);
        panel.append(status,next,cancel);
        for(const button of [generate,upload,next,cancel,...entries.flatMap(e=>[e.pick,e.remove])])
            Object.assign(button.style,{color:'white',background:'#455569',border:'0',borderRadius:'6px',padding:'10px',margin:'4px',cursor:'pointer'});
        overlay.append(panel);document.body.append(overlay);render();
    });
}

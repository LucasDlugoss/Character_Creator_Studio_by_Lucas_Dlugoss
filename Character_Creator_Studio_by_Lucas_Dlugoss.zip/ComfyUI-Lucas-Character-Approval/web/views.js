import { app } from '../../scripts/app.js';
import { api } from '../../scripts/api.js';
import { t, angles, errorText } from './i18n.js';
let openReview = null;
function labelsForTitle(angle) { return t(angle || 'candidate'); }
function closeReview(token) {
    if (openReview?.token === token) {openReview.overlay.remove();openReview=null;}
}
function showReview(data) {
    if(openReview) openReview.overlay.remove();
    const overlay=document.createElement('div');
    Object.assign(overlay.style,{position:'fixed',inset:'0',zIndex:'100002',background:'rgba(0,0,0,.87)',display:'flex',alignItems:'center',justifyContent:'center'});
    const panel=document.createElement('div');
    Object.assign(panel.style,{background:'#20242b',color:'#fff',padding:'20px',borderRadius:'12px',maxWidth:'92vw',maxHeight:'95vh',overflow:'auto',fontFamily:'sans-serif'});
    const title=document.createElement('h2');title.textContent=t('review',{view:labelsForTitle(data.requested)});
    const text=document.createElement('p');text.textContent=t('viewHelp',{view:t(data.requested)});
    const filled=document.createElement('p');filled.textContent=t('assigned',{
        approved:angles(data.approved),skipped:angles(data.skipped||[]),pending:angles(data.pending||data.remaining)});
    panel.append(title,text,filled);
    for(const image of data.images){
        const img=document.createElement('img');img.src=api.apiURL('/view?'+new URLSearchParams({...image,rand:data.token}));
        Object.assign(img.style,{display:'block',maxHeight:'62vh',maxWidth:'85vw',margin:'0 auto 16px',objectFit:'contain'});panel.append(img);
    }
    const row=document.createElement('div');Object.assign(row.style,{display:'flex',gap:'8px',flexWrap:'wrap'});
    const status=document.createElement('p');status.style.color='#ffdb87';
    const buttons=[];
    for(const [label,action] of [[t('useFront'),'front'],[t('useLeft'),'left'],[t('useBack'),'back'],[t('retry'),'retry'],[t('skip'),'skip'],[t('finish'),'finish']]){
        const btn=document.createElement('button');btn.textContent=label;
        const available=action==='retry'||(action==='skip' && (data.approved.length>0 || (data.pending||data.remaining).length>1))||(action==='finish' && data.approved.length>0)||data.remaining.includes(action);btn.disabled=!available;
        Object.assign(btn.style,{padding:'12px',border:0,borderRadius:'6px',background:action==='retry'?'#9b5924':action==='skip'?'#586274':action==='finish'?'#286fb7':'#287447',color:'white',opacity:available?'1':'.35',cursor:available?'pointer':'default'});
        buttons.push({btn,available});row.append(btn);
        btn.onclick=async()=>{
            buttons.forEach(({btn})=>btn.disabled=true);
            try{
                const r=await api.fetchApi('/lucas_character_views/decide',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:data.token,action})});
                if(!r.ok) throw Error((await r.json()).error||'Could not submit your decision.');
                closeReview(data.token);
            }catch(e){status.textContent=errorText(e);buttons.forEach(({btn,available})=>btn.disabled=!available);}
        };
    }
    panel.append(row,status);
    const small=document.createElement('p');small.textContent=t('attempt',{attempt:data.attempt,seed:data.seed});panel.append(small);
    const hide=document.createElement('button');hide.textContent=t('hide');hide.onclick=()=>{overlay.remove();openReview=null;};panel.append(hide);
    overlay.append(panel);document.body.append(overlay);openReview={token:data.token,overlay};
}
api.addEventListener('lucas-view-review',e=>{
    if(app.graph.getNodeById(Number(e.detail.node_id))?.comfyClass==='LucasReviewThreeViews') showReview(e.detail);
});
api.addEventListener('lucas-view-review-closed',e=>closeReview(e.detail.token));
app.registerExtension({name:'Lucas.ViewReview',async beforeRegisterNodeDef(nodeType,nodeData){
    if(nodeData.name!=='LucasReviewThreeViews')return;
    const original=nodeType.prototype.onNodeCreated;
    nodeType.prototype.onNodeCreated=function(){
        original?.apply(this,arguments);
        this.addWidget('button','Open pending view review',null,async()=>{
            try{
                const r=await api.fetchApi('/lucas_character_views/pending?node_id='+encodeURIComponent(this.id));
                if(!r.ok)throw Error('Could not retrieve the pending view review.');
                const {reviews}=await r.json();
                if(!reviews.length){alert(t('noView'));return;}
                showReview(reviews[reviews.length-1]);
            }catch(e){alert(errorText(e));}
        },{serialize:false});
    };
}});

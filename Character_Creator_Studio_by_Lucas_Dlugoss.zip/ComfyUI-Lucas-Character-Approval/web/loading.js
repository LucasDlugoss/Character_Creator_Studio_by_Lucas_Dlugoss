import { app } from '../../scripts/app.js';
import { api } from '../../scripts/api.js';
import { t, languageButton } from './i18n.js';

const busyStates=new Set(['config','queued','running','review','stopping','offline']);
let screen,ui={},state='idle',stage='loadPreparing',percent=null,detail='',result='',promptId=null;
let submitting=false,retrying=false,editor=false,tipIndex=0,started=0,graphTypes={},review=null;
const supported=()=> (app.graph?._nodes||[]).some(n=>['LucasViewSource','LucasLoadPBRCheckpoint','LucasRigExistingGLB'].includes(n.comfyClass));
const isBusy=()=>busyStates.has(state);
const displayNode=id=>String(id??'').split('.')[0];
function render(){
    if(!screen)return;
    screen.hidden=editor||!supported();ui.back.hidden=!editor||!supported();
    ui.title.textContent=t('loadTitle');ui.stage.textContent=t(state==='idle'?'loadReady':state==='done'?'loadDone':state==='error'?'loadError':state==='cancelled'?'loadCancelled':state==='offline'?'loadOffline':state==='review'?'loadReview':state==='stopping'?'loadStopping':stage);
    ui.help.textContent=t(state==='running'||state==='queued'?'loadWait':'loadIntro');
    ui.progress.hidden=!['running','queued','stopping'].includes(state);
    if(percent===null)ui.progress.removeAttribute('value');else ui.progress.value=percent;
    ui.progressText.textContent=percent===null?(state==='running'?t('loadUnknown'):''):t('loadPercent',{value:percent});
    ui.tip.textContent=t('loadTip'+tipIndex);
    ui.elapsed.textContent=started&&isBusy()?t('loadElapsed',{seconds:Math.floor((Date.now()-started)/1000)}):'';
    ui.start.textContent=t('loadStart');ui.start.disabled=isBusy();
    ui.cancel.textContent=t('cancel');ui.cancel.hidden=!['queued','running','review'].includes(state);ui.cancel.disabled=!promptId;
    ui.editor.textContent=t('loadEditor');ui.back.textContent=t('loadReturn');
    ui.review.textContent=t('loadOpenReview');ui.review.hidden=state!=='review';
    ui.blend.hidden=!blendReady;ui.blend.textContent=t('rigBlend');
    ui.blend.href=api.apiURL('/lucas_character/download?'+new URLSearchParams({path:result.replace(/\.glb$/,'.blend')}));
    ui.download.hidden=!result;ui.download.textContent=t('loadDownload');
    ui.download.href=api.apiURL('/lucas_character/download?'+new URLSearchParams({path:result}));
    ui.support.hidden=state!=='done'||!blendReady;
    ui.supportMessage.textContent=t('supportMessage');ui.supportLink.textContent=t('supportLink');
    ui.details.hidden=!detail;ui.summary.textContent=t('loadDetails');ui.error.textContent=detail;
}
function mount(){
    if(screen)return;
    screen=document.createElement('div');screen.id='lucas-guided-screen';
    Object.assign(screen.style,{position:'fixed',inset:'0',zIndex:'99990',background:'#0d121c',color:'#edf3ff',overflow:'auto',fontFamily:'system-ui,sans-serif'});
    const card=document.createElement('main');Object.assign(card.style,{maxWidth:'760px',margin:'8vh auto',padding:'32px',boxSizing:'border-box'});
    const el=(tag,key)=>ui[key]=document.createElement(tag);
    el('h1','title');el('h2','stage');el('p','help');el('progress','progress');ui.progress.max=100;ui.progress.style.width='100%';ui.progress.style.height='18px';
    el('p','progressText');ui.progressText.setAttribute('aria-live','polite');el('p','elapsed');el('p','tip');Object.assign(ui.tip.style,{padding:'20px',background:'#192539',borderRadius:'12px',lineHeight:'1.6'});
    const actions=document.createElement('div');Object.assign(actions.style,{display:'flex',gap:'10px',flexWrap:'wrap'});
    for(const key of ['start','cancel','review','editor']){
        el('button',key);Object.assign(ui[key].style,{padding:'12px 18px',borderRadius:'8px',border:'1px solid #62738d',background:key==='start'?'#256c52':'#202d41',color:'white',cursor:'pointer'});actions.append(ui[key]);
    }
    el('a','download');ui.download.style.margin='20px 0';ui.download.style.color='#9dd9ff';ui.download.download='character.glb';
    el('a','blend');ui.blend.style.color='#9dd9ff';ui.blend.style.margin='20px';
    el('section','support');Object.assign(ui.support.style,{marginTop:'24px',padding:'20px',border:'1px solid #35445c',borderRadius:'12px'});
    el('p','supportMessage');ui.supportMessage.style.lineHeight='1.6';
    el('a','supportLink');ui.supportLink.href='https://ko-fi.com/lucasdlugoss';ui.supportLink.target='_blank';ui.supportLink.rel='noopener noreferrer';ui.supportLink.style.color='#9dd9ff';
    ui.support.append(ui.supportMessage,ui.supportLink);
    el('details','details');el('summary','summary');el('pre','error');ui.error.style.whiteSpace='pre-wrap';ui.details.append(ui.summary,ui.error);
    ui.start.onclick=async()=>{if(isBusy())return;try{await app.queuePrompt(0,1);}catch(e){failed(e);}};
    ui.cancel.onclick=cancelRun;ui.editor.onclick=()=>{editor=true;render();};
    ui.review.onclick=()=>{if(review)api.dispatchEvent(new CustomEvent(review.type,{detail:review.data}));};
    el('button','back');Object.assign(ui.back.style,{position:'fixed',right:'20px',bottom:'20px',zIndex:'99991',padding:'12px',background:'#256c52',color:'white',borderRadius:'8px'});
    ui.back.onclick=()=>{editor=false;render();};
    card.append(languageButton(render),ui.title,ui.stage,ui.help,ui.progress,ui.progressText,ui.elapsed,ui.tip,actions,ui.download,ui.blend,ui.support,ui.details);
    screen.append(card);document.body.append(screen,ui.back);render();
}
function update(next,key){state=next;if(key)stage=key;percent=null;render();}
export function beginSelection(){if(!supported())return;mount();editor=false;detail='';update('config','loadPreparing');}
export function selectionCancelled(){if(state==='config')update('idle');}
export function expectFrontRetry(){retrying=true;review=null;update('queued','loadQueued');}
export function failed(error){detail=String(error?.message||error?.exception_message||error||'');submitting=false;retrying=false;update('error');}
function ours(data){return promptId && (!data?.prompt_id || data.prompt_id===promptId);}
function nodeStage(id){
    const type=graphTypes[displayNode(id)]||'';
    if(type==='LucasReviewThreeViews')return 'loadViews';
    if(type==='KSampler')return displayNode(id)==='16'?'loadFront':'loadShape';
    if(type==='LucasAutomaticRig'||type.startsWith('LucasUniRig')||type.startsWith('UniRig'))return 'loadRig';
    if(type==='LucasPBRPaint21')return 'loadTexture';
    if(/Mesh|MESH|Voxel|Hunyuan3D/.test(type))return 'loadMesh';
    if(/Save|Preview3D/.test(type))return 'loadExport';
    return 'loadPreparing';
}
async function cancelRun(){
    if(!promptId)return;
    const own=promptId;update('stopping');
    try{
        const response=await api.fetchApi('/queue');if(!response.ok)throw Error('Could not read queue.');
        const q=await response.json();
        if((q.queue_running||[]).some(row=>row[1]===own)){
            const r=await api.fetchApi('/interrupt',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt_id:own})});if(!r.ok)throw Error('Could not interrupt execution.');
        }else if((q.queue_pending||[]).some(row=>row[1]===own)){
            const r=await api.fetchApi('/queue',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({delete:[own]})});if(!r.ok)throw Error('Could not remove queued execution.');update('cancelled');
        }else await reconcile();
    }catch(e){failed(e);}
}
let blendReady=false;
function captureOutput(output){if(output?.lucas_blend?.[0])blendReady=true;if(output?.lucas_result?.[0]){const incoming=output.lucas_result[0];if(result.endsWith('_rigged.glb')&&!incoming.endsWith('_rigged.glb'))return;result=incoming;render();}}
async function reconcile(){
    if(!promptId)return;
    try{
        const r=await api.fetchApi('/history/'+encodeURIComponent(promptId));if(!r.ok)throw Error('History unavailable');
        const h=(await r.json())[promptId];
        if(h){
            for(const output of Object.values(h.outputs||{}))captureOutput(output);
            if(h.status?.status_str==='success'){update('done');return;}
            if(h.status?.status_str==='error'){failed(JSON.stringify(h.status.messages||[]));return;}
        }
        const q=await api.fetchApi('/queue');if(!q.ok)throw Error('Queue unavailable');const data=await q.json();
        if((data.queue_running||[]).some(row=>row[1]===promptId)){
            update('running','loadPreparing');
            for(const [cls,path,type] of [
                ['LucasCharacterApproval','/lucas_character_approval/pending','lucas-character-review'],
                ['LucasReviewThreeViews','/lucas_character_views/pending','lucas-view-review']]){
                const node=(app.graph?._nodes||[]).find(n=>n.comfyClass===cls);if(!node)continue;
                const response=await api.fetchApi(path+'?node_id='+encodeURIComponent(node.id));
                if(response.ok){const pending=(await response.json()).reviews||[];
                    if(pending.length)api.dispatchEvent(new CustomEvent(type,{detail:pending[pending.length-1]}));}
            }
        }
        else if((data.queue_pending||[]).some(row=>row[1]===promptId))update('queued','loadQueued');
        else {update('offline');detail=t('loadUnconfirmed');render();}
    }catch(e){update('offline');detail=String(e);render();}
}
app.registerExtension({name:'Lucas.GuidedLoading',
    async setup(){
        mount();
        const original=api.queuePrompt;
        api.queuePrompt=async function(number,payload,...rest){
            const output=payload?.output||{};
            if(!Object.values(output).some(n=>['LucasViewSource','LucasLoadPBRCheckpoint','LucasRigExistingGLB'].includes(n.class_type)))return original.call(this,number,payload,...rest);
            submitting=true;promptId=null;result='';blendReady=false;detail='';review=null;started=Date.now();
            graphTypes=Object.fromEntries(Object.entries(output).map(([id,n])=>[id,n.class_type]));
            update('queued','loadQueued');
            try{
                const response=await original.call(this,number,payload,...rest);
                if(response?.error)throw Error(JSON.stringify(response.error));
                if(!response?.prompt_id)throw Error('No prompt ID returned by ComfyUI.');
                promptId=response.prompt_id;submitting=false;retrying=false;render();return response;
            }catch(e){failed(e);throw e;}
        };
        // Some frontend versions expose executing.detail as a node ID rather
        // than the original server object. Progress still carries prompt_id.
        api.addEventListener('execution_start',e=>{
            if(submitting&&!promptId)promptId=e.detail.prompt_id;
            if(ours(e.detail))update('running','loadPreparing');
        });
        api.addEventListener('executing',e=>{
            const d=typeof e.detail==='object'&&e.detail!==null?e.detail:{node:e.detail};
            if(!ours(d)||!isBusy()||state==='config'||retrying)return;
            if(d.node!==null&&d.node!==undefined)update('running',nodeStage(d.display_node||d.node));
        });
        api.addEventListener('progress',e=>{
            const d=e.detail;if(!ours(d)||!['running','queued'].includes(state))return;
            if(Number.isFinite(d.value)&&Number.isFinite(d.max)&&d.max>0){state='running';percent=Math.min(100,Math.max(0,Math.round(100*d.value/d.max)));render();}
        });
        api.addEventListener('executed',e=>{if(ours(e.detail))captureOutput(e.detail.output);});
        api.addEventListener('execution_success',e=>{if(ours(e.detail)&&!retrying){update('done');if(!result)setTimeout(reconcile,500);}});
        api.addEventListener('execution_error',e=>{if(ours(e.detail))failed(e.detail);});
        api.addEventListener('execution_interrupted',e=>{if(ours(e.detail)&&!retrying)update('cancelled');});
        for(const type of ['lucas-character-review','lucas-view-review'])api.addEventListener(type,e=>{
            if(!promptId||!isBusy()||!app.graph.getNodeById(Number(e.detail.node_id)))return;
            review={type,data:e.detail};update('review');
        });
        for(const type of ['lucas-character-review-closed','lucas-view-review-closed'])api.addEventListener(type,e=>{
            if(review?.data.token===e.detail.token){review=null;if(state==='review')update('running','loadPreparing');}
        });
        api.addEventListener('reconnecting',()=>{if(isBusy()&&state!=='config')update('offline');});
        api.addEventListener('reconnected',()=>{if(state==='offline')reconcile();});
        setInterval(()=>{if(screen&&!screen.hidden){tipIndex=(tipIndex+1)%4;render();}},10000);
        setInterval(()=>{if(screen&&!screen.hidden&&isBusy())render();},1000);
    },
    afterConfigureGraph(){
        mount();editor=false;render();
    }
});

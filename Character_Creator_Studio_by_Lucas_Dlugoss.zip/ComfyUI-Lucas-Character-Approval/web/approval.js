import { requestExistingRig } from './rig.js';
import { beginSelection, selectionCancelled, expectFrontRetry, failed } from './loading.js';
import { app } from '../../scripts/app.js';
import { api } from '../../scripts/api.js';
import { requestCharacterPrompt, getDescriptionWidget } from './prompt.js';
import { requestViewSource } from './sources.js';
import { t, errorText } from './i18n.js';
const reviews = new Map();
let active = null;
let reusePromptOnce = false;
function dismiss(token) {
    if (active?.token === token) { active.overlay.remove(); active = null; }
    reviews.delete(token);
}
function freshSeed(samplerId) {
    const sampler = app.graph.getNodeById(Number(samplerId));
    if (!sampler || sampler.comfyClass !== 'KSampler') throw new Error('Front KSampler not found. Check front_sampler_id on the concept review node.');
    const seed = sampler.widgets?.find(w => w.name === 'seed');
    if (!seed) throw new Error('The front KSampler has no seed widget.');
    const bytes = crypto.getRandomValues(new Uint32Array(2));
    seed.value = (bytes[0] & 0x1fffff) * 4294967296 + bytes[1];
    app.graph.setDirtyCanvas(true, true);
}
function showReview(data) {
    if (active) active.overlay.remove();
    const overlay = document.createElement('div');
    Object.assign(overlay.style, {position:'fixed', inset:'0', zIndex:'100000', background:'rgba(0,0,0,.85)', display:'flex', alignItems:'center', justifyContent:'center'});
    const panel = document.createElement('div');
    Object.assign(panel.style, {background:'#20242b', color:'#fff', padding:'20px', borderRadius:'12px', maxWidth:'90vw', maxHeight:'95vh', overflow:'auto', fontFamily:'sans-serif'});
    const title = document.createElement('h2'); title.textContent = t('frontTitle'); panel.append(title);
    const caption = document.createElement('p'); caption.textContent = t('frontHelp'); panel.append(caption);
    for (const image of data.images) {
        const img = document.createElement('img');
        img.src = api.apiURL('/view?' + new URLSearchParams({...image, rand: data.token}));
        Object.assign(img.style, {display:'block', maxHeight:'65vh', maxWidth:'80vw', margin:'0 auto 16px', objectFit:'contain'});
        panel.append(img);
    }
    const row = document.createElement('div'); Object.assign(row.style,{display:'flex', gap:'10px', flexWrap:'wrap'});
    const status = document.createElement('p'); status.style.color='#ffdb87';
    const buttons = [];
    for (const [label, action, color] of [
        [t('approve'),'approve','#287447'],
        [t('reject'),'reject','#9b5924'],
        [t('stop'),'cancel','#555']]) {
        const btn = document.createElement('button'); btn.textContent=label;
        Object.assign(btn.style,{background:color,color:'white',border:'0',borderRadius:'6px',padding:'12px',cursor:'pointer'});
        buttons.push(btn); row.append(btn);
        btn.onclick = async () => {
            buttons.forEach(b => b.disabled=true);
            try {
                // Set a genuinely new front seed before queueing, regardless of cache.
                if (action === 'reject') { freshSeed(data.front_sampler_id); expectFrontRetry(); }
                const res = await api.fetchApi('/lucas_character_approval/decide', {
                    method:'POST', headers:{'Content-Type':'application/json'},
                    body:JSON.stringify({token:data.token, action})
                });
                if (!res.ok) throw new Error((await res.json()).error || 'Could not submit your decision.');
                dismiss(data.token);
                // Rejection interrupts only the current run. Queue a fresh copy of the graph.
                if (action === 'reject') {
                    try { reusePromptOnce = true; await app.queuePrompt(0, 1); }
                    catch (e) { alert(t('queuedFailed') + '\n' + errorText(e)); }
                    finally { reusePromptOnce = false; }
                }
            } catch (e) { status.textContent=errorText(e); buttons.forEach(b=>b.disabled=false); }
        };
    }
    panel.append(row, status);
    const hide = document.createElement('button'); hide.textContent=t('hide');
    hide.style.marginTop='12px'; hide.onclick=()=>{overlay.remove();active=null;}; panel.append(hide);
    overlay.append(panel); document.body.append(overlay); active={token:data.token,overlay};
}
api.addEventListener('lucas-character-review', e => {
    const node=app.graph.getNodeById(Number(e.detail.node_id));
    if (node?.comfyClass !== 'LucasCharacterApproval') return;
    reviews.set(e.detail.token,e.detail); showReview(e.detail);
});
api.addEventListener('lucas-character-review-closed', e=>dismiss(e.detail.token));
app.registerExtension({
    name:'Lucas.CharacterApproval',
    async setup() {
        const originalQueue=app.queuePrompt;
        const submit=async(context,args)=>{
            try{return await originalQueue.apply(context,args);}
            catch(e){failed(e);throw e;}
            finally{selectionCancelled();}
        };
        let choosing = false;
        app.queuePrompt=async function(...args) {
            if (choosing) return;
            beginSelection();
            const existingRig=(app.graph?._nodes||[]).find(n=>n.comfyClass==='LucasRigExistingGLB' && n.mode!==2 && n.mode!==4);
            if(existingRig){
                choosing=true;let accepted;
                try{accepted=await requestExistingRig(existingRig);}finally{choosing=false;}
                if(!accepted){selectionCancelled();return;}
                return await submit(this,args);
            }
            const source=(app.graph?._nodes || []).find(n=>n.comfyClass==='LucasViewSource' && n.mode!==2 && n.mode!==4);
            let sourceMode=source?.widgets?.find(w=>w.name==='source')?.value;
            if (source && !reusePromptOnce) {
                choosing=true;
                try { sourceMode=await requestViewSource(source); }
                finally { choosing=false; }
                if(sourceMode===null){selectionCancelled();return;}
            }
            if(sourceMode==='Upload')return await submit(this,args);
            const nodes=(app.graph?._nodes || []).filter(n=>n.comfyClass==='LucasCharacterPrompt' && n.mode !== 2 && n.mode !== 4);
            if (nodes.length) {
                const reuse=reusePromptOnce;
                reusePromptOnce=false;
                for (const node of nodes) {
                    if (reuse && getDescriptionWidget(node).value?.trim()) continue;
                    const text=await requestCharacterPrompt(node);
                    if (text===null) {selectionCancelled();return;} // Cancelled: nothing is sent to the server.
                }
            }
            return await submit(this,args);
        };
    },
    async beforeRegisterNodeDef(nodeType,nodeData) {
        if (nodeData.name === 'LucasCharacterPrompt') {
            const original=nodeType.prototype.onNodeCreated;
            nodeType.prototype.onNodeCreated=function() {
                original?.apply(this,arguments);
                this.properties=this.properties||{};
                this.addWidget('button','Edit character description',null,()=>requestCharacterPrompt(this),{serialize:false});
                this.size=[420,260];
            };
            return;
        }
        if (nodeData.name !== 'LucasCharacterApproval') return;
        const original=nodeType.prototype.onNodeCreated;
        nodeType.prototype.onNodeCreated=function() {
            original?.apply(this,arguments);
            this.addWidget('button','Open pending concept review',null, async()=>{
                try {
                    const res=await api.fetchApi('/lucas_character_approval/pending?node_id='+encodeURIComponent(this.id));
                    if (!res.ok) throw new Error('Could not retrieve the pending concept review.');
                    const {reviews:pending}=await res.json();
                    if (!pending.length) {alert(t('noConcept'));return;}
                    const data=pending[pending.length-1]; reviews.set(data.token,data); showReview(data);
                } catch(e) {alert(errorText(e));}
            }, {serialize:false});
            this.size=[380,150];
        };
    }
});

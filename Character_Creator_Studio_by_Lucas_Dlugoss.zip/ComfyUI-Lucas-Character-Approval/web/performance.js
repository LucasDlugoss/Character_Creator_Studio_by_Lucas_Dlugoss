import { app } from '../../scripts/app.js';
import { api } from '../../scripts/api.js';
import { t, errorText } from './i18n.js';

function values(node) {
    const data = {mode:'Automatic',manual:{}};
    for(const w of node.widgets||[]){
        if(w.name==='mode')data.mode=w.value;
        if(w.name.startsWith('manual_'))data.manual[w.name.slice(7)]=w.value;
    }
    return data;
}
async function preview(node){
    const response=await api.fetchApi('/lucas_character/performance',{
        method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(values(node))
    });
    const data=await response.json();
    if(!response.ok)throw new Error(data.error||'Hardware detection failed.');
    return data;
}
function summary(data, lang){
    const tr=(key,vars={})=>t(key,vars,lang);
    const h=data.hardware,s=data.settings;
    const lines=[
        tr('hardware',{gpu:h.gpu,total:h.vram_total_gb.toFixed(1),free:h.vram_free_gb.toFixed(1),ram:h.ram_total_gb.toFixed(0)}),
        tr('sizing',{mode:tr(data.mode),tier:tr(data.tier),concept:s.concept_size,views:s.view_size,cs:s.concept_steps,vs:s.view_steps,ss:s.shape_steps}),
        tr('pbr',{octree:s.octree,pbr:s.pbr_view_size,atlas:s.texture_size,steps:s.pbr_steps})
    ];
    for(const warning of data.warnings||[]){
        const key=warning.startsWith('Transient GPU')?'gpuPressure':warning.startsWith('Low available')?'lowram':warning.startsWith('Quality limited')?'limited':'estimated';
        lines.push(tr(key));
    }
    return lines.join('\n');
}
export function performancePanel(){
    const node=(app.graph?._nodes||[]).find(n=>n.comfyClass==='LucasHardwareProfile'&&n.mode!==2&&n.mode!==4);
    if(!node)return null;
    const panel=document.createElement('div');panel.style.margin='12px 0';
    const label=document.createElement('label');
    const select=document.createElement('select');
    for(const name of ['Automatic','Speed','Quality','Manual']){
        const option=document.createElement('option');option.value=name;option.textContent=t(name);select.append(option);
    }
    select.value=values(node).mode;
    const info=document.createElement('pre');Object.assign(info.style,{whiteSpace:'pre-wrap',fontSize:'12px',color:'#c5e6ff'});
    let version=0,last=null,lastError=null;
    panel.refreshLanguage=()=>{
        label.textContent=t('performance')+': ';
        for(const option of select.options)option.textContent=t(option.value);
        info.textContent=last?summary(last):lastError?errorText(lastError):t('detecting');
    };
    const refresh=async()=>{
        const current=++version;last=null;lastError=null;panel.refreshLanguage();
        try{const data=await preview(node);if(current===version){last=data;panel.refreshLanguage();}}
        catch(e){if(current===version){lastError=e;panel.refreshLanguage();}}
    };
    select.onchange=()=>{node.widgets.find(w=>w.name==='mode').value=select.value;app.graph.setDirtyCanvas(true,true);refresh();};
    panel.append(label,select,info);refresh();return panel;
}
app.registerExtension({name:'Lucas.HardwareProfile',async beforeRegisterNodeDef(nodeType,nodeData){
    if(nodeData.name!=='LucasHardwareProfile')return;
    const created=nodeType.prototype.onNodeCreated;
    nodeType.prototype.onNodeCreated=function(){
        created?.apply(this,arguments);
        this.addWidget('button','Detect GPU / show profile',null,async()=>{
            try{alert(summary(await preview(this)));}catch(e){alert(errorText(e));}
        },{serialize:false});
        const area=document.createElement('textarea');area.readOnly=true;area.style.width='100%';area.style.height='100%';
        area.placeholder='The effective profile appears here when executed. manual_* fields only apply in Manual mode.';
        this.addDOMWidget('performance_report','text',area,{serialize:false});this.lucasPerformanceReport=area;
    };
    const executed=nodeType.prototype.onExecuted;
    nodeType.prototype.onExecuted=function(message){
        executed?.apply(this,arguments);
        if(this.lucasPerformanceReport&&message?.text?.[0]){
            try{this.lucasPerformanceReport.value=summary(JSON.parse(message.text[0]),'en');}
            catch{this.lucasPerformanceReport.value=message.text.join('\n');}
        }
    };
}});

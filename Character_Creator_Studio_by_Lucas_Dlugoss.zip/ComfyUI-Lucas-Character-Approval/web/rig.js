import { app } from '../../scripts/app.js';
import { api } from '../../scripts/api.js';
import { t } from './i18n.js';

export function rigPanel(){
    const node=(app.graph?._nodes||[]).find(n=>n.comfyClass==='LucasAutomaticRig');
    if(!node)return null;
    const widget=name=>node.widgets?.find(w=>w.name===name);
    const box=document.createElement('fieldset'),legend=document.createElement('legend');
    const label=document.createElement('label'),check=document.createElement('input');check.type='checkbox';
    const text=document.createElement('span'),seed=document.createElement('input');seed.type='number';seed.min='0';seed.max='4294967295';seed.step='1';
    const seedLabel=document.createElement('label'),hint=document.createElement('p'),status=document.createElement('p');
    check.checked=widget('rig_preset')?.value==='UniRig';seed.value=String(widget('seed')?.value??42);
    let available=null,reason='';
    function refresh(){
        legend.textContent=t('rigTitle');text.textContent=t('rigEnable');hint.textContent=t('rigHint');
        seedLabel.textContent=t('rigSeed');seed.disabled=!check.checked;
        status.textContent=available===null?t('rigChecking'):available?t('rigReady'):(reason?t('rigMissing')+' ['+reason+']':t('rigMissing'));
        status.style.color=available?'#afe1b9':'#ffdb87';
    }
    function commit(){
        if(widget('rig_preset'))widget('rig_preset').value=check.checked?'UniRig':'None';
        const value=Number(seed.value);
        if(widget('seed'))widget('seed').value=Number.isInteger(value)?Math.max(0,Math.min(4294967295,value)):42;
        app.graph.setDirtyCanvas(true,true);refresh();
    }
    check.onchange=commit;seed.onchange=commit;
    label.append(check,text);box.append(legend,label,seedLabel,seed,hint,status);box.refreshLanguage=refresh;
    api.fetchApi('/lucas_character/rig_status').then(r=>r.json()).then(d=>{available=!!d.available;reason=d.reason||'';refresh();}).catch(e=>{available=false;reason=String(e||'');refresh();});
    refresh();return box;
}

export function requestExistingRig(node){
    return new Promise(resolve=>{
        const overlay=document.createElement('div');
        Object.assign(overlay.style,{position:'fixed',inset:'0',zIndex:'100010',background:'rgba(0,0,0,.85)',display:'flex',alignItems:'center',justifyContent:'center'});
        const panel=document.createElement('div');Object.assign(panel.style,{background:'#20242b',color:'white',padding:'24px',borderRadius:'12px',width:'min(700px,90vw)',fontFamily:'sans-serif'});
        const title=document.createElement('h2');title.textContent=t('rigTitle');
        const help=document.createElement('p');help.textContent=t('rigExisting');
        const input=document.createElement('input');input.type='text';input.style.width='100%';
        const widget=node.widgets?.find(w=>w.name==='glb_path');input.value=widget?.value||'';
        const rig=rigPanel(),run=document.createElement('button'),cancel=document.createElement('button');
        run.textContent=t('submit');cancel.textContent=t('cancel');
        run.onclick=()=>{if(!input.value.trim())return;if(widget)widget.value=input.value.trim();app.graph.setDirtyCanvas(true,true);overlay.remove();resolve(true);};
        cancel.onclick=()=>{overlay.remove();resolve(false);};
        panel.append(title,help,input);if(rig)panel.append(rig);panel.append(run,cancel);overlay.append(panel);document.body.append(overlay);input.focus();
    });
}

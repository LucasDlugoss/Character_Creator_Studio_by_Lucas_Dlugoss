import { rigPanel } from './rig.js';
import { app } from '../../scripts/app.js';
import { performancePanel } from './performance.js';
import { t, languageButton } from './i18n.js';
let dialogOpen = false;
export function getDescriptionWidget(node) {
    const widget = node.widgets?.find(w => w.name === 'description');
    if (!widget) throw new Error('Outdated Lucas node definition. Replace the node folder, restart ComfyUI and reload this browser tab.');
    return widget;
}
export function commitDescription(node, value) {
    const widget = getDescriptionWidget(node);
    const text = value.trim();
    if (!text) throw new Error(t('empty'));
    widget.value = text;
    node.properties = node.properties || {};
    node.properties.last_prompt = text;
    app.graph.setDirtyCanvas(true, true);
    return text;
}
export async function requestCharacterPrompt(node) {
    const descriptionWidget = getDescriptionWidget(node);
    if(!node.widgets?.find(w=>w.name==='anatomy_mode'))throw new Error('Update the v15 node package, restart ComfyUI, reload the browser and import the v15 JSON.');
    if (dialogOpen) return null;
    dialogOpen = true;
    return new Promise(resolve => {
        const overlay = document.createElement('div');
        Object.assign(overlay.style,{position:'fixed',inset:'0',zIndex:'100001',background:'rgba(0,0,0,.85)',display:'flex',alignItems:'center',justifyContent:'center'});
        const panel=document.createElement('div');
        Object.assign(panel.style,{background:'#20242b',color:'#fff',padding:'24px',borderRadius:'12px',width:'min(720px,90vw)',maxHeight:'95vh',overflow:'auto',fontFamily:'sans-serif'});
        const title=document.createElement('h2');
        const explanation=document.createElement('p');
        const input=document.createElement('textarea');
        input.value=descriptionWidget.value || node.properties?.last_prompt || '';
        Object.assign(input.style,{boxSizing:'border-box',width:'100%',height:'260px',resize:'vertical',fontSize:'16px',padding:'12px',background:'#101318',color:'white',border:'1px solid #59616e',borderRadius:'6px'});
        const error=document.createElement('p');error.style.color='#ffdb87';
        const row=document.createElement('div');Object.assign(row.style,{display:'flex',gap:'12px',marginTop:'16px'});
        const submit=document.createElement('button');submit.textContent=t('submit');
        const cancel=document.createElement('button');cancel.textContent=t('cancel');
        for(const b of [submit,cancel]) Object.assign(b.style,{padding:'12px 24px',color:'white',background:b===submit?'#287447':'#555',border:'0',borderRadius:'6px',cursor:'pointer'});
        const finish=value=>{document.removeEventListener('keydown',onKey,true);overlay.remove();dialogOpen=false;resolve(value);};
        const send=()=>{
            const text=input.value.trim();
            if(!text){error.textContent=t('empty');input.focus();return;}
            commitDescription(node, text);finish(text);
        };
        const onKey=e=>{
            if(e.key==='Escape'){e.preventDefault();e.stopPropagation();finish(null);}
            else if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();e.stopPropagation();send();}
        };
        submit.onclick=send;cancel.onclick=()=>finish(null);
        document.addEventListener('keydown',onKey,true);
        const hardwarePanel=performancePanel();
        const rig=rigPanel();
        const anatomyWidget=node.widgets?.find(w=>w.name==='anatomy_mode');
        const anatomyLabel=document.createElement('button');anatomyLabel.type='button';
        const poseDescription=document.createElement('p');poseDescription.style.color='#c5e6ff';
        const anatomySelect=document.createElement('select');
        for(const name of ["Natural anatomy", "Humanoid T-pose", "Quadruped animal", "Reptile quadruped", "Bipedal reptile", "Bird spread wings", "Aquatic creature", "Tentacled creature", "Arthropod", "Serpentine creature"]){
            const option=document.createElement('option');option.value=name;anatomySelect.append(option);
        }
        anatomySelect.value=anatomyWidget?.value||'Natural anatomy';
        anatomySelect.hidden=true;
        anatomyLabel.onclick=()=>{anatomySelect.hidden=!anatomySelect.hidden;if(!anatomySelect.hidden)anatomySelect.focus();};
        anatomySelect.onchange=()=>{if(anatomyWidget){anatomyWidget.value=anatomySelect.value;app.graph.setDirtyCanvas(true,true);anatomySelect.hidden=true;renderLanguage();}};
        const anatomyHint=document.createElement('p');anatomyHint.style.fontSize='13px';
        const hint=document.createElement('p');hint.style.fontSize='12px';
        const renderLanguage=()=>{
            anatomyLabel.textContent=t('choosePreset')+': '+t(anatomySelect.value);
            poseDescription.textContent=t('pose_'+anatomySelect.value);
            for(const option of anatomySelect.options)option.textContent=t(option.value);
            anatomyHint.textContent=t('anatomyHint');
            title.textContent=t('title');explanation.textContent=t('intro');input.placeholder=t('example');
            submit.textContent=t('submit');cancel.textContent=t('cancel');hint.textContent=t('manualHint');
            if(error.textContent)error.textContent=t('empty');
            hardwarePanel?.refreshLanguage?.();rig?.refreshLanguage();
        };
        const language=languageButton(renderLanguage);renderLanguage();
        row.append(submit,cancel);panel.append(language,title,explanation,anatomyLabel,anatomySelect,poseDescription,anatomyHint);if(hardwarePanel)panel.append(hardwarePanel);if(rig)panel.append(rig);panel.append(input,hint,error,row);overlay.append(panel);document.body.append(overlay);input.focus();
    });
}

import { app } from '../../scripts/app.js';
app.registerExtension({
    name: 'Lucas.PromptAudit',
    async beforeRegisterNodeDef(nodeType, nodeData) {
        if (nodeData.name !== 'LucasBuildCharacterPrompt') return;
        const created = nodeType.prototype.onNodeCreated;
        nodeType.prototype.onNodeCreated = function () {
            created?.apply(this, arguments);
            const element = document.createElement('textarea');
            element.readOnly = true;
            element.placeholder = 'Exact positive prompt appears here when this node executes.';
            Object.assign(element.style, { width: '100%', height: '100%', resize: 'none', boxSizing: 'border-box', background: '#111820', color: '#e8eef5', padding: '12px', fontSize: '13px' });
            this.addDOMWidget('prompt_audit', 'text', element, { serialize: false });
            this.lucasAuditElement = element;
            this.size = [430,480];
        };
        const executed = nodeType.prototype.onExecuted;
        nodeType.prototype.onExecuted = function (message) {
            executed?.apply(this, arguments);
            if (this.lucasAuditElement && Array.isArray(message?.text)) {
                this.lucasAuditElement.value = message.text.join('\n');
            }
        };
    }
});

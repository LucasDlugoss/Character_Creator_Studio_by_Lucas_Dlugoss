"""Image-source routing, applied before ComfyUI prompt validation."""
from copy import deepcopy
from pathlib import Path
import hashlib

ANGLES = ('front', 'left', 'back', 'right', 'top', 'bottom')
SHAPE_ANGLES = ('front', 'left', 'back', 'right')


def route_sources(data):
    prompt = data.get('prompt', {})
    routers = [k for k, n in prompt.items() if n.get('class_type') == 'LucasViewSource']
    uploads = [k for k in routers if prompt[k].get('inputs', {}).get('source') == 'Upload']
    if not uploads:
        return data
    # This dedicated workflow has one source selector. Leave invalid configurations
    # to VALIDATE_INPUTS, rather than silently choosing one of several selectors.
    if len(routers) != 1:
        return data
    result = deepcopy(data)
    graph = result['prompt']
    root = uploads[0]
    graph[root]['inputs'].pop('generated_views', None)
    def parents(node):
        return {str(v[0]) for v in node.get('inputs', {}).values()
                if isinstance(v, list) and len(v) == 2 and str(v[0]) in graph}
    # Keep the source and its downstream 3D/texture/export nodes, then their
    # dependencies. Independent generation output nodes must not execute.
    keep = {root}
    while True:
        grown = keep | {k for k, n in graph.items() if parents(n) & keep}
        if grown == keep:
            break
        keep = grown
    pending = list(keep)
    while pending:
        for p in parents(graph[pending.pop()]):
            if p not in keep:
                keep.add(p)
                pending.append(p)
    result['prompt'] = {k: n for k, n in graph.items() if k in keep}
    if isinstance(result.get('partial_execution_targets'), list):
        result['partial_execution_targets'] = [k for k in result['partial_execution_targets'] if str(k) in keep]
    return result


def image_path(value):
    import folder_paths
    root = Path(folder_paths.get_input_directory()).resolve()
    path = (root / value).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        raise ValueError('Uploaded view is missing or outside the input folder: ' + value)
    return path


def load_view(value):
    import numpy as np
    import torch
    from PIL import Image, ImageOps
    with Image.open(image_path(value)) as raw:
        im = ImageOps.exif_transpose(raw).convert('RGBA')
        im.thumbnail((2048, 2048), Image.Resampling.LANCZOS)
        background = Image.new('RGBA', im.size, 'white')
        background.alpha_composite(im)
        # Pad instead of distorting the animal's proportions.
        im = ImageOps.pad(background.convert('RGB'), (max(im.size),) * 2, color='white')
        arr = np.asarray(im, dtype=np.float32) / 255.0
    return torch.from_numpy(arr).unsqueeze(0)


class LucasViewSource:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required': {'source': (['Generate', 'Upload'],),
                             **{a: ('STRING', {'default': ''}) for a in ANGLES[:3]}},
                'optional': {'generated_views': ('LUCAS_APPROVED_VIEWS',),
                             **{a: ('STRING', {'default': ''}) for a in ANGLES[3:]}}}
    RETURN_TYPES = ('LUCAS_APPROVED_VIEWS',)
    RETURN_NAMES = ('selected_views',)
    FUNCTION = 'select'
    CATEGORY = 'Lucas/Character'

    @classmethod
    def VALIDATE_INPUTS(cls, source, front='', left='', back='', right='', top='', bottom=''):
        if source == 'Upload':
            values = [v for v in (front, left, back, right, top, bottom) if v.strip()]
            if not any(v.strip() for v in (front, left, back, right)):
                return 'Upload at least one geometry view: front, left, back or right. Top and bottom are PBR references only.'
            try:
                from PIL import Image
                for v in values:
                    with Image.open(image_path(v)) as im:
                        im.verify()
            except Exception as exc:
                return str(exc)
        return True

    @classmethod
    def IS_CHANGED(cls, source, front='', left='', back='', right='', top='', bottom='', **kwargs):
        if source != 'Upload':
            return source
        digest = hashlib.sha256()
        for value in (front, left, back, right, top, bottom):
            digest.update(value.encode())
            if value.strip():
                digest.update(image_path(value).read_bytes())
        return digest.hexdigest()

    def select(self, source, front='', left='', back='', generated_views=None, right='', top='', bottom=''):
        if source == 'Generate':
            if generated_views is None:
                raise ValueError('Connect the generated views to the source selector.')
            return (generated_views,)
        if source != 'Upload':
            raise ValueError('Invalid image source.')
        if not any(v.strip() for v in (front, left, back, right)):
            raise ValueError('Upload front, left, back or right for geometry; top/bottom alone are not supported.')
        images = {a: load_view(v) for a, v in zip(ANGLES, (front, left, back, right, top, bottom)) if v.strip()}
        if not images:
            raise ValueError('Upload at least one geometry view: front, left, back or right.')
        return ({'images': images, 'skipped': [a for a in ANGLES if a not in images]},)


NODE_CLASS_MAPPINGS = {'LucasViewSource': LucasViewSource}
NODE_DISPLAY_NAME_MAPPINGS = {'LucasViewSource': 'Lucas | Generate or upload views'}

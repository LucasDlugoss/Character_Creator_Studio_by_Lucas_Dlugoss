"""Run in Blender background mode; creates new files, never overwrites input assets.
blender --background --factory-startup --python blender_retopology.py -- --input character.glb --high high.glb --output output_folder
"""
import argparse
import json
import math
import sys
from pathlib import Path


def main(argv=None):
    import bpy
    import bmesh
    p = argparse.ArgumentParser()
    p.add_argument('--input', required=True, help='Textured PBR GLB from the workflow')
    p.add_argument('--high', help='Matching high_detail GLB from the SAME execution')
    p.add_argument('--output', required=True, help='New empty output directory')
    p.add_argument('--faces', type=int, default=30000, help='Approximate quad face target')
    p.add_argument('--texture-size', type=int, default=4096)
    p.add_argument('--ray-distance', type=float, default=0.01, help='Selected-to-active bake ray distance, in imported Blender units')
    args = p.parse_args(argv)
    if args.faces < 100 or args.texture_size < 128 or args.ray_distance <= 0:
        p.error('Use at least 100 faces, 128px textures and positive ray distance.')
    srcpath = Path(args.input).resolve()
    if not srcpath.is_file() or (args.high and not Path(args.high).is_file()):
        p.error('Input/high mesh file does not exist.')
    out = Path(args.output).resolve()
    if out.exists() and any(out.iterdir()):
        p.error('Output directory must be empty; choose a new folder.')
    out.mkdir(parents=True, exist_ok=True)
    if bpy.data.filepath:
        raise RuntimeError('Run with --factory-startup in a separate Blender process, not inside your working scene.')
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)

    def activate(obj, others=()):
        bpy.ops.object.select_all(action='DESELECT')
        for o in [obj, *others]:
            o.hide_set(False)
            o.hide_render = False
            o.select_set(True)
        bpy.context.view_layer.objects.active = obj

    def load(path, name):
        before = set(bpy.data.objects)
        bpy.ops.import_scene.gltf(filepath=str(path))
        meshes = [o for o in bpy.data.objects if o not in before and o.type == 'MESH']
        if not meshes:
            raise RuntimeError('GLB has no mesh objects.')
        activate(meshes[0], meshes[1:])
        bpy.ops.object.join()
        obj = bpy.context.object
        obj.name = name
        bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
        return obj

    source = load(srcpath, 'Source_PBR')
    high = load(Path(args.high).resolve(), 'Source_High') if args.high else source
    low = source.copy()
    low.data = source.data.copy()
    bpy.context.collection.objects.link(low)
    low.name = 'Character_Retopology'
    # Separate disconnected components so small accessories are not discarded.
    activate(low)
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.separate(type='LOOSE')
    bpy.ops.object.mode_set(mode='OBJECT')
    parts = [o for o in bpy.context.selected_objects if o.type == 'MESH']
    total_area = sum(sum(poly.area for poly in obj.data.polygons) for obj in parts)
    targets = []
    for obj in parts:
        activate(obj)
        bm = bmesh.new(); bm.from_mesh(obj.data)
        bad_edges = sum(1 for e in bm.edges if not e.is_manifold and not e.is_boundary)
        bm.free()
        if bad_edges:
            raise RuntimeError(f'{obj.name}: {bad_edges} non-manifold edges. Repair these in Blender before QuadriFlow; original GLBs are untouched.')
        target = max(64, round(args.faces * sum(poly.area for poly in obj.data.polygons) / max(total_area, 1e-12)))
        old = obj.data
        kwargs = dict(use_mesh_symmetry=False, use_preserve_sharp=True,
                      use_preserve_boundary=True, mode='FACES', target_faces=target, seed=0)
        supported = bpy.ops.object.quadriflow_remesh.get_rna_type().properties.keys()
        kwargs = {k: v for k, v in kwargs.items() if k in supported}
        result = bpy.ops.object.quadriflow_remesh(**kwargs)
        if 'FINISHED' not in result or not obj.data.polygons or not any(len(f.vertices) == 4 for f in obj.data.polygons):
            raise RuntimeError(f'QuadriFlow did not produce quads for {obj.name}; inspect the source mesh.')
        targets.append(target)
        # No global voxel remesh, smoothing or shrinkwrap: avoid joining fingers
        # and projecting nearby parts onto the wrong surface.
    activate(parts[0], parts[1:]); bpy.ops.object.join()
    low = bpy.context.object; low.name = 'Character_Retopology'
    activate(low)
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.uv.smart_project(angle_limit=math.radians(66), island_margin=0.02)
    bpy.ops.object.mode_set(mode='OBJECT')
    for f in low.data.polygons:
        f.use_smooth = True
    low.data.materials.clear()
    mat = bpy.data.materials.new('Character_PBR_Rebaked'); mat.use_nodes = True
    low.data.materials.append(mat)
    nt = mat.node_tree
    bsdf = next(n for n in nt.nodes if n.type == 'BSDF_PRINCIPLED')
    scene = bpy.context.scene
    scene.render.engine = 'CYCLES'; scene.cycles.device = 'CPU'; scene.cycles.samples = 16
    scene.render.bake.use_selected_to_active = True
    scene.render.bake.use_clear = True; scene.render.bake.margin = 16
    scene.render.bake.cage_extrusion = args.ray_distance
    scene.render.bake.max_ray_distance = args.ray_distance * 2
    images = {}

    def new_target(name, noncolor):
        img = bpy.data.images.new(name, width=args.texture_size, height=args.texture_size, alpha=False)
        if noncolor:
            img.colorspace_settings.name = 'Non-Color'
        node = nt.nodes.new('ShaderNodeTexImage'); node.image = img
        for n in nt.nodes:
            n.select = False
        node.select = True; nt.nodes.active = node
        images[name] = (img, node)
        return img

    def bake_property(name, socket_name, noncolor=False):
        img = new_target(name, noncolor)
        changes = []
        try:
            # Bake material properties via emission; lighting is never baked in.
            for material in {slot.material for slot in source.material_slots if slot.material}:
                if not material.use_nodes:
                    raise RuntimeError('Source material must use Principled BSDF nodes.')
                tree = material.node_tree
                principled = next((n for n in tree.nodes if n.type == 'BSDF_PRINCIPLED'), None)
                output = next((n for n in tree.nodes if n.type == 'OUTPUT_MATERIAL' and n.is_active_output), None)
                if principled is None or output is None:
                    raise RuntimeError('Unsupported source shader; expected Principled BSDF.')
                links = [(l.from_socket, l.to_socket) for l in list(output.inputs['Surface'].links)]
                emission = tree.nodes.new('ShaderNodeEmission')
                value = principled.inputs[socket_name]
                if value.is_linked:
                    tree.links.new(value.links[0].from_socket, emission.inputs['Color'])
                elif socket_name == 'Base Color':
                    emission.inputs['Color'].default_value = value.default_value
                else:
                    v = value.default_value
                    emission.inputs['Color'].default_value = (v, v, v, 1)
                tree.links.new(emission.outputs[0], output.inputs['Surface'])
                changes.append((tree, emission, links))
            activate(low, (source,))
            bpy.ops.object.bake(type='EMIT')
        finally:
            for tree, emission, links in changes:
                tree.nodes.remove(emission)
                for a, b in links:
                    tree.links.new(a, b)
        img.filepath_raw = str(out / (name + '.png')); img.file_format = 'PNG'; img.save()

    bake_property('base_color', 'Base Color')
    bake_property('metallic', 'Metallic', True)
    bake_property('roughness', 'Roughness', True)
    normal = new_target('normal', True)
    scene.render.bake.normal_space = 'TANGENT'
    activate(low, (high,))
    bpy.ops.object.bake(type='NORMAL')
    normal.filepath_raw = str(out / 'normal.png'); normal.file_format = 'PNG'; normal.save()
    for name, socket in [('base_color', 'Base Color'), ('metallic', 'Metallic'), ('roughness', 'Roughness')]:
        nt.links.new(images[name][1].outputs['Color'], bsdf.inputs[socket])
    nmap = nt.nodes.new('ShaderNodeNormalMap'); nmap.space = 'TANGENT'
    nt.links.new(images['normal'][1].outputs['Color'], nmap.inputs['Color'])
    nt.links.new(nmap.outputs['Normal'], bsdf.inputs['Normal'])
    activate(low)
    for obj in {source, high}:
        obj.hide_render = True; obj.hide_set(True)
    for image, _ in images.values():
        image.pack()
    bpy.ops.wm.save_as_mainfile(filepath=str(out / 'character_quads.blend'))
    bpy.ops.export_scene.gltf(filepath=str(out / 'character_rebaked.glb'), export_format='GLB', use_selection=True, export_texcoords=True, export_normals=True, export_materials='EXPORT')
    report = {'requested_quads': args.faces, 'component_targets': targets, 'actual_faces': len(low.data.polygons),
        'quad_faces': sum(len(f.vertices) == 4 for f in low.data.polygons), 'texture_size': args.texture_size,
        'normal_source': str(Path(args.high).resolve()) if args.high else str(srcpath),
        'warning': 'Automatic remeshing does not create anatomically designed deformation loops. Inspect fingers, shoulders, elbows, hips, knees and face. GLB triangulates; use BLEND to retain quads.'}
    (out / 'retopology_report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main(sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else None)

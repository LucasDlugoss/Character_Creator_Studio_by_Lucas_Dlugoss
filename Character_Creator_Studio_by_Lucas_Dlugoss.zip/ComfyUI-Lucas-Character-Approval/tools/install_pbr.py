"""Install PBR dependencies into the Python running this script. Run with ComfyUI stopped."""
import argparse
import importlib
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile

COMMIT = 'a0b26fbb94c9a9d32720526c52e64f87e05d2b53'
MODULES = ('fast_simplification', 'trimesh', 'xatlas', 'custom_rasterizer',
           'custom_rasterizer_kernel', 'mesh_inpaint_processor')

def run(args, **kwargs):
    print('>', ' '.join(map(str, args)), flush=True)
    subprocess.run(list(map(str, args)), check=True, **kwargs)

def compiler_environment():
    if os.name != 'nt':
        return
    os.environ['DISTUTILS_USE_SDK'] = '1'
    if shutil.which('cl'):
        return
    vswhere = Path(os.environ.get('ProgramFiles(x86)', r'C:\Program Files (x86)')) / 'Microsoft Visual Studio/Installer/vswhere.exe'
    if not vswhere.exists():
        raise RuntimeError('Install Visual Studio Build Tools 2022 with Desktop development with C++, then retry.')
    installation = subprocess.check_output([str(vswhere), '-latest', '-products', '*', '-requires',
        'Microsoft.VisualStudio.Component.VC.Tools.x86.x64', '-property', 'installationPath'], text=True).strip()
    vcvars = Path(installation) / 'VC/Auxiliary/Build/vcvars64.bat'
    if not installation or not vcvars.exists():
        raise RuntimeError('MSVC x64 compiler not found. Install the C++ workload in Visual Studio Build Tools.')
    with tempfile.TemporaryDirectory(prefix='lucas_msvc_') as temp:
        activate = Path(temp) / 'activate.cmd'
        activate.write_text('@echo off\ncall "' + str(vcvars) + '" >nul\nif errorlevel 1 exit /b 1\nset\n')
        envtext = subprocess.check_output(['cmd.exe', '/d', '/c', str(activate)], text=True)
    for line in envtext.splitlines():
        if '=' in line and not line.startswith('='):
            key, value = line.split('=', 1)
            os.environ[key] = value
    os.environ['DISTUTILS_USE_SDK'] = '1'
    if not shutil.which('cl'):
        raise RuntimeError('Could not activate MSVC. Run from x64 Native Tools Command Prompt for VS 2022.')

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--check-only', action='store_true')
    args = ap.parse_args()
    root = Path(__file__).resolve().parents[3]
    if not (root / 'main.py').is_file() or not (root / 'custom_nodes').is_dir():
        raise RuntimeError('Extract this package into ComfyUI/custom_nodes/ComfyUI-Lucas-Character-Approval first.')
    print('Python:', sys.executable, '\nComfyUI:', root, flush=True)
    import torch
    print('Torch:', torch.__version__, 'CUDA:', torch.version.cuda, flush=True)
    destination = root / 'custom_nodes/ComfyUI-Hunyuan3d-2-1'
    if not args.check_only:
        if not torch.cuda.is_available():
            raise RuntimeError('CUDA GPU is not available to this Python. No packages changed.')
        compiler_environment()
        from torch.utils.cpp_extension import CUDA_HOME
        if not CUDA_HOME or not (Path(CUDA_HOME) / 'bin/nvcc.exe' if os.name == 'nt' else Path(CUDA_HOME) / 'bin/nvcc').exists():
            raise RuntimeError('CUDA Toolkit/nvcc missing. Install the Toolkit matching torch.version.cuda; no Torch downgrade is performed.')
        os.environ['CUDA_HOME'] = str(CUDA_HOME)
        os.environ['MAX_JOBS'] = '2'
        major, minor = torch.cuda.get_device_capability()
        os.environ['TORCH_CUDA_ARCH_LIST'] = f'{major}.{minor}'
        with tempfile.TemporaryDirectory(prefix='lucas_pbr_') as temp:
            temp = Path(temp)
            constraints = temp / 'constraints.txt'
            pins = []
            for name in ('torch', 'torchvision', 'torchaudio', 'numpy'):
                try:
                    pins.append(f'{name}=={importlib.metadata.version(name)}')
                except importlib.metadata.PackageNotFoundError:
                    pass
            constraints.write_text('\n'.join(pins))
            if not destination.exists():
                archive = temp / 'source.zip'
                print('Downloading pinned visualbruno wrapper source...', flush=True)
                urllib.request.urlretrieve(f'https://github.com/visualbruno/ComfyUI-Hunyuan3d-2-1/archive/{COMMIT}.zip', archive)
                with zipfile.ZipFile(archive) as z:
                    z.extractall(temp / 'source')
                source = next((temp / 'source').iterdir())
                shutil.copytree(source, destination)
            if not (destination / 'requirements.txt').exists():
                raise RuntimeError('Existing wrapper directory is incomplete; it was preserved. Inspect it before retrying.')
            run([sys.executable, '-m', 'pip', 'install', '-c', constraints, '-r', destination / 'requirements.txt',
                 'fast-simplification', 'ninja', 'setuptools', 'wheel', 'pybind11', 'spandrel'])
            # Build from source for this Python/Torch/CUDA rather than using cp312 wheels.
            raster = destination / 'hy3dpaint/custom_rasterizer'
            setup = raster / 'setup.py'
            original = setup.read_text(encoding='utf-8')
            token = '"cxx": ["-O3", "-std=c++20"]'
            if os.name == 'nt' and token in original:
                backup = setup.with_suffix('.py.lucas-backup')
                if not backup.exists():
                    backup.write_text(original, encoding='utf-8')
                setup.write_text(original.replace(token, '"cxx": ["/O2", "/std:c++20"]'), encoding='utf-8')
            for source in (raster, destination / 'hy3dpaint/DifferentiableRenderer'):
                run([sys.executable, '-m', 'pip', 'install', '--no-build-isolation', '--no-deps', '.'], cwd=source)
    # A new process sees new installations and tests actual DLL imports.
    code = 'import torch; import importlib; [importlib.import_module(x) for x in ' + repr(MODULES) + ']; print("Native dependencies: OK")'
    run([sys.executable, '-c', code])
    if not (destination / '__init__.py').is_file():
        raise RuntimeError('visualbruno wrapper directory missing.')
    print('\nNative imports passed. Restart ComfyUI. v9 checks the registered PBR pipeline before sampling.')
    print('Weights are separate: run tools/download_quality_models.py --help for model download options.')
    print('This check does not test GPU rendering, weights, or a complete PBR generation.')

if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('\nINSTALLATION STOPPED:', exc, file=sys.stderr)
        print('Keep this complete log. Do not regenerate the character until preflight passes.', file=sys.stderr)
        sys.exit(1)

"""Restore UniRig normalization; transfer learned weights to original PBR mesh.
No bone placement templates, bone-heat weighting, or distance-to-bone fallback.
Surface barycentric interpolation transfers predicted weights from inference mesh.
"""
import json
import math
from pathlib import Path
import sys


def barycentric(point, a, b, c):
    v0=b-a;v1=c-a;v2=point-a
    d00=v0.dot(v0);d01=v0.dot(v1);d11=v1.dot(v1);d20=v2.dot(v0);d21=v2.dot(v1)
    denominator=d00*d11-d01*d01
    if abs(denominator)<1e-20: return (1.,0.,0.)
    v=(d11*d20-d01*d21)/denominator;w=(d00*d21-d01*d20)/denominator
    values=[max(0.,1-v-w),max(0.,v),max(0.,w)];total=sum(values)
    return tuple(value/total for value in values)


def main():
    import bpy
    from mathutils import Matrix, Vector
    from mathutils.bvhtree import BVHTree
    source, fbx, metadata, destination=sys.argv[sys.argv.index('--')+1:]
    if bpy.app.version<(4,2,0): raise RuntimeError('Blender 4.2+ required.')
    meta=json.loads(Path(metadata).read_text(encoding='utf-8'))
    target=Path(destination)
    bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
    bpy.ops.import_scene.fbx(filepath=fbx,ignore_leaf_bones=False,use_image_search=False)
    arms=[o for o in bpy.context.scene.objects if o.type=='ARMATURE']
    references=[o for o in bpy.context.scene.objects if o.type=='MESH']
    if len(arms)!=1 or not references: raise RuntimeError('UniRig FBX must contain one armature and a weighted mesh.')
    arm=arms[0];arm.name='Lucas_UniRig'
    bone_names={b.name for b in arm.data.bones if b.use_deform}
    if len(bone_names)<2: raise RuntimeError('UniRig did not export a valid deform skeleton.')
    # Generic articulationxl export retains Blender axes and normalized coordinates.
    restore=Matrix.Translation(Vector(meta['center'])) @ Matrix.Scale(float(meta['scale']),4)
    transforms={o:o.matrix_world.copy() for o in bpy.context.scene.objects}
    def depth(obj):
        value=0
        while obj.parent is not None:value+=1;obj=obj.parent
        return value
    for obj in sorted(transforms,key=depth):
        obj.matrix_world=restore @ transforms[obj]
        bpy.context.view_layer.update()
    bpy.context.view_layer.update()
    points=[];triangles=[];weights=[]
    for obj in references:
        obj.data.calc_loop_triangles();offset=len(points)
        group_names={g.index:g.name for g in obj.vertex_groups if g.name in bone_names}
        for vertex in obj.data.vertices:
            points.append(obj.matrix_world @ vertex.co)
            row={group_names[g.group]:float(g.weight) for g in vertex.groups if g.group in group_names and math.isfinite(g.weight) and g.weight>0}
            if not row: raise RuntimeError('UniRig predicted an unweighted reference vertex; export stopped.')
            total=sum(row.values());weights.append({name:value/total for name,value in row.items()})
        triangles.extend(tuple(offset+i for i in tri.vertices) for tri in obj.data.loop_triangles)
    if not triangles: raise RuntimeError('UniRig reference has no triangles.')
    tree=BVHTree.FromPolygons(points,triangles,all_triangles=True)
    existing=set(bpy.context.scene.objects)
    bpy.ops.import_scene.gltf(filepath=source,import_pack_images=True)
    originals=[o for o in bpy.context.scene.objects if o not in existing and o.type=='MESH']
    if not originals: raise RuntimeError('Original textured mesh unavailable.')
    vertices=[o.matrix_world @ v.co for o in originals for v in o.data.vertices]
    lo=Vector(tuple(min(v[i] for v in vertices) for i in range(3)))
    hi=Vector(tuple(max(v[i] for v in vertices) for i in range(3)))
    diagonal=(hi-lo).length
    if diagonal<=1e-8: raise RuntimeError('Degenerate original mesh.')
    distances=[]
    for obj in originals:
        # Existing weights or rigs are not silently overwritten.
        if any(mod.type=='ARMATURE' for mod in obj.modifiers): raise RuntimeError('Original already has a rig.')
        groups={name:obj.vertex_groups.new(name=name) for name in sorted(bone_names)}
        for vertex in obj.data.vertices:
            point=obj.matrix_world @ vertex.co
            nearest,normal,index,distance=tree.find_nearest(point)
            if index is None: raise RuntimeError('Surface transfer failed.')
            distances.append(float(distance)/diagonal)
            ids=triangles[index];coefficients=barycentric(nearest,*(points[i] for i in ids))
            merged={}
            for vi,coefficient in zip(ids,coefficients):
                for name,value in weights[vi].items(): merged[name]=merged.get(name,0.)+coefficient*value
            top=sorted(merged.items(),key=lambda item:item[1],reverse=True)[:4]
            total=sum(weight for _,weight in top)
            if total<1e-12 or not math.isfinite(total): raise RuntimeError('Invalid transferred skin weights.')
            for name,weight in top: groups[name].add([vertex.index],weight/total,'REPLACE')
        transform=obj.matrix_world.copy();obj.parent=arm
        obj.matrix_parent_inverse=arm.matrix_world.inverted();obj.matrix_world=transform
        modifier=obj.modifiers.new('UniRig Skin','ARMATURE');modifier.object=arm
    distances.sort();p95=distances[min(len(distances)-1,int(len(distances)*.95))]
    if p95>.015 or distances[-1]>.05:
        raise RuntimeError(f'Rig alignment check failed: p95={p95:.4f}, max={distances[-1]:.4f} of mesh diagonal. Original GLB preserved. Check normalization and orientation.')
    for obj in references: bpy.data.objects.remove(obj,do_unlink=True)
    bpy.ops.object.select_all(action='DESELECT')
    arm.select_set(True);arm.show_in_front=True;bpy.context.view_layer.objects.active=arm
    for obj in originals:obj.select_set(True)
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from blender_materials import connect_pbr
    material_report = connect_pbr(originals, source)
    bpy.ops.file.pack_all()
    bpy.ops.wm.save_as_mainfile(filepath=str(target.with_suffix('.blend')))
    bpy.ops.export_scene.gltf(filepath=str(target),export_format='GLB',use_selection=True,
                              export_skins=True,export_animations=False,export_materials='EXPORT')
    report=dict(meta)
    report.update(blender=bpy.app.version_string,materials=material_report,original_mesh_preserved=True,
                  transfer='Nearest triangle surface, barycentric interpolation of UniRig predicted weights; top 4 normalized',
                  distance_p95_fraction=p95,distance_max_fraction=distances[-1],weighted_vertices=len(distances),
                  deform_bones=len(bone_names),source_fbx=fbx,
                  limits='Inspect joint placement and deformation in Blender. No retopology, IK controls or facial expressions. Not guaranteed production-ready.')
    target.with_suffix('.rig.json').write_text(json.dumps(report,indent=2),encoding='utf-8')


if __name__=='__main__':main()

"""Download NEW quality-stage weights only. Run in the ComfyUI Python environment."""
import argparse
import shutil
from pathlib import Path

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--comfy-root',required=True,type=Path)
    args=p.parse_args()
    root=args.comfy_root.resolve()
    if not (root/'main.py').is_file():
        p.error('--comfy-root must point to the active ComfyUI folder containing main.py.')
    from huggingface_hub import hf_hub_download,snapshot_download
    filename='qwen_image_2512_fp8_e4m3fn.safetensors'
    dst=root/'models'/'diffusion_models'/filename
    dst.parent.mkdir(parents=True,exist_ok=True)
    if dst.exists():
        print('Existing concept model retained:',dst)
    else:
        source=hf_hub_download('Comfy-Org/Qwen-Image_ComfyUI',filename='split_files/diffusion_models/'+filename)
        temp=dst.with_suffix('.partial')
        shutil.copyfile(source,temp);temp.replace(dst)
    # Keep standard HF cache: these are the exact repositories requested by Paint 2.1.
    snapshot_download('tencent/Hunyuan3D-2.1',allow_patterns=['hunyuan3d-paintpbr-v2-1/*'])
    snapshot_download('facebook/dinov2-giant',allow_patterns=['*.json','*.safetensors','pytorch_model.bin'])
    print('New weights downloaded. Existing Edit2511, angle LoRA, encoder, VAE, shape and RMBG weights are still required.')
    print('Test one complete run before setting HF_HUB_OFFLINE=1 and TRANSFORMERS_OFFLINE=1.')

if __name__=='__main__':main()

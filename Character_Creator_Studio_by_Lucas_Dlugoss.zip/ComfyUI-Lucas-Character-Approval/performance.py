"""Hardware selection is conservative policy, not a tested compatibility guarantee."""
import json

GIB = 1024 ** 3
MODES = ['Automatic', 'Speed', 'Quality', 'Manual']
FIELDS = ('concept_size', 'view_size', 'concept_steps', 'view_steps', 'shape_steps', 'octree', 'chunks', 'pbr_view_size', 'texture_size', 'pbr_steps')
DEFAULTS = (1328, 1024, 50, 40, 50, 512, 8000, 768, 4096, 30)
PRESETS = {
    'economy': (1024, 768, 40, 30, 40, 384, 4000, 512, 2048, 20),
    'balanced': (1328, 1024, 50, 40, 50, 512, 6000, 768, 4096, 30),
    'quality': (1328, 1328, 50, 40, 50, 512, 8000, 1024, 4096, 30),
    'speed': (768, 768, 30, 25, 30, 256, 3000, 512, 2048, 15),
}


def hardware():
    import torch
    import psutil
    import comfy.model_management as mm
    device = mm.get_torch_device()
    ram = psutil.virtual_memory()
    info = {'device': str(device), 'gpu': 'No CUDA', 'vram_total_gb': 0, 'vram_free_gb': 0,
            'vram_budget_gb': 0, 'ram_total_gb': ram.total / GIB, 'ram_available_gb': ram.available / GIB}
    if device.type == 'cuda' and torch.cuda.is_available():
        free, total = torch.cuda.mem_get_info(device)
        prop = torch.cuda.get_device_properties(device)
        # Includes this process's CUDA allocator memory, potentially reclaimable
        # between stages. Not a promise that all allocations can be released.
        reserved = torch.cuda.memory_reserved(device)
        info.update(gpu=prop.name, vram_total_gb=total / GIB, vram_free_gb=free / GIB,
                    vram_budget_gb=min(total, free + reserved) / GIB,
                    cuda_capability=f'{prop.major}.{prop.minor}')
    return info


def select_profile(mode, hw, manual=None):
    if mode not in MODES:
        raise ValueError('Invalid performance mode.')
    warnings = ['Estimated profiles; full generation on this GPU still requires validation.']
    if hw['vram_total_gb'] <= 0:
        raise ValueError('This PBR workflow requires an active NVIDIA CUDA GPU in ComfyUI.')
    total, budget = hw['vram_total_gb'], hw['vram_budget_gb']
    if mode != 'Manual' and (total < 15 or hw['ram_total_gb'] < 30):
        raise ValueError('Automatic profiles require approximately 16 GB VRAM and 32 GB RAM. Close other applications or experiment in Manual mode; compatibility is not guaranteed.')
    if total >= 30 and budget >= 28 and hw['ram_total_gb'] >= 60:
        tier = 'quality'
    elif total >= 22 and budget >= 20 and hw['ram_total_gb'] >= 60:
        tier = 'balanced'
    else:
        tier = 'economy'
    if budget < 12:
        warnings.append('Transient GPU memory pressure; conservative profile selected. Cached models will be released before retrying.')
        tier = 'economy'
    if hw['ram_available_gb'] < 12:
        warnings.append('Low available RAM for offload; close other applications. Conservative profile selected.')
        tier = 'economy'
    if mode == 'Manual':
        cfg = dict(zip(FIELDS, DEFAULTS));cfg.update(manual or {})
        tier = 'manual'
    else:
        if mode == 'Automatic' and tier == 'quality': tier = 'balanced'
        if mode == 'Quality' and tier == 'balanced': tier = 'quality'
        if mode == 'Speed': tier = 'speed'
        cfg = dict(zip(FIELDS, PRESETS[tier]))
        if mode == 'Quality' and tier == 'economy':
            warnings.append('Quality limited by memory budget; 4K PBR was not enabled.')
    for name in ('concept_size', 'view_size'):
        if not 512 <= int(cfg[name]) <= 1536 or int(cfg[name]) % 16:
            raise ValueError(f'{name}: use a multiple of 16 between 512 and 1536.')
    if cfg['pbr_view_size'] not in (512, 768, 1024) or cfg['texture_size'] not in (2048, 4096):
        raise ValueError('Invalid PBR resolution.')
    for name in ('concept_steps', 'view_steps', 'shape_steps', 'pbr_steps'):
        if not 1 <= int(cfg[name]) <= 100: raise ValueError('Steps must be between 1 and 100.')
    if not 128 <= int(cfg['octree']) <= 512 or not 1000 <= int(cfg['chunks']) <= 16000:
        raise ValueError('Octree or chunks outside valid limits.')
    cfg['mesh_target_faces'] = {'speed': 100000, 'economy': 150000, 'balanced': 300000, 'quality': 500000, 'manual': 300000}[tier]
    return {'mode': mode, 'tier': tier, 'hardware': hw, 'settings': cfg, 'warnings': warnings,
            'views': ['front', 'left', 'back'], 'offload': 'PBR model CPU offload; VAE slicing/tiling; unload managed models before PBR'}


class LucasHardwareProfile:
    @classmethod
    def INPUT_TYPES(cls):
        req = {'mode': (MODES, {'default': 'Automatic'})}
        for name, default in zip(FIELDS, DEFAULTS):
            if name in ('concept_size', 'view_size'): opt={'default':default,'min':512,'max':1536,'step':16}
            elif name == 'pbr_view_size': opt={'default':default,'min':512,'max':1024,'step':256}
            elif name == 'texture_size': opt={'default':default,'min':2048,'max':4096,'step':2048}
            elif name == 'octree': opt={'default':default,'min':128,'max':512,'step':128}
            elif name == 'chunks': opt={'default':default,'min':1000,'max':16000,'step':1000}
            else: opt={'default':default,'min':1,'max':100}
            req['manual_' + name] = ('INT', opt)
        return {'required': req}
    RETURN_TYPES = ('INT',) * 7 + ('STRING',)
    RETURN_NAMES = FIELDS[:7] + ('performance_config',)
    FUNCTION = 'resolve'
    CATEGORY = 'Lucas/Character'
    @classmethod
    def IS_CHANGED(cls, **kwargs): return float('nan')
    def resolve(self, mode, **kwargs):
        hw = hardware()
        if hw['vram_total_gb'] >= 15 and hw['vram_budget_gb'] < 12:
            import comfy.model_management as mm
            mm.unload_all_models()
            mm.soft_empty_cache()
            hw = hardware()
        config = select_profile(mode, hw, {k.removeprefix('manual_'): v for k,v in kwargs.items()})
        text = json.dumps(config, ensure_ascii=False, indent=2)
        print('[Lucas hardware profile]\n' + text)
        return {'ui': {'text': [text]}, 'result': tuple(config['settings'][k] for k in FIELDS[:7]) + (text,)}


NODE_CLASS_MAPPINGS = {'LucasHardwareProfile': LucasHardwareProfile}
NODE_DISPLAY_NAME_MAPPINGS = {'LucasHardwareProfile': 'Lucas | GPU / automatic performance'}

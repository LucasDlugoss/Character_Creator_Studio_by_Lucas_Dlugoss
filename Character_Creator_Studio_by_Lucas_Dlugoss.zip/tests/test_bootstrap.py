import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('bootstrap', ROOT / 'bootstrap.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)

spec_u = importlib.util.spec_from_file_location('install_unirig', ROOT / 'install_unirig.py')
u = importlib.util.module_from_spec(spec_u)
spec_u.loader.exec_module(u)


class Response(io.BytesIO):
    def __init__(self, data, status=200, headers=None):
        super().__init__(data)
        self.status = status
        self.headers = headers or {'Content-Length': str(len(data))}


class BootstrapTests(unittest.TestCase):
    def test_verified_download_and_reuse(self):
        data = b'validated payload'
        sha = hashlib.sha256(data).hexdigest()
        with tempfile.TemporaryDirectory() as folder:
            p = Path(folder) / 'file.zip'
            with patch.object(b.urllib.request, 'urlopen', return_value=Response(data)) as network:
                b.download('https://example.test/file', p, sha, len(data))
                self.assertEqual(p.read_bytes(), data)
                b.download('https://example.test/file', p, sha, len(data))
                self.assertEqual(network.call_count, 1)

    def test_resume(self):
        data = b'partial and remainder'
        sha = hashlib.sha256(data).hexdigest()
        with tempfile.TemporaryDirectory() as folder:
            p = Path(folder) / 'model'
            p.with_name('model.part').write_bytes(data[:7])
            with patch.object(b.urllib.request, 'urlopen', return_value=Response(data[7:], 206, {'Content-Range': f'bytes 7-{len(data)-1}/{len(data)}'})):
                b.download('https://example.test/model', p, sha, len(data))
                self.assertEqual(p.read_bytes(), data)

    def test_server_ignores_range_restarts(self):
        data = b'complete'
        sha = hashlib.sha256(data).hexdigest()
        with tempfile.TemporaryDirectory() as folder:
            p = Path(folder) / 'model'
            p.with_name('model.part').write_bytes(b'wrong')
            with patch.object(b.urllib.request, 'urlopen', return_value=Response(data)):
                b.download('https://example.test/model', p, sha, len(data))
                self.assertEqual(p.read_bytes(), data)

    def test_bad_checksum_never_promoted(self):
        with tempfile.TemporaryDirectory() as folder:
            p = Path(folder) / 'program.exe'
            with patch.object(b.urllib.request, 'urlopen', side_effect=lambda *a, **k: Response(b'bad')):
                with self.assertRaises(RuntimeError):
                    b.download('https://example.test/file', p, 'a' * 64)
            self.assertFalse(p.exists())

    def test_archive_traversal_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            p = Path(folder) / 'archive.zip'
            with zipfile.ZipFile(p, 'w') as z:
                z.writestr('../outside', 'bad')
            with self.assertRaises(ValueError):
                b.unpack(p, Path(folder) / 'output')
            self.assertFalse((Path(folder) / 'outside').exists())

    def test_safe_extraction(self):
        with tempfile.TemporaryDirectory() as folder:
            p = Path(folder) / 'archive.zip'
            with zipfile.ZipFile(p, 'w') as z:
                z.writestr('cmd/git.exe', 'fixture')
            b.unpack(p, Path(folder) / 'output')
            self.assertTrue((Path(folder) / 'output/cmd/git.exe').is_file())

    def test_model_downloads_pinned_and_verified(self):
        with tempfile.TemporaryDirectory() as folder, patch.object(b, 'download') as download:
            result = b.download_models(Path(folder))
            self.assertEqual(download.call_count, 2)
            self.assertEqual(set(result['files']), {'skeleton.safetensors', 'skin.safetensors'})
            for call in download.call_args_list:
                self.assertIn(result['revision'], call.args[0])
                self.assertEqual(len(call.args[2]), 64)
                self.assertGreater(call.args[3], 1000000000)

    def test_launcher_aliases(self):
        for name in ['INSTALAR.cmd', 'INSTALL.cmd', 'INSTALL_UNIRIG.cmd']:
            text = (ROOT / name).read_text()
            self.assertIn('bootstrap.py', text)
            self.assertNotIn('--backend-only', text)

    def test_existing_git_not_downloaded(self):
        with tempfile.TemporaryDirectory() as folder:
            with patch.object(b.shutil, 'which', return_value='/existing/git.exe'), patch.object(b, 'program_version', return_value=True), patch.object(b, 'user_path_add'), patch.object(b, 'download') as download, patch.dict(b.os.environ, {'PATH': 'original'}):
                git = b.ensure_git(Path(folder), Path(folder))
                self.assertEqual(str(git), '/existing/git.exe')
                download.assert_not_called()

    def test_managed_blender_reused(self):
        with tempfile.TemporaryDirectory() as folder:
            exe = Path(folder) / 'lucas_tools/blender/blender-test/blender.exe'
            exe.parent.mkdir(parents=True)
            exe.touch()
            with patch.dict(b.os.environ, {}, clear=True), patch.object(b.shutil, 'which', return_value=None), patch.object(b, 'program_version', return_value=True), patch.object(b, 'download') as download:
                self.assertEqual(b.ensure_blender(Path(folder), Path(folder)), exe)
                download.assert_not_called()

    def test_heal_root_toml(self):
        with tempfile.TemporaryDirectory() as folder:
            t = Path(folder)
            (t / 'comfy-env-root.toml').write_text('[dependencies]\nfoo = "1"\n[node_reqs]\nbar = "repo"\n', encoding='utf-8')
            u.restore_or_heal_root_toml(t, mode='modern')
            healed = (t / 'comfy-env-root.toml').read_text(encoding='utf-8')
            self.assertNotIn('[dependencies]', healed)
            self.assertIn('[node_packs]', healed)
            u.restore_or_heal_root_toml(t, mode='0.4.1')
            restored = (t / 'comfy-env-root.toml').read_text(encoding='utf-8')
            self.assertIn('[dependencies]', restored)
            self.assertIn('[node_reqs]', restored)


if __name__ == '__main__':
    unittest.main()

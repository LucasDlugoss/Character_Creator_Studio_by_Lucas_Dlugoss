import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
import numpy as np
import trimesh

PACK=Path(__file__).resolve().parents[1]/'ComfyUI-Lucas-Character-Approval'
def load(name):
 s=importlib.util.spec_from_file_location(name,PACK/(name+'.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
q=load('quality');p=load('performance')

class QualityTests(unittest.TestCase):
 def test_quality_on_24gb_and_pressure(self):
  hw=dict(vram_total_gb=24,vram_budget_gb=23,ram_total_gb=64,ram_available_gb=40)
  a=p.select_profile('Automatic',hw);b=p.select_profile('Quality',hw)
  self.assertEqual(a['settings']['pbr_view_size'],768)
  self.assertEqual(b['settings']['pbr_view_size'],1024)
  self.assertEqual(b['settings']['mesh_target_faces'],500000)
  self.assertEqual(p.select_profile('Quality',dict(hw,vram_budget_gb=10))['tier'],'economy')
 def test_budget_override_and_original(self):
  mesh=trimesh.creation.icosphere(subdivisions=3)
  original=mesh.vertices.copy()
  _,low,report=q.LucasMeshQuality().process(mesh,0,json.dumps({'settings':{'mesh_target_faces':500}}))
  self.assertLess(len(low.faces),len(mesh.faces));self.assertEqual(json.loads(report)['requested_target_faces'],500)
  _,low2,_=q.LucasMeshQuality().process(mesh,800,json.dumps({'settings':{'mesh_target_faces':500}}))
  self.assertGreater(len(low2.faces),len(low.faces));self.assertLess(len(low2.faces),len(mesh.faces))
  np.testing.assert_array_equal(mesh.vertices,original)
 def test_small_accessory_survives(self):
  main=trimesh.creation.icosphere(subdivisions=3)
  small=trimesh.creation.icosphere(subdivisions=0,radius=.005);small.apply_translation([2,0,0])
  mesh=trimesh.util.concatenate([main,small]);high,low,report=q.clean_mesh(mesh,200)
  self.assertEqual(len(low.split(only_watertight=False)),2)
  self.assertEqual(len(min(low.split(),key=lambda m:m.area).faces),20)
  self.assertEqual(len(high.faces),len(mesh.faces))
 def test_uv_geometry_normals_and_glb(self):
  mesh=trimesh.creation.icosphere(subdivisions=2)
  uv,report=q.unwrap_quality(mesh,2048)
  self.assertEqual(len(uv.faces),len(mesh.faces))
  np.testing.assert_allclose(uv.bounds,mesh.bounds,atol=1e-6)
  self.assertEqual(report['atlas_count'],1)
  self.assertGreater(report['padding_at_output_px'],0)
  self.assertEqual(report['degenerate_uv_triangles'],0)
  np.testing.assert_allclose(np.linalg.norm(uv.vertex_normals,axis=1),1,atol=1e-5)
  # Duplicated vertices at a UV seam must carry the same original normal.
  groups={}
  for v,n in zip(uv.vertices,uv.vertex_normals):
   key=tuple(v)
   if key in groups:np.testing.assert_allclose(n,groups[key],atol=1e-6)
   groups[key]=n
  import struct
  data=uv.export(file_type='glb',include_normals=True)
  n=struct.unpack_from('<I',data,12)[0];doc=json.loads(data[20:20+n])
  self.assertIn('NORMAL',doc['meshes'][0]['primitives'][0]['attributes'])
 def test_pbr_channels(self):
  _,packed,m,r=q.pbr_images(np.ones((2,2,3))*.5,np.broadcast_to([.2,.7,0],(2,2,3)))
  self.assertEqual(np.array(packed)[0,0].tolist(),[255,178,51])

if __name__=='__main__':unittest.main()

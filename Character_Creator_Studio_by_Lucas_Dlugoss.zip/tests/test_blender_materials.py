"""Run with Blender's Python/bpy. Tests actual shader graphs and GLB round-trip."""
import sys
import tempfile
from pathlib import Path
import bpy
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'ComfyUI-Lucas-Character-Approval/tools'))
from blender_materials import connect_pbr


def run():
    with tempfile.TemporaryDirectory() as directory:
        root=Path(directory); source=root/'character.glb'
        bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
        bpy.ops.mesh.primitive_cube_add();obj=bpy.context.object
        def png(name,color):
            image=bpy.data.images.new(name,width=4,height=4)
            image.pixels=list(color)*16
            image.filepath_raw=str(root/('character_'+name+'.png'));image.file_format='PNG';image.save()
        png('base_color',(0.6,0.2,0.1,1))
        png('metallic',(0.3,0.3,0.3,1))
        png('roughness',(0.7,0.7,0.7,1))
        png('metallic_roughness',(1,0.7,0.3,1))
        report=connect_pbr([obj],source)
        mat=obj.active_material;nodes=mat.node_tree.nodes
        shader=next(n for n in nodes if n.type=='BSDF_PRINCIPLED')
        for socket,name in [('Base Color','base_color'),('Metallic','metallic'),('Roughness','roughness')]:
            assert shader.inputs[socket].links[0].from_node.name==name
            assert nodes[name].image.packed_file
            assert nodes[name].image.colorspace_settings.name==('sRGB' if name=='base_color' else 'Non-Color')
        assert not shader.inputs['Normal'].is_linked
        bpy.ops.wm.save_as_mainfile(filepath=str(root/'test.blend'))
        bpy.ops.wm.open_mainfile(filepath=str(root/'test.blend'))
        obj=bpy.context.object
        assert all(n.image.packed_file for n in obj.active_material.node_tree.nodes if n.type=='TEX_IMAGE')
        # GLB exported for rigged output must preserve image-based PBR sockets.
        bpy.ops.export_scene.gltf(filepath=str(root/'test.glb'),export_format='GLB')
        bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
        bpy.ops.import_scene.gltf(filepath=str(root/'test.glb'))
        obj=next(o for o in bpy.context.scene.objects if o.type=='MESH')
        shader=next(n for n in obj.active_material.node_tree.nodes if n.type=='BSDF_PRINCIPLED')
        assert all(shader.inputs[s].is_linked for s in ('Base Color','Metallic','Roughness'))
        # Combined-map fallback must use glTF G/B, never red for metallic.
        (root/'character_metallic.png').unlink();(root/'character_roughness.png').unlink()
        connect_pbr([obj],source)
        shader=next(n for n in obj.active_material.node_tree.nodes if n.type=='BSDF_PRINCIPLED')
        assert shader.inputs['Metallic'].links[0].from_socket.name=='Blue'
        assert shader.inputs['Roughness'].links[0].from_socket.name=='Green'
        # Foreign/old GLB with no sidecars keeps original material.
        original=obj.active_material
        connect_pbr([obj],root/'external.glb')
        assert obj.active_material==original
    print('PASS: PBR links, color spaces, packed BLEND reload, GLB roundtrip, packed-channel fallback, embedded material preservation.',flush=True)

if __name__=='__main__':run()

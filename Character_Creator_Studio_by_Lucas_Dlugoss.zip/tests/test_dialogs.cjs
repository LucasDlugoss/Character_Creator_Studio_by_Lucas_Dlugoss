const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const root=path.resolve(__dirname,'../ComfyUI-Lucas-Character-Approval/web');
class Element{
 constructor(tag){this.tag=tag;this.children=[];this.style={};this.attributes={};this.textContent='';this.value='';this.hidden=false;}
 append(...xs){for(const x of xs){this.children.push(x);if(x&&typeof x==='object')x.parent=this;}}
 setAttribute(k,v){this.attributes[k]=v;}
 removeAttribute(k){delete this.attributes[k];if(k==='value')this.value=undefined;}
 focus(){}
 remove(){if(this.parent)this.parent.children=this.parent.children.filter(x=>x!==this);}
 get options(){return this.children;}
}
const document={body:new Element('body'),createElement:tag=>new Element(tag),addEventListener(){},removeEventListener(){}};
class FormDataMock { constructor(){this.entries=[];} append(k,v){this.entries.push([k,v]);} }
let uploadFails=false;
const store=new Map(),events={},requests=[],extensions=[];
const promptNode={id:10,comfyClass:'LucasCharacterPrompt',mode:0,widgets:[{name:'description',value:'Elefante realista — não adicionar braços'},{name:'anatomy_mode',value:'Quadruped animal'}],properties:{}};
const perfNode={id:744,comfyClass:'LucasHardwareProfile',mode:0,widgets:[{name:'mode',value:'Automatic'}]};
const nodes=[promptNode,perfNode,{id:300,comfyClass:'LucasReviewThreeViews'},{id:200,comfyClass:'LucasCharacterApproval'}];
const app={graph:{_nodes:nodes,getNodeById:id=>nodes.find(n=>n.id===id),setDirtyCanvas(){}},registerExtension:x=>extensions.push(x)};
const api={apiURL:x=>x,addEventListener:(k,f)=>{const old=events[k];events[k]=e=>{old?.(e);f(e);};},dispatchEvent:e=>events[e.type]?.(e),async fetchApi(url,opts){
 requests.push({url,data:opts?.body instanceof FormDataMock?opts.body:opts?.body?JSON.parse(opts.body):null});
 if(url==='/upload/image')return uploadFails?{ok:false,status:500}:{ok:true,json:async()=>({name:'deer.png',subfolder:'Lucas_Character/uploads',type:'input'})};
 if(url.includes('/performance'))return {ok:true,json:async()=>({hardware:{gpu:'GPU',vram_total_gb:24,vram_free_gb:23,ram_total_gb:64},mode:JSON.parse(opts.body).mode,tier:'balanced',settings:{concept_size:1328,view_size:1024,concept_steps:50,view_steps:40,shape_steps:50,octree:512,pbr_view_size:768,texture_size:4096,pbr_steps:30},warnings:['Estimated profiles; full generation on this GPU still requires validation.']})};
 return {ok:true,json:async()=>({ok:true})};
}};
const context=vm.createContext({document,localStorage:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v)},console,setInterval:()=>1,setTimeout:()=>1,CustomEvent:class{constructor(type,args){this.type=type;this.detail=args.detail;}},FormData:FormDataMock,URLSearchParams,alert(){},crypto:require('crypto').webcrypto,app,api});
const cache=new Map();
function mod(file){
 if(cache.has(file))return cache.get(file);
 let source;
 if(file==='app')source='export const app=globalThis.app;';
 else if(file==='api')source='export const api=globalThis.api;';
 else source=fs.readFileSync(path.join(root,file),'utf8');
 const m=new vm.SourceTextModule(source,{context,identifier:file});cache.set(file,m);return m;
}
async function load(file){const m=mod(file);if(m.status==='unlinked')await m.link((name,parent)=>mod(name.endsWith('/scripts/app.js')?'app':name.endsWith('/scripts/api.js')?'api':path.basename(name)));if(m.status!=='evaluated')await m.evaluate();return m.namespace;}
function descendants(e){return [e,...e.children.flatMap(x=>typeof x==='object'?descendants(x):[])];}
function visible(e){for(let n=e;n;n=n.parent)if(n.hidden)return false;return true;}
function find(tag,text){return descendants(document.body).find(e=>e.tag===tag&&e.textContent===text&&visible(e));}
let completed=false;process.on('beforeExit',()=>{if(!completed){console.error('FAIL: test promise did not finish');process.exitCode=1;}});
(async()=>{
 const i=await load('i18n.js');assert.equal(i.getLanguage(),'en');
 const enKeys=Object.keys(i.catalogs.en).sort();
 for(const [lang,cat] of Object.entries(i.catalogs)){
  assert.deepEqual(Object.keys(cat).sort(),enKeys);
  for(const key of enKeys){
   assert(cat[key].length>0);
   const vars=s=>[...s.matchAll(/\{(\w+)\}/g)].map(m=>m[1]).sort();
   assert.deepEqual(vars(cat[key]),vars(i.catalogs.en[key]),lang+':'+key);
  }
 }
 const rnode={id:747,comfyClass:'LucasAutomaticRig',widgets:[{name:'rig_preset',value:'None'},{name:'seed',value:42}]};nodes.push(rnode);
 const rigModule=await load('rig.js');const rigBox=rigModule.rigPanel();
 const checkbox=descendants(rigBox).find(e=>e.tag==='input');assert.equal(checkbox.checked,false);
 checkbox.checked=true;checkbox.onchange();assert.equal(rnode.widgets[0].value,'UniRig');
 const rigSeed=descendants(rigBox).find(e=>e.tag==='input'&&e.type==='number');rigSeed.value='123';rigSeed.onchange();assert.equal(rnode.widgets[1].value,123);
 checkbox.checked=false;checkbox.onchange();assert.equal(rnode.widgets[0].value,'None');
 const existingNode={widgets:[{name:'glb_path',value:'old.glb'}]};
 const existingRequest=rigModule.requestExistingRig(existingNode);
 const fileInput=descendants(document.body).find(e=>e.tag==='input'&&e.type==='text');
 fileInput.value='Lucas_Character/3D/existing.glb';find('button',i.t('submit')).onclick();
 assert.equal(await existingRequest,true);assert.equal(existingNode.widgets[0].value,'Lucas_Character/3D/existing.glb');
 const p=await load('prompt.js');
 const pending=p.requestCharacterPrompt(promptNode);
 await new Promise(r=>setImmediate(r));
 const selector=descendants(document.body).find(e=>e.attributes['aria-label']==='Language');
 assert(selector);const original=promptNode.widgets[0].value;
 for(const [code] of i.languages){
  selector.value=code;selector.onchange();
  assert.equal(i.getLanguage(),code);assert(find('h2',i.t('title')));
  assert.equal(descendants(document.body).find(e=>e.tag==='textarea').value,original);
  assert.equal(perfNode.widgets[0].value,'Automatic');
  assert.equal(promptNode.widgets[1].value,'Quadruped animal');
  assert(find('button',i.t('submit')));
 }
 i.setLanguage('pt-BR');selector.value='pt-BR';selector.onchange();
 const presetSelect=descendants(document.body).find(e=>e.tag==='select'&&e.options.some(o=>o.value==='Bird spread wings'));
 assert(presetSelect);assert.equal(presetSelect.options.length,10);
 for(const option of presetSelect.options){
  presetSelect.value=option.value;presetSelect.onchange();
  assert.equal(promptNode.widgets[1].value,option.value);
  assert(find('p',i.t('pose_'+option.value)));
  assert.equal(promptNode.widgets[0].value,original);
 }
 presetSelect.value='Quadruped animal';presetSelect.onchange();
 find('button',i.t('submit')).onclick();assert.equal(await pending,original);assert.equal(promptNode.widgets[0].value,original);
 assert.equal(store.get('lucas.character.dialogLanguage.v1'),'pt-BR');
 await load('views.js');await load('approval.js');
 for(const [code] of i.languages){
  i.setLanguage(code);
  events['lucas-view-review']({detail:{node_id:300,token:'test',images:[],requested:'left',approved:['front'],remaining:['left','back'],pending:['left','back'],skipped:[],seed:'42',attempt:1}});
  assert(find('h2',i.t('review',{view:i.t('left')})));
  await find('button',i.t('useLeft')).onclick();assert.equal(requests.at(-1).data.action,'left');
  events['lucas-character-review']({detail:{node_id:200,token:'concept',images:[],front_sampler_id:16}});
  assert(find('h2',i.t('frontTitle')));
  await find('button',i.t('approve')).onclick();assert.equal(requests.at(-1).data.action,'approve');
 }
 i.setLanguage('unsupported');assert.equal(i.getLanguage(),'en');
 const src=await load('sources.js');
 const sourceNode={id:746,comfyClass:'LucasViewSource',mode:0,widgets:[{name:'source',value:'Generate'},...['front','left','back','right','top','bottom'].map(name=>({name,value:''}))]};
 const sourceValue=name=>sourceNode.widgets.find(w=>w.name===name);
 let choice=src.requestViewSource(sourceNode);
 let langSelect=descendants(document.body).find(e=>e.attributes['aria-label']==='Language');
 for(const [code] of i.languages){
  langSelect.value=code;langSelect.onchange();assert(find('h2',i.t('sourceTitle')));assert(find('button',i.t('sourceUpload')));
 }
 find('button',i.t('sourceUpload')).onclick();
 find('button',i.t('uploadStart')).onclick();assert(find('p',i.t('uploadRequired')));
 let inputs=descendants(document.body).filter(e=>e.tag==='input'&&e.type==='file');
 assert.equal(inputs.length,6);
 // A LEFT-only upload is sufficient, no fake front/back references are inserted.
 inputs[1].files=[{name:'deer.png'}];await inputs[1].onchange();
 assert.equal(requests.at(-1).url,'/upload/image');
 assert(requests.at(-1).data.entries.some(([k,v])=>k==='overwrite'&&v==='false'));
 find('button',i.t('uploadStart')).onclick();assert.equal(await choice,'Upload');
 assert.equal(sourceValue('front').value,'');assert.equal(sourceValue('back').value,'');
 assert.equal(sourceValue('left').value,'Lucas_Character/uploads/deer.png');
 choice=src.requestViewSource(sourceNode);
 inputs=descendants(document.body).filter(e=>e.tag==='input'&&e.type==='file');
 uploadFails=true;inputs[0].files=[{name:'invalid.png'}];await inputs[0].onchange();uploadFails=false;
 assert(find('p',i.t('uploadFailed')));
 find('button',i.t('cancel')).onclick();assert.equal(await choice,null);assert.equal(sourceValue('front').value,'');
 // Polar-only uploads are blocked; adding RIGHT makes them valid.
 sourceValue('left').value='';sourceValue('top').value='top.png';sourceValue('bottom').value='bottom.png';
 choice=src.requestViewSource(sourceNode);
 find('button',i.t('uploadStart')).onclick();assert(find('p',i.t('uploadRequired')));
 inputs=descendants(document.body).filter(e=>e.tag==='input'&&e.type==='file');
 inputs[3].files=[{name:'right.png'}];await inputs[3].onchange();
 find('button',i.t('uploadStart')).onclick();assert.equal(await choice,'Upload');
 assert.equal(sourceValue('right').value,'Lucas_Character/uploads/deer.png');
 assert.equal(sourceValue('top').value,'top.png');assert.equal(sourceValue('bottom').value,'bottom.png');
 // Queue integration: cancel sends nothing; upload bypasses the prompt dialog.
 nodes.push(sourceNode);let queued=0;app.queuePrompt=async()=>{queued++;};
 await extensions.find(e=>e.name==='Lucas.CharacterApproval').setup();
 let q=app.queuePrompt(0,1);find('button',i.t('cancel')).onclick();await q;assert.equal(queued,0);
 q=app.queuePrompt(0,1);find('button',i.t('uploadStart')).onclick();await q;assert.equal(queued,1);
 assert(!find('h2',i.t('title')));
 q=app.queuePrompt(0,1);find('button',i.t('sourceGenerate')).onclick();find('button',i.t('sourceNext')).onclick();
 await new Promise(r=>setImmediate(r));assert(find('h2',i.t('title')));
 find('button',i.t('submit')).onclick();await q;assert.equal(queued,2);
 assert.equal(sourceValue('source').value,'Generate');
 // Loading facade: stage progress, review/retry, success, errors, scoped cancel.
 let seq=0,queueFail=false;
 api.queuePrompt=async()=>{if(queueFail)throw Error('Test validation failure');return {prompt_id:'job-'+(++seq)};};
 const loading=await load('loading.js');
 await extensions.find(e=>e.name==='Lucas.GuidedLoading').setup();
 const payload={output:{'746':{class_type:'LucasViewSource'},'16':{class_type:'KSampler'},'742':{class_type:'LucasPBRPaint21'}}};
 const screen=descendants(document.body).find(e=>e.attributes&&e.id==='lucas-guided-screen');assert(screen);assert.equal(screen.hidden,false);
 const support=descendants(screen).find(e=>e.tag==='section');assert.equal(support.hidden,true);
 loading.beginSelection();loading.selectionCancelled();assert(find('h2',i.t('loadReady')));
 await api.queuePrompt(0,payload);assert(find('h2',i.t('loadQueued')));
 events.execution_start({detail:{prompt_id:'job-1'}});
 events.executing({detail:{node:'16',prompt_id:'job-1'}});assert(find('h2',i.t('loadFront')));
 events.progress({detail:{prompt_id:'unrelated',value:99,max:100}});
 let progress=descendants(screen).find(e=>e.tag==='progress');assert.equal(progress.value,undefined);
 events.progress({detail:{prompt_id:'job-1',value:5,max:20}});assert.equal(progress.value,25);
 events.executing({detail:'742'});assert(find('h2',i.t('loadTexture')));assert.equal(progress.value,undefined);
 events['lucas-view-review']({detail:{node_id:300,token:'pending',images:[],requested:'left',approved:['front'],remaining:['left','back'],pending:['left','back'],skipped:[],seed:'42',attempt:1}});
 assert(find('h2',i.t('loadReview')));
 events['lucas-view-review-closed']({detail:{token:'pending'}});assert(find('h2',i.t('loadPreparing')));
 events.executed({detail:{prompt_id:'job-1',output:{lucas_result:['Lucas_Character/3D/model.glb'],lucas_blend:['Lucas_Character/3D/model.blend']}}});
 events.execution_success({detail:{prompt_id:'job-1'}});assert(find('h2',i.t('loadDone')));
 assert.equal(support.hidden,false);const supportLink=find('a',i.t('supportLink'));assert.equal(supportLink.href,'https://ko-fi.com/lucasdlugoss');assert.equal(supportLink.target,'_blank');assert.equal(supportLink.rel,'noopener noreferrer');
 const dl=find('a',i.t('loadDownload'));assert.equal(dl.hidden,false);assert(dl.href.includes('download?path='));
 find('button',i.t('loadEditor')).onclick();assert.equal(screen.hidden,true);
 find('button',i.t('loadReturn')).onclick();assert.equal(screen.hidden,false);
 await api.queuePrompt(0,payload);events.execution_error({detail:{prompt_id:'job-2',exception_message:'Test OOM'}});
 assert(find('h2',i.t('loadError')));assert(find('pre','Test OOM'));assert.equal(support.hidden,true);assert.equal(dl.hidden,true);
 queueFail=true;await assert.rejects(api.queuePrompt(0,payload));queueFail=false;assert(find('h2',i.t('loadError')));
 await api.queuePrompt(0,payload);loading.expectFrontRetry();events.execution_interrupted({detail:{prompt_id:'job-3'}});assert(!find('h2',i.t('loadCancelled')));
 await api.queuePrompt(0,payload);events.execution_interrupted({detail:{prompt_id:'job-3'}});assert(find('h2',i.t('loadQueued')));
 events.execution_interrupted({detail:{prompt_id:'job-4'}});assert(find('h2',i.t('loadCancelled')));
 await api.queuePrompt(0,payload);
 const oldFetch=api.fetchApi;
 api.fetchApi=async(url,options)=>{
  requests.push({url,data:options?.body?JSON.parse(options.body):null});
  if(url==='/queue'&&!options)return {ok:true,json:async()=>({queue_pending:[[0,'job-5'],[1,'another-job']],queue_running:[]})};
  return {ok:true,json:async()=>({})};
 };
 await find('button',i.t('cancel')).onclick();assert(find('h2',i.t('loadCancelled')));
 assert.deepEqual(requests.at(-1).data,{delete:['job-5']});
 api.fetchApi=oldFetch;
 // All new screen strings have complete translations and stable placeholders.
 for(const [lang] of i.languages){i.setLanguage(lang);find('button',i.t('loadReturn',{},'en'))?.onclick?.();}
 completed=true;
 console.log('PASS: six-view dialogs plus guided loading, progress isolation, review, retry, results, error, cancellation, editor escape and eight-language catalogs.');
})().catch(e=>{console.error(e);process.exitCode=1;});

import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
PACK=ROOT/'ComfyUI-Lucas-Character-Approval'
spec=importlib.util.spec_from_file_location('rig',PACK/'rig.py');rig=importlib.util.module_from_spec(spec);spec.loader.exec_module(rig)

class Node:
 def __init__(self,name,args,index):self.name=name;self.args=args;self.index=index
 def out(self,slot):return [str(self.index),slot]
class Graph:
 def __init__(self):self.nodes=[]
 def node(self,name,**args):
  n=Node(name,args,len(self.nodes));self.nodes.append(n);return n
 def finalize(self):return {str(n.index):{'class_type':n.name,'inputs':n.args} for n in self.nodes}

class RigTests(unittest.TestCase):
 def metadata(self):return dict(joints=[[0,0,0],[0,0,1]],tails=[[0,0,1],[0,0,2]],names=['root','head'],parents=[None,0],mesh_center=[0,0,0],mesh_scale=2)
 def test_valid_skeleton(self):self.assertEqual(rig.validate_skeleton(self.metadata())['bones'],2)
 def test_cycle_rejected(self):
  m=self.metadata();m['parents']=[1,0]
  with self.assertRaises(ValueError):rig.validate_skeleton(m)
 def test_invalid_predictions_rejected(self):
  for key,value in [('mesh_scale',0),('names',['same','same']),('joints',[[float('nan'),0,0],[0,0,1]])]:
   m=self.metadata();m[key]=value
   with self.assertRaises(ValueError):rig.validate_skeleton(m)
 def test_disabled_exports_blend_without_unirig(self):
  with patch.object(rig,'check_unirig',side_effect=AssertionError('must not load')), patch.object(rig,'export_blender_materials') as export:
   self.assertEqual(rig.LucasAutomaticRig().run('original.glb','None')['result'],('original.glb',))
   export.assert_called_once_with('original.glb')
   self.assertIs(rig.LucasAutomaticRig.VALIDATE_INPUTS('None'),True)
 def test_enabled_dependency_error(self):
  with patch.object(rig,'check_unirig',side_effect=RuntimeError('missing backend')):
   self.assertEqual(rig.LucasAutomaticRig.VALIDATE_INPUTS('UniRig'),'missing backend')
 def test_no_template_fallback(self):
  with self.assertRaises(ValueError):rig.LucasAutomaticRig().run('x.glb','Quadruped')
 def test_graph_links(self):
  for filename in ['Qwen_Character_Approval_3Views_Offline.json','Lucas_Retomar_PBR.json','Lucas_Retomar_Rig.json']:
   d=json.loads((ROOT/filename).read_text());nodes={n['id']:n for n in d['nodes']}
   for lid,origin,slot,target,index,typ in d['links']:
    self.assertIn(lid,nodes[origin]['outputs'][slot]['links']);self.assertEqual(nodes[target]['inputs'][index]['link'],lid)
   n=next(n for n in nodes.values() if n['type']=='LucasAutomaticRig');self.assertIn(n['widgets_values'][0],['None','UniRig']);self.assertEqual(n['widgets_values'][1],42)
 def test_expansion_uses_both_models_and_original(self):
  with tempfile.TemporaryDirectory() as directory:
   (Path(directory)/'source.glb').write_bytes(b'fixture')
   fp=types.SimpleNamespace(get_output_directory=lambda:directory)
   graph=types.SimpleNamespace(GraphBuilder=Graph)
   with patch.dict(sys.modules,{'folder_paths':fp,'comfy_execution.graph_utils':graph}),patch.object(rig,'check_unirig'):
    out=rig.LucasAutomaticRig().run('source.glb','UniRig',123)
    nodes=list(out['expand'].values());typeset={n['class_type'] for n in nodes}
    self.assertIn('UniRigExtractSkeletonNew',typeset);self.assertIn('UniRigApplySkinningMLNew',typeset)
    extraction=next(n for n in nodes if n['class_type']=='UniRigExtractSkeletonNew')
    self.assertEqual(extraction['inputs']['skeleton_template'],'articulationxl');self.assertEqual(extraction['inputs']['seed'],123)
    self.assertEqual(nodes[-1]['inputs']['source_path'],'source.glb')
    with self.assertRaises(ValueError):rig.output_path('../outside.glb','.glb')

if __name__=='__main__':unittest.main()
